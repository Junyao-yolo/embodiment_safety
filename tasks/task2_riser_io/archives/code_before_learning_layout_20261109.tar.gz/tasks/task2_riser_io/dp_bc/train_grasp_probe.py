"""Fine-tune one Task2 demonstration prefix to verify closed-loop grasp learnability."""
from pathlib import Path
import copy,json,os,subprocess,sys,time
import numpy as np
import torch
D=Path(__file__).resolve().parent
from model import build
from interface import CAMERAS
OUT=D/"runs/grasp_fit_v001"
EP=D/"data/opposed_v002/raw/episode_0189"
def main():
 OUT.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);torch.manual_seed(42)
 rng=np.random.default_rng(42);started=time.perf_counter()
 payload=torch.load(D/"runs/opposed100_v001/policy_bn_synced.pt",map_location="cpu",weights_only=False)
 model=build(payload["config"]);model.load_state_dict(payload["model"]);model=model.cuda()
 limit=int(np.searchsorted(np.load(EP/"time.npy"),14.,side="right"))
 state=torch.from_numpy(np.load(EP/"state.npy")[:limit].copy()).cuda()
 action=torch.from_numpy(np.load(EP/"action.npy")[:limit].copy()).cuda()
 images={c:torch.from_numpy(np.load(EP/(c+".npy"),mmap_mode="r")[:limit].copy()).permute(0,3,1,2).float().cuda()/255 for c in CAMERAS}
 horizon=model.horizon
 def batch(indices):
  oi=torch.as_tensor(np.asarray(indices)[:,None]+np.arange(2)[None],device="cuda")
  ai=torch.as_tensor(np.asarray(indices)[:,None]+np.arange(horizon)[None],device="cuda")
  return {"obs":{**{c:images[c][oi] for c in CAMERAS},"state":state[oi]},"action":action[ai]}
 model.train()
 for mod in model.modules():
  if isinstance(mod,torch.nn.modules.batchnorm._BatchNorm):mod.eval()
 opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=1e-5,weight_decay=1e-6)
 settings={"source_checkpoint":str(D/"runs/opposed100_v001/policy_bn_synced.pt"),"episode":str(EP),
  "prefix_seconds":14,"steps":2000,"batch_size":16,"learning_rate":1e-5,"precision":"float32",
  "normalization":"BatchNorm running statistics fixed during fine-tuning","architecture":"unchanged Task2 DP-BC",
  "purpose":"Single-demonstration grasp diagnostic, not the final 100-demonstration model"}
 (OUT/"config.json").write_text(json.dumps(settings,indent=2))
 losses=[]
 with (OUT/"metrics.jsonl").open("w") as log:
  for step in range(1,2001):
   b=batch(rng.integers(0,limit-horizon+1,size=16));opt.zero_grad(set_to_none=True)
   loss=model.compute_loss(b)
   if not torch.isfinite(loss):raise RuntimeError("Nonfinite loss")
   loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
   losses.append(float(loss.detach()))
   if step%100==0:
    row={"status":"TRAINING","step":step,"total_steps":2000,"loss_mean_100":float(np.mean(losses[-100:])),"wall_s":time.perf_counter()-started}
    log.write(json.dumps(row)+"\n");log.flush();(OUT/"progress.json").write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
 model.eval()
 payload["model"]={k:v.detach().cpu() for k,v in model.state_dict().items()};payload["diagnostic_training"]=settings
 torch.save(payload,OUT/"policy.pt")
 checks=[]
 with torch.no_grad():
  for k in [19,30,60,65,75,95,120]:
   b=batch([k-1]);torch.manual_seed(189)
   pred=model.predict_action(b["obs"])["action"][0,0].reshape(6,8)
   truth=action[k].reshape(6,8)
   checks.append({"sample":k,"arm_mae_rad":float(abs(pred[:,:7]-truth[:,:7]).mean()),"arm_max_rad":float(abs(pred[:,:7]-truth[:,:7]).max()),"width_error_mm":float(abs(pred[:,7]-truth[:,7]).max()*1000)})
 (OUT/"action_validation.json").write_text(json.dumps(checks,indent=2))
 del model,opt,images,state,action;torch.cuda.empty_cache()
 evaluation=D/"evaluations/grasp_fit_v001";evaluation.mkdir(exist_ok=True)
 command=["/mnt/data2/isaacsim-5.0.0/python.sh","-B",str(D/"evaluate_batch.py"),"--checkpoint",str(OUT/"policy.pt"),
  "--output",str(evaluation),"--trials","1","--seed","189","--max-seconds","12","--n-action-steps","1","--policy-device","cuda",
  "--thresholds",str(D/"runs/opposed100_v001/safety_thresholds.json")]
 (OUT/"progress.json").write_text(json.dumps({"status":"TESTING_GRASP","step":2000,"command":command},indent=2))
 with (evaluation/"worker.log").open("w") as log:
  completed=subprocess.run(command,cwd=D,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 resultpath=evaluation/"trial_000/result.json"
 report=json.loads(resultpath.read_text()) if resultpath.exists() else {}
 valid=report.get("error") in (None,"released assembly incomplete") and report.get("command_blocks",0)>0
 result={"status":"COMPLETE" if completed.returncode==0 and valid else "TEST_ERROR","training_steps":2000,
  "wall_s":time.perf_counter()-started,"grasp_lift_passed":bool(report.get("wire_lifted")),
  "max_ring_lift_m":report.get("max_ring_lift_m"),"evaluation":str(evaluation),"action_validation":checks}
 (OUT/"result.json").write_text(json.dumps(result,indent=2));(OUT/"progress.json").write_text(json.dumps(result,indent=2))
 print(json.dumps(result),flush=True)
if __name__=="__main__":main()
