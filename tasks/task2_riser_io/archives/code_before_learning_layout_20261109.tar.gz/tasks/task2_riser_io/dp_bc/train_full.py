"""Train the established Task2 DP-BC model on successful demonstrations."""
from pathlib import Path
import argparse,copy,json,math,os,random,time
import numpy as np
import torch
from torch.utils.data import DataLoader,Sampler
from data import Task2Data
from model import CONFIG,build
from interface import CAMERAS,action_block_to_targets
from diffusion_policy.model.common.normalizer import LinearNormalizer,SingleFieldLinearNormalizer
from diffusion_policy.model.diffusion.ema_model import EMAModel

class LocalityBatches(Sampler):
 """Shuffle bounded contiguous windows while visiting every sequence once per epoch."""
 def __init__(self,size,batch_size,seed):
  self.size=size;self.batch_size=batch_size;self.seed=seed;self.epoch=0;self.block_size=1024
 def __len__(self):return math.ceil(self.size/self.batch_size)
 def __iter__(self):
  rng=np.random.default_rng(self.seed+self.epoch);self.epoch+=1
  for block in rng.permutation(math.ceil(self.size/self.block_size)):
   ids=np.arange(block*self.block_size,min((block+1)*self.block_size,self.size));rng.shuffle(ids)
   for start in range(0,len(ids),self.batch_size):yield ids[start:start+self.batch_size].tolist()

def main():
 p=argparse.ArgumentParser()
 p.add_argument("--data",required=True);p.add_argument("--output",required=True)
 p.add_argument("--epochs",type=int,default=30);p.add_argument("--batch-size",type=int,default=32)
 p.add_argument("--workers",type=int,default=2);p.add_argument("--seed",type=int,default=42)
 p.add_argument("--steps",type=int,default=0)
 a=p.parse_args();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
 started=time.perf_counter();torch.set_num_threads(2)
 torch.manual_seed(a.seed);random.seed(a.seed);np.random.seed(a.seed)
 torch.backends.cudnn.benchmark=True
 torch.set_float32_matmul_precision("high")
 status={"status":"LOADING_DATA","started_unix":time.time(),"pid":os.getpid()}
 def publish(**kw):
  status.update(kw);(out/"progress.json").write_text(json.dumps(status,indent=2))
 publish()
 data=Task2Data(a.data)
 if len(data.episodes)!=100:raise ValueError(f"Expected the new 100 trajectories, got {len(data.episodes)}")
 loader=DataLoader(data,batch_sampler=LocalityBatches(len(data),a.batch_size,a.seed),
                   num_workers=a.workers,pin_memory=True,persistent_workers=a.workers>0)
 steps=a.steps or a.epochs*len(loader)
 config=dict(CONFIG)
 model=build(config)
 norm=LinearNormalizer()
 norm.fit({k:np.concatenate([e[k] for e in data.episodes]) for k in ("state","action")},mode="limits")
 for c in CAMERAS:norm[c]=SingleFieldLinearNormalizer.create_identity()
 model.set_normalizer(norm);model=model.cuda()
 ema_model=copy.deepcopy(model);ema=EMAModel(ema_model,power=.75)
 opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-6)
 warmup=min(500,max(1,steps//20))
 schedule=torch.optim.lr_scheduler.LambdaLR(opt,lambda s:min(1.,(s+1)/warmup)*.5*(1+math.cos(math.pi*max(0,s-warmup)/max(1,steps-warmup))))
 settings=dict(model=config,data=str(Path(a.data).resolve()),episodes=len(data.episodes),sequences=len(data),
  epochs=a.epochs,steps=steps,batch_size=a.batch_size,seed=a.seed,learning_rate=1e-4,
  optimizer="AdamW",weight_decay=1e-6,lr_schedule="warmup_cosine",warmup_steps=warmup,
  gradient_clip_norm=1.,precision="bfloat16 autocast; float32 weights",ema_power=.75,ema_max_decay=.9999,
  batch_sampling="shuffled 1024-window locality blocks, randomized within each block, all windows each epoch",loader_workers=a.workers,gpu=torch.cuda.get_device_name(),torch_version=torch.__version__,
  split="All 100 demonstration episodes train; independent simulation resets test; no test-set checkpoint selection",
  checkpoint_selection="final EMA",episode_paths=[e["path"] for e in data.episodes])
 (out/"config.json").write_text(json.dumps(settings,indent=2))
 def dev(b):return {k:dev(v) for k,v in b.items()} if isinstance(b,dict) else b.cuda(non_blocking=True)
 def save(step,final=False):
  payload={"config":config,"model":ema_model.state_dict(),"steps":step,"training":settings}
  torch.save(payload,out/"policy.pt.tmp");os.replace(out/"policy.pt.tmp",out/"policy.pt")
  torch.save({"raw_model":model.state_dict(),"optimizer":opt.state_dict(),"scheduler":schedule.state_dict(),"steps":step,
              "ema_step":ema.optimization_step,"rng":torch.get_rng_state(),"cuda_rng":torch.cuda.get_rng_state()},out/"training_state.pt.tmp")
  os.replace(out/"training_state.pt.tmp",out/"training_state.pt")
 it=iter(loader);training_start=time.perf_counter();rolling=[];first_loss=None
 with (out/"metrics.jsonl").open("w") as log:
  for step in range(1,steps+1):
   try:batch=next(it)
   except StopIteration:it=iter(loader);batch=next(it)
   batch=dev(batch);model.train();opt.zero_grad(set_to_none=True)
   with torch.autocast("cuda",dtype=torch.bfloat16):loss=model.compute_loss(batch)
   if not torch.isfinite(loss):raise RuntimeError("Nonfinite training loss")
   loss.backward();grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
   if not torch.isfinite(grad):raise RuntimeError("Nonfinite gradients")
   opt.step();schedule.step();ema.step(model)
   with torch.no_grad():
    training_buffers=dict(model.named_buffers())
    for name,buffer in ema_model.named_buffers():buffer.copy_(training_buffers[name])
   value=float(loss.detach());rolling.append(value)
   if first_loss is None:first_loss=value
   wall=time.perf_counter()-training_start
   row=dict(step=step,loss=value,lr=schedule.get_last_lr()[0],wall_s=wall)
   log.write(json.dumps(row)+"\n")
   if step%50==0 or step==1:
    log.flush();average=float(np.mean(rolling[-100:]))
    publish(status="TRAINING",step=step,total_steps=steps,epoch=step/len(loader),mean_loss_100=average,
            train_wall_s=wall,seconds_per_step=wall/step,estimated_remaining_s=wall/step*(steps-step),
            peak_gpu_allocated_GiB=torch.cuda.max_memory_allocated()/2**30)
    print(json.dumps(status),flush=True)
   if step%2000==0 or step==steps:save(step)
 ema_model.eval()
 with torch.no_grad():
  obs={k:v[:1] for k,v in batch["obs"].items()}
  pred=ema_model.predict_action(obs)["action"].cpu().numpy()
 action_block_to_targets(pred[0,0])
 reloaded=build(config)
 reloaded.load_state_dict(torch.load(out/"policy.pt",map_location="cpu",weights_only=False)["model"])
 result=dict(status="COMPLETE",episodes=len(data.episodes),sequences=len(data),steps=steps,
   training_wall_s=time.perf_counter()-training_start,total_wall_s=time.perf_counter()-started,
   first_loss=first_loss,mean_last_100_loss=float(np.mean(rolling[-100:])),
   inference_shape=list(pred.shape),checkpoint_reload_passed=True,learned_policy_task_success_verified=False)
 (out/"result.json").write_text(json.dumps(result,indent=2));publish(**result)
 print(json.dumps(result),flush=True)
if __name__=="__main__":main()
