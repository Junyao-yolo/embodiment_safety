# Task2 反馈采集

代码目录：/mnt/data2/wjy_SERL/Embodied_Safety/tasks/task2_riser_io/dp_bc

## 执行和保存

默认入口 collect.py 使用 feedback_dart.json。一个批次只启动一个 Isaac Sim 应用、加载一次场景；逐条保存结果后停止时间线，恢复刚体初始变换、世界关节锚点和机器人关节状态，再在同一场景中重置物理。相机与 render products 在批次内复用。

只有功能装配成功的回合进入 data/raw/episode_XXXX。每次尝试的连续数值保存在 attempt_results/measurements_SEED.npz，汇总保存在 collection_SEED.json。失败回合不进入示范训练，默认不编码失败视频。

- action.npy：专家纠正指令；物理等待段是明确的保持指令。
- executed_action.npy：实际执行指令，包括 DART 扰动或 DAgger 策略动作。
- action_source.npy：每条指令的来源。
- diagnostics.json：独立保存数值质量、轨迹平滑度、几何偏差与连续测量文件路径，不参与功能验收。
- state.npy：23 维机器人状态，上一次指令使用实际执行值。
- external/wrist_left/wrist_right.npy：10 Hz、128×128 RGB，与状态、时间对齐。
- episode.json：初态、路径模式、阶段名称、标签语义。

一个48维动作包含6条60 Hz关节/夹爪指令，对应0.1秒。8步动作块执行0.8秒；观测仍在运动期间每0.1秒更新。等待结束会清空策略旧历史和剩余动作，从当前观测重新规划。固定扩散噪声使用本回合的种子，不同回合仍可采样不同动作模式。

## 随机化和反馈

线缆、固定端、束线器和拾取支座整体变换，保持连接关系；目标板及其支撑共同变换。螺丝相对托架作小范围位置扰动和偏航旋转，然后托架带动螺丝整体移动。机器人初始末端位姿和可抓取区域内的抓取点分别随机化。

相邻四个种子共享一组初态，分别使用 direct、left、right、high 搬运路径。成功数据中保存各模式计数。路径族是待物理验证的候选，不能把配置了四种路径等同于已得到四种成功模式。

反馈专家读取当前物体和关节状态，通过 query(state) 给出当前任务参考下的纠正指令。抓取后的参考使用实测抓取变换。跟踪偏差可以延长本阶段；预算用完后记录偏差并继续。它不负责从任意散乱状态全局重规划装配任务。

DART-style 采集使用相关的笛卡尔速度扰动，默认标准差2 mm/s、相关时间0.35秒；接触阶段幅度为其十分之一。专家标签在扰动前产生，平滑执行器限制指令变化。这是固定噪声实验，尚未估计 DART 论文中的最优噪声协方差。

DAgger 在实际执行轨迹上查询专家，以10 Hz决定执行策略还是专家动作，并记录策略实际执行比例和接管次数。只有最终成功的混合轨迹进入聚合数据集；每轮在全部历史成功数据上从零训练。输入 checkpoint 用于该轮采集，下一轮再使用本轮训练得到的 checkpoint。

## 数值记录与任务判定

版本：task2_released_assembly_v004。

力、力矩、峰值速度、加速度、关节间隙、姿态质量和螺纹导程拟合均记录，不因这些数值短时超限中止或剔除回合。控制器的平滑限速用于生成动作，不作为成功轨迹筛选条件。

旋拧轴向参考按螺纹导程进给，该阶段接触力只记录，不用低力目标向上退让。需人工结束实际装配失败的尝试时，将原因写入 dp_bc/reset_requested；采集器保存该次诊断，在同一应用和场景内重置后继续。

功能完成检查端子仍位于实物座的容纳范围内，螺丝与螺母和端子有接触、穿入螺母区域，夹爪已松开。座和环形端子的尺寸来自 USD 几何。原有较严格的数值质量检查保留在 numerical_quality；手部撤离距离同样只记录。无法继续的非有限物理状态/指令，或执行结束仍未装配完成，才作为失败。safety_verdict 仍为 UNASSESSED。

静止段不删除帧、不压缩时间，也不添加人为微动。训练时仅对完整16帧窗口内的长保持段减少重复起点，阶段转换和短停顿保留。现有23维观测没有四个阶段标记位。

## 运动速度与腕部视角

普通移动的笛卡尔规划峰值为1000 mm/s，五次插值的线加速度上限为2000 mm/s²；普通阶段的名义时间倍率为0.1，参考步进也使用对应阶段速度。关节指令仍限制为1.8 rad/s、10 rad/s²，因此短距离、姿态变化和反馈跟踪可能达不到笛卡尔规划峰值。速度单位均按仿真时间计算。

抓取下降80 mm/s，线端抬起150 mm/s，端子落座30 mm/s，螺丝对齐50 mm/s，穿环及螺纹入口10 mm/s，拧紧轴向移动5 mm/s，回转重抓80 mm/s。拧紧旋转峰值1.85 rad/s，保留平滑旋转起停。这些是待物理验证的执行参数，不是安全损伤阈值。

当前采集场景 riser_io_success_v014.usda 的两个腕部镜头分别安装在手部坐标 X=−80 mm 和 X=+80 mm、Y=0、Z=35 mm，从相对两侧斜看指尖接触区，光轴夹角约93.7°。wrist_left 对应 −X 安装侧，wrist_right 对应 +X 安装侧，两者共同观察抓取目标的不同侧面。已在实际抓取与抬起姿态下渲染检查，夹爪主体仍出现在画面上部，端子与指尖接触区可见。

相机名称、RGB分辨率和状态/动作维数保持一致。历史数据保留原相机位姿，新增数据在相机 manifest 中记录实际位姿；episode_0101 使用之前的同侧机位。新机位完整装配尚未采集，旧 checkpoint 不视为已适配。

## 运行

新机位的100条成功轨迹单独采集到 data/opposed_v002/raw。两个 Task2 进程各负责50条；进程0使用偶数种子，进程1使用奇数种子，覆盖 direct、left、right、high 四种路径。初态随机化及相关 DART 扰动启用。Task1 的进程、配置和数据保持独立。

    python3 -B collect_parallel.py --output-root data/opposed_v002 --workers 2 --successes 100 --seed 100

第一个进程完成两条成功轨迹、验证场景内重置后，再自动启动第二个进程。每个进程持续复用自己的 Isaac 应用和已加载场景；完成后保存记录并原地重置，不逐回合重启。相邻种子共享初态但采用不同路径。已有成功和失败尝试的种子在重启批次时跳过。

批次进度：data/opposed_v002/progress.json；两个进程的进度、日志、重置请求分别带 worker_0、worker_1 后缀。每个进程最多尝试150回合，连续8次实际任务失败时停止该进程并报告 NEEDS_REPAIR。失败回合保留数值诊断，不进入 raw 训练目录。诊断数值不会触发拒收。

当前配置使用CPU PhysX和GPU相机渲染，120 Hz物理、60 Hz指令、10 Hz图像；刚体求解迭代为128/8，关节系统为64/8。接触与旋拧阶段保留跟踪收敛和停稳检查，普通接近、搬运和撤离完成计划停稳后即可继续。最终松爪后的保持检查为3秒。关节接近位置限位时提前减速。

只读取新机位数据进行 DP-BC 训练：

    /mnt/data2/wjy_SERL/Embodied_Safety/algos/diffusion_policy/.venv/bin/python -B train.py --data data/opposed_v002/raw --output runs/opposed_v002 --steps 1000

上面的训练命令不会自动执行。视频从成功回合的原始同步图像导出：

    /mnt/data2/wjy_SERL/Embodied_Safety/algos/diffusion_policy/.venv/bin/python -B export_success_video.py data/opposed_v002/raw/episode_0100

单进程采集仍支持 collect.py --collection-config feedback_expert.json --additional-successes 5。DAgger 入口为 dagger_round.py；策略执行对照可使用相同 seed、checkpoint 和预算，比较 --n-action-steps 1/8。演示回放读取 executed_action.npy 并恢复所记录的初态。

## 验证与限制

CPU检查已覆盖专家/执行标签分离和时间对齐、反馈纠偏、噪声相关性与执行平滑、真实策略进程通信、等待后的动作缓存清空、同一个USD stage内初态恢复，以及“数值尖峰不拒收、实际装配失败拒收”。

同样16次观测，动作块从1改为8，神经推理由16次降为2次。耗时记录在 implement-stage/execution_benchmark.json，仅代表CPU推理。既有15条数据的训练窗口由27341减为26984，连续原始数据保持完整。

Task1占用GPU期间没有运行新版物理回合。新版初态/路径可行性、DART恢复成功率、DAgger学习收益、同一场景连续物理重置以及每条总采集时长仍待验证。现有成功轨迹仍为15条，不能将CPU检查视作新增成功示范或“五分钟一条”的证据。

方法依据：[DAgger](https://proceedings.mlr.press/v15/ross11a.html)、[DART作者说明](https://bair.berkeley.edu/blog/2017/10/26/dart/)、[Diffusion Policy](https://diffusion-policy.cs.columbia.edu/)。

物理后端记录在每条轨迹的 physics_backend 和 runtime_config.physics_device 中。已有GPU轨迹保留其原始标记。后端切换在回合重置时重建物理上下文，复用同一个应用和USD场景。CPU接触阶段存在 getMaterialFromInternalFaceIndex 警告；力与扭矩仍作为未标定诊断量记录，CPU/GPU力值等价性尚未验证。
