"""Train and exercise the Task2 DP-BC data-to-command pipeline."""
from pathlib import Path
import argparse,json,time,random
import numpy as np
import torch
from torch.utils.data import DataLoader
from interface import CAMERAS,action_block_to_targets
from model import CONFIG,build
from data import Task2Data
def main():
 p=argparse.ArgumentParser();p.add_argument("--data",required=True);p.add_argument("--output",required=True);p.add_argument("--steps",type=int,default=100);p.add_argument("--batch-size",type=int,default=4);p.add_argument("--device",default="cuda")
 a=p.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 torch.set_num_threads(2);torch.manual_seed(42);random.seed(42);np.random.seed(42)
 data=Task2Data(a.data);model=build()
 from diffusion_policy.model.common.normalizer import LinearNormalizer,SingleFieldLinearNormalizer
 norm=LinearNormalizer()
 norm.fit({"state":np.concatenate([e["state"] for e in data.episodes]),"action":np.concatenate([e["action"] for e in data.episodes])},mode="limits")
 for c in CAMERAS:norm[c]=SingleFieldLinearNormalizer.create_identity()
 model.set_normalizer(norm);model=model.to(a.device)
 optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-6)
 loader=DataLoader(data,batch_size=a.batch_size,shuffle=True,num_workers=0)
 def dev(b):return {k:dev(v) for k,v in b.items()} if isinstance(b,dict) else b.to(a.device)
 it=iter(loader);started=time.perf_counter();losses=[]
 with (out/"metrics.jsonl").open("w") as log:
  for step in range(a.steps):
   try:batch=next(it)
   except StopIteration:it=iter(loader);batch=next(it)
   batch=dev(batch);model.train();optimizer.zero_grad(set_to_none=True)
   loss=model.compute_loss(batch)
   if not torch.isfinite(loss):raise RuntimeError("Nonfinite training loss")
   loss.backward();grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
   if not torch.isfinite(grad):raise RuntimeError("Nonfinite gradients")
   optimizer.step();losses.append(float(loss.detach()))
   row={"step":step+1,"loss":losses[-1],"wall_s":time.perf_counter()-started};log.write(json.dumps(row)+"\n");log.flush()
   if (step+1)%10==0:print(json.dumps(row),flush=True)
 model.eval()
 with torch.no_grad():pred=model.predict_action(batch["obs"])["action"].cpu().numpy()
 if pred.shape!=(batch["action"].shape[0],1,48):raise ValueError("Inference action shape")
 targets=[action_block_to_targets(x[0]) for x in pred]
 checkpoint=out/"policy.pt";torch.save({"config":CONFIG,"model":model.state_dict(),"steps":a.steps},checkpoint)
 reloaded=build();reloaded.load_state_dict(torch.load(checkpoint,map_location="cpu",weights_only=False)["model"])
 reloaded=reloaded.to(a.device).eval()
 with torch.no_grad():again=reloaded.predict_action(batch["obs"])["action"].cpu().numpy()
 for x in again:action_block_to_targets(x[0])
 result={"passed":True,"episodes":len(data.episodes),"sequences":len(data),"steps":a.steps,"first_loss":losses[0],"last_loss":losses[-1],
 "wall_s":time.perf_counter()-started,"state_shape":list(batch["obs"]["state"].shape),"image_shape":list(batch["obs"]["external"].shape),
 "action_shape":list(batch["action"].shape),"inference_shape":list(pred.shape),"controller_target_shape":list(targets[0].shape),
 "checkpoint_reload_passed":True,"scope":"data loading, gradient updates, checkpoint reload, inference and 60Hz controller target conversion",
 "learned_policy_task_success_verified":False}
 (out/"result.json").write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
if __name__=="__main__":main()
