"""Check Task2 entry points and the generated policy-evaluation worker."""
from pathlib import Path
import ast,runpy,sys,tempfile
import numpy as np
D=Path(__file__).resolve().parent;R=D.parent
for p in [R/"scripts/run_dp_bc.py",*D.glob("*.py")]:
 compile(p.read_text(),str(p),"exec")
with tempfile.TemporaryDirectory(dir=D/"implement-stage") as tmp:
 old=sys.argv
 sys.argv=[str(D/"evaluate.py"),"--checkpoint",str(D/"runs/pilot5/policy.pt"),"--output",tmp,"--n-action-steps","8","--fixed-noise"]
 captured=[]
 runpy.run_path(str(D/"evaluate.py"),init_globals={"exec":lambda code,namespace:captured.append(code)})
 sys.argv=old
 assert len(captured)==1
 old=sys.argv
 sys.argv=[str(D/"replay.py"),"--episode",str(D/"data/raw/episode_0020")]
 captured=[]
 runpy.run_path(str(D/"replay.py"),init_globals={"exec":lambda code,namespace:captured.append(code)})
 sys.argv=old
 assert len(captured)==1
# Execute the actual baseline gripper primitive without launching Isaac.
tree=ast.parse((R/"scripts/run_dp_bc.py").read_text())
grip=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="grip")
q=np.array([0.,-.5,0.,-2.,0.,1.7,.7,.04,.04])
trace=[]
class Solver:
 def compute_forward_kinematics(self,*a):return np.zeros(3),np.eye(3)
class Robot:
 def set_dof_position_targets(self,values,*a):trace.append(values.copy())
ns=dict(q=q,fi=np.array([7,8]),ai=np.arange(7),solver=Solver(),robot=Robot(),ix=np.array([0]),np=np,
 motion_config={"phases":{}},phase="grasp",physics_hz=120,expert=None,tick=lambda n:None)
exec(compile(ast.Module(body=[grip],type_ignores=[]),"grip","exec"),ns)
ns["grip"](0.,1.)
assert np.all(np.diff(np.array(trace)[:,0,7])<=0)
assert np.allclose(q[7:9],0.)
print("Entry points compile; evaluation worker constructs; baseline gripper closes monotonically.")
