"""Measure the contact tensor sign on a settled body."""
from pathlib import Path
import json
from isaacsim import SimulationApp
R=Path('/mnt/data2/wjy_SERL/Embodied_Safety/tasks/task2_riser_io')
app=SimulationApp({'headless':True,'limit_cpu_threads':2,'extra_args':['--/log/file='+str(R/'dp_bc/contact_probe_kit.log')]})
try:
 import omni.usd,omni.physics.tensors as tensors
 from pxr import UsdGeom,UsdPhysics,PhysxSchema,Gf
 from isaacsim.core.api import SimulationContext
 omni.usd.get_context().new_stage()
 stage=omni.usd.get_context().get_stage()
 UsdGeom.Xform.Define(stage,'/World')
 scene=UsdPhysics.Scene.Define(stage,'/World/PhysicsScene')
 scene.CreateGravityDirectionAttr(Gf.Vec3f(0,0,-1));scene.CreateGravityMagnitudeAttr(9.81)
 api=PhysxSchema.PhysxSceneAPI.Apply(scene.GetPrim())
 api.CreateEnableGPUDynamicsAttr(True);api.CreateBroadphaseTypeAttr('GPU')
 base=UsdGeom.Cube.Define(stage,'/World/Base');base.CreateSizeAttr(1.)
 base.AddScaleOp().Set(Gf.Vec3f(1,1,.1));base.AddTranslateOp().Set(Gf.Vec3d(0,0,-.5))
 UsdPhysics.CollisionAPI.Apply(base.GetPrim())
 body=UsdGeom.Cube.Define(stage,'/World/Body');body.CreateSizeAttr(.1)
 body.AddTranslateOp().Set(Gf.Vec3d(0,0,.12))
 UsdPhysics.CollisionAPI.Apply(body.GetPrim());UsdPhysics.RigidBodyAPI.Apply(body.GetPrim())
 UsdPhysics.MassAPI.Apply(body.GetPrim()).CreateMassAttr(.1)
 PhysxSchema.PhysxContactReportAPI.Apply(body.GetPrim()).CreateThresholdAttr(0.)
 sim=SimulationContext(physics_dt=1/120,rendering_dt=1/60,backend='torch',device='cuda:0')
 sim.initialize_physics();sim.play()
 for _ in range(4):sim.step(render=True)
 view=tensors.create_simulation_view('torch');view.set_subspace_roots('/')
 contacts=view.create_rigid_contact_view('/World/Body',['/World/Base'],128)
 rows=[]
 for step in range(180):
  sim.step(render=False)
  if step%30==29:
   f,p,n,d,c,st=contacts.get_contact_data(1/120)
   count=int(c[0,0]);start=int(st[0,0])
   values=f[start:start+count].cpu().numpy().reshape(-1)
   rows.append(dict(step=step+1,force_values=values.tolist(),positive_count=int((values>0).sum()),magnitude_count=int((abs(values)>0).sum())))
 result={'fixture':'gravity-loaded cube on static plate; no task trajectory','rows':rows}
 (R/'dp_bc/contact_sign_probe.json').write_text(json.dumps(result,indent=2))
 print('CONTACT_SIGN_RESULT',json.dumps(result),flush=True)
finally:
 app.close()
