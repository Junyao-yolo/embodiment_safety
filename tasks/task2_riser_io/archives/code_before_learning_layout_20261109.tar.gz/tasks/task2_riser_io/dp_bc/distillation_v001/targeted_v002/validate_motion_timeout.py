"""Exercise progress timeouts against the executed collection controller."""
import ast,json,sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from collect_handback import make_source
tree=ast.parse(make_source())
node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="control_schedule")
schedule_code=compile(ast.Module(body=[node],type_ignores=[]),"<collection control_schedule>","exec")
results=[]
def run_case(name, *, recover=False, existing_teacher=False, normal=False, waypoint=False):
 expert=SimpleNamespace(error=.01,limits=SimpleNamespace(velocity=np.zeros(7)),reference=dict(position=np.zeros(3),rotation=np.eye(3)))
 expert.tracking_error=lambda state:expert.error
 calls=[]
 router=SimpleNamespace(teacher_override=existing_teacher,path_recovery_active=False)
 def take_over(state,phase,reason,details):
  calls.append(dict(details,previous_override=router.teacher_override))
  router.teacher_override=True
  if recover:expert.error=0.
 router.recover_motion=take_over
 ns=dict(expert=expert,router=router,phase="approach",latest={},report={},np=np)
 exec(schedule_code,ns)
 gen=ns["control_schedule"](300 if normal else 10)
 exhausted=False;finished=False
 for tick in range(1000):
  if normal:expert.error=.001
  if waypoint:
   if tick<20:
    expert.error=0.;router.path_recovery_active=True
   elif tick==20:
    expert.reference["position"]=np.array([0.,0.,.025])
   if tick>=20:
    expert.error=max(0.,.025-(tick-20)*.0001)
    router.path_recovery_active=expert.error>.0002
  try:next(gen)
  except StopIteration:finished=True;break
  except RuntimeError as exc:
   assert "Teacher recovery exhausted" in str(exc)
   exhausted=True;break
 assert router.teacher_override==existing_teacher,(name,"override not restored")
 if normal or waypoint:
  assert finished and not calls,(name,finished,calls)
 elif recover:
  assert finished and len(calls)==1,(name,finished,calls)
  assert calls[0]["no_progress_action_steps"]==20.
 else:
  assert exhausted and len(calls)==2,(name,exhausted,calls)
  assert all(c["no_progress_action_steps"]==20. for c in calls)
 results.append(dict(case=name,passed=True,control_ticks=tick,recoveries=calls,finished=finished,exhausted=exhausted))
run_case("student_stall_recovers",recover=True)
run_case("teacher_stall_recovers",recover=True,existing_teacher=True)
run_case("permanent_stall_bounded")
run_case("normal_motion_longer_than_twenty_steps",normal=True)
run_case("entry_waypoint_change_preserves_real_progress",waypoint=True)
output=HERE.parent/"motion_timeout_validation.json"
output.write_text(json.dumps(dict(passed=True,cases=results),indent=2))
print(json.dumps(dict(passed=True,cases=[dict(case=r["case"],control_ticks=r["control_ticks"],recovery_attempts=len(r["recoveries"])) for r in results],report=str(output)),indent=2))
