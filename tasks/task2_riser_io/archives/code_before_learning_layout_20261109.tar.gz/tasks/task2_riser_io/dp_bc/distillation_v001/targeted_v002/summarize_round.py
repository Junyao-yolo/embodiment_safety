"""Summarize Task2 corrective training and independent policy evaluation."""
from pathlib import Path
import json
import numpy as np
D=Path(__file__).resolve().parents[2]
O=D/"distillation_v001/retention_repair_v001/parallel"
T=D/"runs/handback_action4_parallel_v001"
E=D/"evaluations/handback_action4_parallel_v001"
def read(p):return json.loads(p.read_text())
def main():
 cfg=read(T/"config.json");train=read(T/"result.json");summary=read(E/"summary.json")
 before=read(O/"fit_before.json");after=read(O/"fit_after.json")
 episodes=read(O/"accepted_episodes.json")
 losses=[json.loads(line)["loss"] for line in (T/"metrics.jsonl").read_text().splitlines()]
 selected=read(E/"video_selection.json")
 n=summary["valid_tests"];ok=summary["task_successes"]
 safe_rate=summary["safe_completion_rate"]
 def value(x):return "未评定" if x is None else f"{100*x:.1f}%"
 lines=[
  f"Task2：{len(episodes)} 条教师辅助纠偏轨迹完成增量训练，随后执行 {n} 条无教师闭环测试。",
  f"任务成功 {ok}/{n}（{value(summary['task_success_rate'])}）；经验螺丝装配边界内完成率 {value(safe_rate)}。",
  "纠偏轨迹的装配成功与学生独立成功分别统计。纠偏采集使用特权状态教师，测试策略只接收 23 维机器人状态及三路 128×128 RGB 图像。",
  "",
  "| 训练参数 | 数值 |","|---|---|",
  f"| 梯度更新 | {train['steps']} |",f"| 批量 | {cfg['batch_size']} |",
  f"| 学习率 | {cfg['learning_rate']} |",f"| 热身步数 | {cfg['warmup_steps']} |",
  f"| 优化器 | {cfg['optimizer']} |",f"| 权重衰减 | {cfg['weight_decay']} |",
  f"| 梯度裁剪 | {cfg['gradient_clip_norm']} |",f"| EMA power | {cfg['ema_power']} |",
  f"| 精度 | {cfg['precision']} |","| 动作维数 / 执行块 | 48 / 4（0.4 s） |",
  f"| 实测训练时长 | {train['train_wall_s']/60:.2f} 分钟 |",
  f"| 实测测试总时长 | {summary['total_test_wall_s']/60:.2f} 分钟 |",
  "",
  "从当前学生检查点继续训练，仅载入本轮纠偏轨迹，归一化器继承原检查点。损失为归一化干净动作预测的掩码均方误差：先对每个样本的有效动作分量取均值，再对批量取均值。",
  f"首个更新损失 {losses[0]:.6g}，前 100 步均值 {np.mean(losses[:100]):.6g}，末 100 步均值 {np.mean(losses[-100:]):.6g}。",
  "",
  "| 固定观测下的拟合指标 | 更新前 | 更新后 |","|---|---:|---:|"]
 for key in ("normalized_action_mse","arm_mae_rad","gripper_mae_mm"):
  lines.append(f"| {key} | {before['aggregate'][key]:.6g} | {after['aggregate'][key]:.6g} |")
 lines += ["","| 阶段 | 更新前动作 MSE | 更新后动作 MSE | 更新后夹爪开度 MAE / mm |","|---|---:|---:|---:|"]
 for phase in ("approach","descend","grasp","transport","seat","release","screw_grasp","thread_turn","screw_regrasp_close"):
  a=before["by_phase"][phase];b=after["by_phase"][phase]
  lines.append(f"| {phase} | {a['normalized_action_mse']:.6g} | {b['normalized_action_mse']:.6g} | {b['gripper_mae_mm']:.3f} |")
 lines += ["","上述拟合指标来自训练样本，不等同于独立闭环成功率。",
  "测试使用相同分布的独立初态组、固定检查点和每回合 180 s 仿真执行预算，全程没有教师接管。",
  "安全统计只覆盖已冻结的经验螺丝装配运行边界：轴向 16 N、侧向 15 N、扭矩 0.025 N·m、接触倾角 6°；200 ms 平滑后连续超限 100 ms 记为违规，恢复后保留违规历史。数值超限不作为采集任务失败条件。",
  "已知问题：这些数值不是材料损伤极限。根部拉力、局部弯曲、连接损伤尚未完成阈值标定，真实损伤率未评定，不能据此宣称全过程物理安全。",
  "", "本轮纠偏覆盖："+json.dumps({key:sum(part.get(key,0) for part in cfg["data"]) for key in ("student_query_windows","student_to_teacher_boundary_windows")},ensure_ascii=False)+"。",
  "后续重复旋拧与重新夹持主要来自教师续接段；本轮没有通过全程装配验收的学生重新夹持纠偏样本。",
  "", "失败分类："+json.dumps(summary["failure_counts"],ensure_ascii=False)+"。",
  "运行边界超限分类："+json.dumps(summary["violation_counts"],ensure_ascii=False)+"。",
  "", "检查点：",str(T/"policy.pt"),"逐回合结果：",str(E/"trials.csv"),
  "完整测试统计：",str(E/"summary.json"),"训练损失历史：",str(T/"metrics.jsonl"),""]
 for category,items in selected.items():
  lines.append(category+f"：{len(items)} 条实际代表视频。")
  lines.extend(item["video"] for item in items)
  lines.append("")
 (O/"report.md").write_text("\n".join(lines))
 print(str(O/"report.md"),flush=True)
if __name__=="__main__":main()
