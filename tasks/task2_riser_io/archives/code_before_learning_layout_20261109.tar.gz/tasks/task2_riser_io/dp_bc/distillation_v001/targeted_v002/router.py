"""Stage-targeted corrective control with measured intervention events."""
from collections import deque
import numpy as np
from scipy.spatial.transform import Rotation
from feedback import RecoveryRouter

GROUPS = {
 "approach":"grasp", "descend":"grasp", "grasp":"grasp", "lift":"grasp",
 "level":"transport", "transport":"transport",
 "seat":"seating", "release":"seating", "retract":"seating",
}
class TargetedRouter(RecoveryRouter):
 def __init__(self,expert,config,seed,policy,clock):
  super().__init__(expert,config,seed,policy)
  self.clock=clock;self.phase=None;self.control="hold";self.events=[]
  self.reason="初始静置";self.trigger={};self.metrics={}
  self.mode="policy";self.bad_pose=0;self.bad_grip=0;self.window=deque()
  self.student_by_phase={};self.corrections_by_phase={};self.phase_start=0.
  self.pending_failure=None;self.grasp_reference=None;self.measured_grasp=None;self.motion_recoveries=[]
 def group(self,phase):
  return GROUPS.get(phase,"assembly")
 def pose_metrics(self,state):
  ref=self.expert.reference
  if ref["body"] is None:
   p,r=self.expert.fk(np.asarray(state["joints"])[0,:7])
   r=Rotation.from_matrix(r)
  else:
   actual=np.asarray(state[ref["body"]])[0];p=actual[:3];r=Rotation.from_quat(actual[3:])
  p=np.asarray(p);angle=float(np.linalg.norm((Rotation.from_matrix(ref["rotation"])*r.inv()).as_rotvec()))
  distance=float(np.linalg.norm(p-ref["position"]))
  return dict(position_error_mm=distance*1000,angle_error_deg=np.degrees(angle),
              tracking_error_mm=max(distance,.03*angle)*1000),p,r
 def transition(self,control,phase,reason,trigger=None):
  if control==self.control and phase==getattr(self,"event_phase",None) and reason==self.reason:return
  event=dict(time_s=float(self.clock()),phase=phase,group=self.group(phase),
             previous_control=self.control,control=control,reason=reason,
             trigger=trigger or {},measurements=dict(self.metrics))
  self.events.append(event);self.control=control;self.reason=reason
  self.trigger=trigger or {};self.event_phase=phase
 def enter_phase(self,phase):
  self.phase=phase;self.phase_start=self.clock();self.mode="policy"
  self.bad_pose=0;self.bad_grip=0;self.window.clear();self.grasp_reference=None;self.measured_grasp=None
  self.pending=[];self.last_observation=None
  self.policy.clear_actions()
 def note_hold(self,phase,seconds):
  self.transition("hold",phase,"接触稳定／保持验证",dict(duration_s=float(seconds)))
 def note_grasp_failure(self,phase,height,width):
  self.pending_failure=dict(reason="提起后未抓牢：物体抬升或夹持宽度不足",
    trigger=dict(height_mm=float(height*1000),required_height_mm=30.,
                 actual_width_mm=float(width*1000),required_width_mm=1.))
  if self.group(phase)!="assembly":
   self.interventions+=1
   self.corrections_by_phase[phase]=self.corrections_by_phase.get(phase,0)+1
  self.transition("teacher_recovery",phase,self.pending_failure["reason"],self.pending_failure["trigger"])
 def note_seat_failure(self,xy,z):
  self.pending_failure=dict(reason="落座几何判定未通过",trigger=dict(ring_xy_error_mm=float(xy*1000),ring_height_m=float(z)))
  self.interventions+=1;self.corrections_by_phase["seat"]=self.corrections_by_phase.get("seat",0)+1
 def correct(self,phase,reason,trigger):
  self.mode="recovery";self.interventions+=1
  self.corrections_by_phase[phase]=self.corrections_by_phase.get(phase,0)+1
  self.transition("teacher_recovery",phase,reason,trigger)
 def recover_motion(self,state,phase,reason,details):
  previous_control=self.control
  trigger=dict(details,previous_control=previous_control)
  if previous_control=="student":
   self.correct(phase,reason,trigger)
  else:
   self.mode="recovery"
   self.transition("teacher_recovery",phase,reason,trigger)
  self.teacher_override=True;self.pending_failure=dict(reason=reason,trigger=trigger)
  self.pending=[];self.policy.clear_actions()
  self.grasp_reference=None;self.measured_grasp=None
  self.recovery_started=float(self.clock());self.close_since=None
  self.motion_recoveries.append(dict(time_s=float(self.clock()),phase=phase,reason=reason,trigger=trigger))
 def snapshot(self):
  return dict(control=self.control,reason=self.reason,trigger=self.trigger,
              last_switch_s=self.events[-1]["time_s"] if self.events else 0.,
              measurements=self.metrics)
 def summary(self):
  groups={g:sum(n for p,n in self.student_by_phase.items() if self.group(p)==g) for g in ("grasp","transport","seating")}
  corrections={g:sum(n for p,n in self.corrections_by_phase.items() if self.group(p)==g) for g in groups}
  eligible=all(n>=6 for n in groups.values()) and sum(corrections.values())>0
  return dict(student_commands_by_phase=self.student_by_phase,student_commands_by_group=groups,
              corrections_by_phase=self.corrections_by_phase,corrections_by_group=corrections,
              measured_interventions=self.interventions,motion_recoveries=self.motion_recoveries,collection_eligible=eligible,
              control_events=self.events,
              intervention_limits_are_safety_limits=False,
              continuation="Teacher completes screw assembly; this is an assisted successful trajectory.")
 def command(self,state,phase,jacobian,images=None,observation=None,observation_id=None,force_expert=False):
  if phase!=self.phase:self.enter_phase(phase)
  ref=self.expert.reference
  if ref["body"] in ("ring","screw") and self.mode=="recovery":
   if self.grasp_reference is not ref["grasp_offset"]:
    self.grasp_reference=ref["grasp_offset"]
    actual=np.asarray(state[ref["body"]])[0];body_rotation=Rotation.from_quat(actual[3:])
    hp,hr=self.expert.fk(np.asarray(state["joints"])[0,:7])
    self.measured_grasp=(body_rotation.inv().apply(np.asarray(hp)-actual[:3]),
                         body_rotation.inv().as_matrix()@np.asarray(hr))
   ref["grasp_offset"],ref["grasp_rotation"]=self.measured_grasp
  self.expert.use_measured_ring_control=True
  self.expert.use_measured_screw_control=self.mode=="recovery" or self.group(phase)!="assembly"
  label=self.expert.query(state)
  self.metrics,p,r=self.pose_metrics(state)
  if ref["body"] is not None:
   hand_position,_=self.expert.fk(np.asarray(state["joints"])[0,:7])
   self.metrics.update(body_position_m=p.tolist(),reference_position_m=np.asarray(ref["position"]).tolist(),hand_body_distance_mm=float(np.linalg.norm(np.asarray(hand_position)-p)*1000),grasp_offset_length_mm=float(np.linalg.norm(ref["grasp_offset"])*1000))
  self.metrics["command_speed_rad_s"]=float(np.max(np.abs(self.expert.limits.velocity)))
  now=float(self.clock());group=self.group(phase)
  if observation_id!=self.last_observation and images is not None:
   self.last_observation=observation_id
   self.pending=list(self.policy.act(images,observation))
  candidate=self.pending.pop(0) if self.pending else None
  source="expert";desired=label
  if group=="assembly" and not self.teacher_override:
   self.transition("teacher_continuation",phase,"教师完成后续螺丝装配；不计学生纠正")
  elif phase in ("lift","level","release","retract") and not self.teacher_override:
   self.transition("teacher_completion",phase,"教师完成抬升／调平／松爪验证；不计学生纠正")
  elif self.teacher_override:
   failure=self.pending_failure or dict(reason="装配检查未通过后的教师重试",trigger={})
   self.transition("teacher_recovery",phase,failure["reason"],failure["trigger"])
   source="recovery"
  elif force_expert:
   self.transition("teacher_completion",phase,"夹爪指令收尾；不计偏差触发纠正")
  else:
   if candidate is None:
    self.transition("teacher_completion",phase,"等待首个学生动作")
   else:
    width_error=abs(float(candidate[7:9].sum()-self.expert.reference["width"]))*1000
    self.metrics["student_width_error_mm"]=width_error
    limit=self.config["seat_tracking_limit_mm"] if group=="seating" else self.config["free_tracking_limit_mm"]
    if phase in ("screw_ring_entry","thread_entry","thread_turn","screw_regrasp_return","screw_regrasp_close"):limit=min(limit,3.)
    self.bad_pose=self.bad_pose+1 if self.metrics["tracking_error_mm"]>limit else 0
    self.bad_grip=self.bad_grip+1 if width_error>self.config["gripper_difference_mm"] else 0
    self.window.append((now,p.copy(),r,self.expert.reference["position"].copy(),Rotation.from_matrix(self.expert.reference["rotation"])))
    while len(self.window)>1 and now-self.window[1][0]>=self.config["stall_window_s"]:self.window.popleft()
    start,oldp,oldr,oldref,oldrefrot=self.window[0]
    progress_mm=max(float(np.linalg.norm(p-oldp))*1000,30*float(np.linalg.norm((r*oldr.inv()).as_rotvec())))
    reference_motion=max(float(np.linalg.norm(self.expert.reference["position"]-oldref))*1000,30*float(np.linalg.norm((Rotation.from_matrix(self.expert.reference["rotation"])*oldrefrot.inv()).as_rotvec())))
    predicted_error=0.;contact_risk=None
    if self.expert.reference["body"] is not None:
     limited=self.expert.limits.preview(candidate)
     cp,cr=self.expert.fk(limited[:7])
     hp,hr=self.expert.fk(np.asarray(state["joints"])[0,:7])
     change=np.asarray(cr)@np.asarray(hr).T
     projected=np.asarray(cp)+change@(p-np.asarray(hp))
     projected_r=Rotation.from_matrix(change)*r
     predicted_error=max(np.linalg.norm(projected-ref["position"]),
       .03*np.linalg.norm((Rotation.from_matrix(ref["rotation"])*projected_r.inv()).as_rotvec()))*1000
     if ref["body"]=="screw" and phase in ("screw_ring_entry","thread_entry","thread_turn"):
      lateral=float(np.linalg.norm(projected[:2]-ref["position"][:2]))
      tilt=float(np.degrees(np.arccos(np.clip(projected_r.as_matrix()[2,2],-1.,1.))))
      approaching_contact=projected[2]<float(self.seat_position[2]+.006)
      if approaching_contact and (lateral>.0006 or tilt>2.):
       contact_risk=dict(predicted_lateral_mm=lateral*1000,predicted_tilt_deg=tilt,
                         lateral_alignment_mm=.6,tilt_alignment_deg=2.)
    elif phase in ("screw_regrasp_return","screw_regrasp_close"):
     limited=self.expert.limits.preview(candidate)
     cp,cr=self.expert.fk(limited[:7])
     predicted_error=max(np.linalg.norm(np.asarray(cp)-ref["position"]),
       .03*np.linalg.norm((Rotation.from_matrix(ref["rotation"])*Rotation.from_matrix(cr).inv()).as_rotvec()))*1000
    self.metrics["predicted_tracking_error_mm"]=float(predicted_error)
    if self.mode=="policy":
     if contact_risk is not None:
      self.correct(phase,"接近孔口时对准误差将增大，教师恢复对准",contact_risk)
     elif predicted_error>limit:
      self.correct(phase,"持物动作预测偏差超出可纠正范围，执行前接管",
       dict(predicted_tracking_error_mm=float(predicted_error),limit_mm=limit))
     elif self.bad_pose>=6:
      self.correct(phase,"位姿跟踪偏差持续超出接管容差",
       dict(tracking_error_mm=self.metrics["tracking_error_mm"],limit_mm=limit,duration_s=self.bad_pose/60.))
     elif (self.bad_grip>=3 if self.expert.reference["body"] is not None else self.bad_grip>=12) and (self.expert.reference["body"] is not None or now-self.phase_start>=.25):
      self.correct(phase,"学生夹爪开度与当前任务需求持续不符",
       dict(width_error_mm=width_error,limit_mm=self.config["gripper_difference_mm"],duration_s=self.bad_grip/60.))
     elif now-start>=self.config["stall_window_s"]-1e-6 and reference_motion<.5 and self.metrics["tracking_error_mm"]>4.:
      self.correct(phase,"最终目标保持不变，但学生未能到位",
       dict(reference_motion_mm=reference_motion,window_s=now-start,tracking_error_mm=self.metrics["tracking_error_mm"],arrival_tolerance_mm=4.))
     elif now-start>=self.config["stall_window_s"]-1e-6 and reference_motion<.5 and self.metrics["command_speed_rad_s"]>.08:
      self.correct(phase,"目标已接近，但关节指令持续未稳定",
       dict(command_speed_rad_s=self.metrics["command_speed_rad_s"],settled_speed_rad_s=.08,window_s=now-start,tracking_error_mm=self.metrics["tracking_error_mm"]))
     elif now-start>=self.config["stall_window_s"]-1e-6 and progress_mm<1.5 and self.metrics["tracking_error_mm"]>4.:
      self.correct(phase,"末端持续停滞，尚未到达当前目标",
       dict(motion_mm=progress_mm,minimum_motion_mm=1.5,window_s=now-start,tracking_error_mm=self.metrics["tracking_error_mm"]))
    if self.mode=="recovery":
     source="recovery"
     if self.control!="teacher_recovery":
      self.transition("teacher_recovery",phase,"教师继续完成本阶段纠正")
    else:
     source="policy";desired=candidate
     self.transition("student",phase,"学生执行；当前阶段尚未触发接管条件")
     self.student_by_phase[phase]=self.student_by_phase.get(phase,0)+1
  executed=self.expert.limits.commit(desired)
  self.counts[source]+=1
  return label,executed,source
