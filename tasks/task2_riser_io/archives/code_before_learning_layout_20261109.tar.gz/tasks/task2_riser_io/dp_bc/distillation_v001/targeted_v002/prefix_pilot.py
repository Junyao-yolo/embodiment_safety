"""Incremental prefix supervision followed by a teacher-free comparison."""
from pathlib import Path
from datetime import datetime
import json,os,subprocess,time,traceback
D=Path(__file__).resolve().parents[2];H=D/"distillation_v001"
OUT=H/"targeted_round002_v001/prefix_pilot_v001"
PY=D.parents[2]/"algos/diffusion_policy/.venv/bin/python"
DATA=H/"targeted_round002_v001/raw"
SOURCE=D/"runs/corrective_only_v001/policy.pt"
TRAIN=D/"runs/targeted_prefix_pilot_v001"
EVAL=D/"evaluations/targeted_prefix_pilot_v001"
start=time.perf_counter()
def state(status,**kw):
 row=dict(status=status,updated_at=datetime.now().isoformat(),wall_s=time.perf_counter()-start,**kw)
 (OUT/"progress.json").write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
def run(command,name):
 state(name,command=[str(x) for x in command])
 env=os.environ.copy();env.update(OMP_NUM_THREADS="2",MKL_NUM_THREADS="2",OPENBLAS_NUM_THREADS="2",PYTHONDONTWRITEBYTECODE="1",CUDA_VISIBLE_DEVICES="0")
 with (OUT/(name+".log")).open("w") as log:
  p=subprocess.Popen([str(x) for x in command],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,cwd=D,env=env)
  (OUT/"active.pid").write_text(str(p.pid));code=p.wait()
 if code:raise RuntimeError(name+" failed; see "+str(OUT/(name+".log")))
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 plan=dict(source_checkpoint=str(SOURCE),data=str(DATA),new_episodes=1,original_demonstrations_loaded=0,
  updates=2000,learning_rate=[1e-5,1e-6],batch_size=16,normalizer="inherited unchanged",
  sampling="50% handoff boundaries, 30% other corrective-phase windows, 20% continuation",
  supervision="contiguous teacher prefixes; padding masked",evaluation_seed=920013,
  evaluation_teacher_enabled=False,student_contract="23 state + 3 RGB; 48 action")
 (OUT/"plan.json").write_text(json.dumps(plan,indent=2))
 run([PY,"-B",H/"targeted_v002/prefix_fit.py","--checkpoint",SOURCE,"--data",DATA,"--output",OUT/"fit_before.json"],"FIT_BEFORE")
 run([PY,"-B",H/"train.py","--corrective-only","--short-corrections","--corrective",DATA,
  "--checkpoint",SOURCE,"--output",TRAIN,"--steps","2000","--learning-rate",".00001",
  "--min-learning-rate",".000001","--warmup-steps","100"],"TRAIN")
 run([PY,"-B",H/"targeted_v002/prefix_fit.py","--checkpoint",TRAIN/"policy.pt","--data",DATA,"--output",OUT/"fit_after.json"],"FIT_AFTER")
 run(["/mnt/data2/isaacsim-5.0.0/python.sh","-B",D/"evaluate_batch.py","--checkpoint",TRAIN/"policy.pt",
  "--output",EVAL,"--seeds","920013","--max-seconds","180","--n-action-steps","8","--policy-device","cuda",
  "--thresholds",D/"runs/opposed100_v001/safety_thresholds.json"],"AUTONOMOUS_EVALUATION")
 evaluations=[json.loads(p.read_text()) for p in sorted(EVAL.glob("trial_*/evaluation.json"))]
 result=dict(training=json.loads((TRAIN/"result.json").read_text()),
  fit_before=json.loads((OUT/"fit_before.json").read_text())["by_role"],
  fit_after=json.loads((OUT/"fit_after.json").read_text())["by_role"],evaluations=evaluations,
  learned_full_task_verified=bool(evaluations) and all(e["task_success"] for e in evaluations))
 (OUT/"result.json").write_text(json.dumps(result,indent=2))
 state("COMPLETE",learned_full_task_verified=result["learned_full_task_verified"],result=str(OUT/"result.json"))
if __name__=="__main__":
 try:main()
 except Exception as exc:
  OUT.mkdir(parents=True,exist_ok=True);state("NEEDS_REPAIR",error=str(exc))
  (OUT/"error.txt").write_text(traceback.format_exc());raise
