"""Measure Task2 training throughput alongside the active Task1 training run."""
from pathlib import Path
import copy,json,time,subprocess,sys,statistics
D=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent/"parallel_probe"
OUT.mkdir(exist_ok=True)
TASK1=D.parents[2]/"outputs/runs/task1/diffusion_policy/parallel_diverse_new_wrist_bc_v001/train/metrics.jsonl"
def task1_rows():
    result=[]
    for line in TASK1.read_text().splitlines()[-1800:]:
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if "step" in r and "elapsed_s" in r:result.append(r)
    return result
def rate(rows):
    ds=[(b["elapsed_s"]-a["elapsed_s"])/(b["step"]-a["step"]) for a,b in zip(rows,rows[1:]) if b["step"]>a["step"]]
    return {"rows":len(rows),"median_seconds_per_step":statistics.median(ds) if ds else None,
            "mean_seconds_per_step":(rows[-1]["elapsed_s"]-rows[0]["elapsed_s"])/(rows[-1]["step"]-rows[0]["step"]) if len(rows)>1 else None}
baseline=task1_rows()[-501:]
result={"status":"PREPARING","baseline_task1":rate(baseline),"baseline_last_step":baseline[-1]["step"],
        "checkpoint_written":False,"scope":"Disposable training updates for throughput measurement only."}
(OUT/"result.json").write_text(json.dumps(result,indent=2))
sys.path.insert(0,str(D))
import numpy as np
import torch
torch.set_num_threads(1)
torch.manual_seed(42)
torch.set_float32_matmul_precision("highest")
from model import build
from interface import CAMERAS
from diffusion_policy.model.diffusion.ema_model import EMAModel
payload=torch.load(D/"runs/opposed100_v002/policy.pt",map_location="cpu",weights_only=False)
model=build(payload["config"])
model.load_state_dict(payload["model"])
model=model.cuda().train()
ema_model=copy.deepcopy(model);ema=EMAModel(ema_model,power=.75)
opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-6)
ep=D/"data/opposed_v002/raw/episode_0189"
x=np.load(ep/"state.npy")
a=np.load(ep/"action.npy").reshape(-1,6,8).copy()
prev=np.concatenate([x[:,15:22,None].transpose(0,2,1),a[:,:-1,:7]],axis=1)
a[:,:,:7]-=prev
ids=np.array([20,35,50,65,80,100,120,150,190,240,300,400,600,800,1100,1500])
oi=ids[:,None]+np.arange(2);ai=ids[:,None]+np.arange(16)
obs={"state":torch.from_numpy(x[oi]).cuda()}
for c in CAMERAS:
    arr=np.load(ep/(c+".npy"),mmap_mode="r")
    obs[c]=torch.from_numpy(np.array(arr[oi])).permute(0,1,4,2,3).float().cuda()/255
batch={"obs":obs,"action":torch.from_numpy(a.reshape(-1,48)[ai]).cuda()}
def update():
    opt.zero_grad(set_to_none=True)
    loss=model.compute_loss(batch)
    if not torch.isfinite(loss):raise RuntimeError("Nonfinite probe loss")
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
    opt.step();ema.step(model)
    with torch.no_grad():
        buffers=dict(model.named_buffers())
        for name,value in ema_model.named_buffers():value.copy_(buffers[name])
    return float(loss.detach())
for _ in range(10):update()
torch.cuda.synchronize()
phases=[]
for name,pause in [("concurrent_unpaced",0.),("concurrent_paced",.12)]:
    start_rows=task1_rows();start_step=start_rows[-1]["step"]
    start=time.perf_counter()
    result.update(status="MEASURING",phase=name)
    (OUT/"result.json").write_text(json.dumps(result,indent=2))
    for _ in range(120):
        update()
        torch.cuda.synchronize()
        if pause:time.sleep(pause)
    wall=time.perf_counter()-start
    end_rows=task1_rows()
    during=[r for r in end_rows if r["step"]>=start_step]
    row={"phase":name,"task2_updates":120,"wall_s":wall,"task2_seconds_per_update":wall/120,
         "task1":rate(during),"task1_start_step":start_step,"task1_end_step":end_rows[-1]["step"],
         "task2_peak_allocated_mib":torch.cuda.max_memory_allocated()/1024**2,
         "gpu":subprocess.check_output(["nvidia-smi","--query-gpu=memory.used,memory.free,utilization.gpu","--format=csv,noheader"],text=True).strip()}
    baseline_rate=result["baseline_task1"]["median_seconds_per_step"]
    row["task1_typical_step_slowdown_fraction"]=row["task1"]["median_seconds_per_step"]/baseline_rate-1.
    phases.append(row);print(json.dumps(row),flush=True)
result.update(status="COMPLETE",phases=phases)
(OUT/"result.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
