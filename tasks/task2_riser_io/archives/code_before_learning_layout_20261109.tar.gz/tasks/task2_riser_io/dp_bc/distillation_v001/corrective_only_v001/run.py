"""Fine-tune Task2 on corrective demonstrations and evaluate autonomous execution."""
from pathlib import Path
from datetime import datetime
import json,os,subprocess,time,traceback
HERE=Path(__file__).resolve().parent
D=HERE.parents[1]
H=D/"distillation_v001"
PY=D.parents[2]/"algos/diffusion_policy/.venv/bin/python"
ISAAC=Path("/mnt/data2/isaacsim-5.0.0/python.sh")
SOURCE=D/"runs/distilled_round001_v001/policy.pt"
TRAIN=D/"runs/corrective_only_v001"
EVAL=D/"evaluations/corrective_only_pilot_v001"
start=time.perf_counter()

def state(status,**fields):
    data=dict(status=status,updated_at=datetime.now().isoformat(),wall_s=time.perf_counter()-start,**fields)
    (HERE/"progress.json").write_text(json.dumps(data,indent=2))
    print(json.dumps(data),flush=True)

def run(command,log,status):
    state(status,command=[str(x) for x in command],log=str(log))
    env=os.environ.copy()
    env.update(OMP_NUM_THREADS="2",MKL_NUM_THREADS="2",OPENBLAS_NUM_THREADS="2",PYTHONDONTWRITEBYTECODE="1",CUDA_VISIBLE_DEVICES="0")
    with log.open("w") as f:
        p=subprocess.Popen([str(x) for x in command],stdout=f,stderr=subprocess.STDOUT,
                           stdin=subprocess.DEVNULL,cwd=str(D),env=env)
        (HERE/"active.pid").write_text(str(p.pid))
        code=p.wait()
    if code:raise RuntimeError(status+" failed; see "+str(log))

def main():
    plan=dict(source_checkpoint=str(SOURCE),corrective_root=str(H/"round_001/raw"),
              training_output=str(TRAIN),old_demonstrations_in_training=0,corrective_episodes=5,
              updates=2000,batch_size=16,learning_rate=[1e-5,1e-6],warmup_updates=100,
              normalization="inherited unchanged",student_inputs="23 state plus three RGB views",
              evaluation_seeds=[920013,189],evaluation_budget_s=360,
              evaluation_teacher_interventions=False,
              task1_coexistence="Existing Task1 processes remain running; training yields 0.12 s per update when active.")
    (HERE/"plan.json").write_text(json.dumps(plan,indent=2))
    run([PY,"-B",HERE/"fit_probe.py","--checkpoint",SOURCE,"--output",HERE/"fit_before.json"],
        HERE/"fit_before.log","MEASURING_CORRECTIVE_FIT_BEFORE")
    run([PY,"-B",H/"train.py","--corrective-only","--corrective",H/"round_001/raw",
         "--checkpoint",SOURCE,"--output",TRAIN,"--steps","2000",
         "--learning-rate","0.00001","--min-learning-rate","0.000001","--warmup-steps","100"],
        HERE/"train.log","TRAINING_CORRECTIVE_ONLY")
    run([PY,"-B",HERE/"fit_probe.py","--checkpoint",TRAIN/"policy.pt","--output",HERE/"fit_after.json"],
        HERE/"fit_after.log","MEASURING_CORRECTIVE_FIT_AFTER")
    run([ISAAC,"-B",D/"evaluate_batch.py","--checkpoint",TRAIN/"policy.pt",
         "--output",EVAL,"--seeds","920013","189","--max-seconds","360","--n-action-steps","8",
         "--policy-device","cuda","--thresholds",D/"runs/opposed100_v001/safety_thresholds.json"],
        HERE/"evaluation.log","AUTONOMOUS_TESTS")
    evaluations=[]
    for p in sorted(EVAL.glob("trial_*/evaluation.json")):
        e=json.loads(p.read_text());r=e["report"]
        evaluations.append(dict(seed=e["seed"],valid_policy_test=e["valid_policy_test"],task_success=e["task_success"],
                                failure_category=e.get("failure_category"),
                                wire_lifted=r.get("wire_lifted"),wire_seated=r.get("wire_seated"),
                                screw_lifted=r.get("screw_lifted"),thread_engagement_verified=r.get("thread_engagement_verified"),
                                demonstration_actions_used=r.get("demonstration_actions_used"),
                                stop_reason=r.get("stop_reason"),video=e.get("video"),result=str(p)))
    before=json.loads((HERE/"fit_before.json").read_text())
    after=json.loads((HERE/"fit_after.json").read_text())
    result=dict(training=json.loads((TRAIN/"result.json").read_text()),fit_before=before["aggregate"],
                fit_after=after["aggregate"],autonomous_tests=evaluations,
                learned_full_task_verified=len(evaluations)==2 and all(e["task_success"] and e["thread_engagement_verified"] for e in evaluations))
    (HERE/"result.json").write_text(json.dumps(result,indent=2))
    state("COMPLETE",result=str(HERE/"result.json"),learned_full_task_verified=result["learned_full_task_verified"])

if __name__=="__main__":
    try:main()
    except Exception as error:
        state("NEEDS_REPAIR",error=str(error))
        (HERE/"error.txt").write_text(traceback.format_exc())
        raise
