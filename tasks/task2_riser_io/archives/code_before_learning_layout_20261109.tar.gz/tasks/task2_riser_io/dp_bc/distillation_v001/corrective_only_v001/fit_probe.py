"""Measure corrective-demo action fit using fixed observations and diffusion noise."""
from pathlib import Path
import argparse,json,sys,time
import numpy as np
import torch
from torch.utils.data import default_collate
D=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(D))
from model import build
from distillation_v001.dataset import DistillationData,BalancedBatches
from distillation_v001.train import task1_active

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--checkpoint",type=Path,required=True)
    ap.add_argument("--output",type=Path,required=True)
    args=ap.parse_args()
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    data=DistillationData(None,D/"distillation_v001/round_001/raw")
    assert len(data.summary)==1 and data.summary[0]["source"]==1
    assert data.summary[0]["episodes"]==5
    sampler=BalancedBatches(data,16,16,42)
    assert sampler.sources==[1]
    for batch in sampler:
        assert all(data.episodes[data.starts[int(i)][0]]["source"]==1 for i in batch)
    selected=[]
    for (episode,phase),ids in data.groups[1].items():
        selected.append((int(ids[len(ids)//2]),phase,data.episodes[episode]["path"]))
    payload=torch.load(args.checkpoint,map_location="cpu",weights_only=False)
    model=build(payload["config"])
    model.load_state_dict(payload["model"])
    model.n_action_steps=8
    model=model.cuda().eval()
    rows=[]
    with torch.inference_mode():
        for start in range(0,len(selected),16):
            cases=selected[start:start+16]
            batch=default_collate([data[i] for i,_,_ in cases])
            obs={k:v.cuda() for k,v in batch["obs"].items()}
            torch.manual_seed(8137+start)
            torch.cuda.manual_seed_all(8137+start)
            predicted=model.predict_action(obs)["action"]
            target=batch["action"][:,1:9].cuda()
            normalized_error=(model.normalizer["action"].normalize(predicted)-
                              model.normalizer["action"].normalize(target)).cpu().numpy()
            error=(predicted-target).cpu().numpy().reshape(len(cases),8,6,8)
            for j,(i,phase,episode) in enumerate(cases):
                rows.append(dict(index=i,phase=phase,episode=episode,
                                 normalized_action_mse=float(np.mean(normalized_error[j]**2)),
                                 arm_mae_rad=float(np.mean(np.abs(error[j,:,:,:7]))),
                                 arm_p95_rad=float(np.quantile(np.abs(error[j,:,:,:7]),.95)),
                                 gripper_mae_mm=float(np.mean(np.abs(error[j,:,:,7]))*1000),
                                 gripper_p95_mm=float(np.quantile(np.abs(error[j,:,:,7]),.95)*1000)))
            if task1_active():time.sleep(.12)
    metrics=["normalized_action_mse","arm_mae_rad","gripper_mae_mm"]
    phases={p:{k:float(np.mean([r[k] for r in rows if r["phase"]==p])) for k in metrics}
            for p in dict.fromkeys(r["phase"] for r in rows)}
    summary=dict(checkpoint=str(args.checkpoint),checkpoint_steps=payload["steps"],
                 kind="in_sample_fixed_observations_and_noise; not autonomous or held-out validation",
                 action_horizon_blocks=8,observation_samples=len(rows),data=data.summary,
                 original_episodes_loaded=0,phases=phases,rows=rows,
                 aggregate={k:float(np.mean([r[k] for r in rows])) for k in metrics})
    args.output.write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in {"rows","phases"}}),flush=True)
if __name__=="__main__":main()
