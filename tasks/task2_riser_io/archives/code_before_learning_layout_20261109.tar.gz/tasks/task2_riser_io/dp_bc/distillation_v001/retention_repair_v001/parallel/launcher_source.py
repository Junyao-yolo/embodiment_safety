"""Two-process Task2 DAgger collection followed by incremental student training."""
from pathlib import Path
from datetime import datetime
import json,os,signal,subprocess,time,traceback
HERE=Path(__file__).resolve().parent
D=HERE.parents[1];H=D/"distillation_v001"
OUT=H/"retention_repair_v001/parallel"
PY=D.parents[2]/"algos/diffusion_policy/.venv/bin/python"
ISAAC=Path("/mnt/data2/isaacsim-5.0.0/python.sh")
SOURCE=D/"runs/targeted_query_pilot_v001/policy.pt"
TRAIN=D/"runs/handback_action4_parallel_v001"
EVAL=D/"evaluations/handback_action4_parallel_v001"
BASE_EPISODES=[H/"handback_round003_v001/raw/episode_920013",H/"retention_repair_v001/probe_960260/raw/episode_960260",H/"retention_repair_v001/probe_960305/raw/episode_960305"]
EVAL_SEEDS=[970000+4*i for i in range(20)]
PLANS=[{'worker_id': 0, 'successes': 3, 'focus_quotas': {'wire': 1, 'screw_pick': 1, 'fastening': 1}, 'seeds': [960203, 960263, 960283, 960204, 960264, 960284, 960211, 960271, 960291, 960212, 960272, 960292]}, {'worker_id': 1, 'successes': 4, 'focus_quotas': {'wire': 1, 'screw_pick': 1, 'fastening': 2}, 'seeds': [960208, 960258, 960308, 960209, 960259, 960309, 960216, 960266, 960316, 960217, 960267, 960317]}]
class AttachedCollector:
 def __init__(self,pid):
  self.pid=pid
 def poll(self):
  try:
   status=Path("/proc")/str(self.pid)/"stat"
   return "EXITED" if status.read_text().rsplit(")",1)[1].split()[0]=="Z" else None
  except FileNotFoundError:
   return "EXITED"
children=[];stop_requested=False;started=time.perf_counter()
def request_stop(signum,frame):
 global stop_requested
 stop_requested=True
signal.signal(signal.SIGTERM,request_stop)
signal.signal(signal.SIGINT,request_stop)
def write_json(path,value):
 pending=path.with_suffix(".tmp")
 pending.write_text(json.dumps(value,ensure_ascii=False,indent=2));pending.replace(path)
def read_json(path,default):
 return json.loads(path.read_text()) if path.exists() else default
def state(status,**kw):
 row=dict(status=status,updated_at=datetime.now().isoformat(),wall_s=time.perf_counter()-started,
          n_action_steps=4,action_block_seconds=.4,target_successes=10,evaluation_trials=20,**kw)
 write_json(OUT/"progress.json",row)
 pipeline=read_json(H/"pipeline_progress.json",{})
 pipeline.update(status=status,updated_at=row["updated_at"],active_collection=status=="COLLECTING",
                 active_training=status=="TRAINING",active_evaluation=status=="AUTONOMOUS_EVALUATION",
                 collection_progress=str(OUT/"progress.json"),checkpoint=str(SOURCE),
                 n_action_steps=4,parallel_workers=2,evaluation_trials=20,evaluation_output=str(EVAL))
 if "completed_successes" in kw:
  pipeline["new_correction_successes"]=kw["completed_successes"]
  pipeline["corrective_episodes"]=kw["completed_successes"]
 evaluation_rows=[read_json(path,{}) for path in EVAL.glob("trial_*/evaluation.json")]
 pipeline["completed_autonomous_tests"]=sum(bool(row.get("valid_policy_test")) for row in evaluation_rows)
 pipeline["complete_successes"]=sum(bool(row.get("task_success")) for row in evaluation_rows)
 pipeline["active_pid"]=kw.get("active_pid",os.getpid() if status not in ("COMPLETE","COLLECTION_INCOMPLETE","NEEDS_REPAIR","STOPPED_BY_USER") else None)
 pipeline["results"]=str(OUT/"result.json")
 pipeline.pop("report",None)
 if "student_updated" in kw:pipeline["student_updated_with_new_collection"]=kw["student_updated"]
 if kw.get("student_updated"):pipeline["checkpoint"]=str(TRAIN/"policy.pt")
 write_json(H/"pipeline_progress.json",pipeline)
 print(json.dumps(row,ensure_ascii=False),flush=True)
def launch(command,logfile,cwd=D):
 env=dict(os.environ,CUDA_VISIBLE_DEVICES="0",OMP_NUM_THREADS="4",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="4",PYTHONDONTWRITEBYTECODE="1")
 with logfile.open("ab",buffering=0) as log:
  child=subprocess.Popen([str(x) for x in command],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL,start_new_session=True)
 children.append(child)
 return child
def stop_children():
 for plan in PLANS:
  root=OUT/("worker_"+str(plan["worker_id"]).zfill(2))
  if root.exists():
   (root/"stop_after_attempt").write_text("Stop requested for parallel DAgger.\n")
   (root/"reset_requested").write_text("Stop requested for parallel DAgger.\n")
 deadline=time.monotonic()+10
 while time.monotonic()<deadline and any(c.poll() is None for c in children):time.sleep(.5)
 for child in children:
  if child.poll() is None:
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
 deadline=time.monotonic()+5
 while time.monotonic()<deadline and any(c.poll() is None for c in children):time.sleep(.5)
 for child in children:
  if child.poll() is None:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
def check_stop():
 if stop_requested or (OUT/"stop_requested").exists():raise InterruptedError("Stopped by user")
def collect_status(workers):
 rows=[];episodes=[str(p) for p in BASE_EPISODES]
 for plan,child,root in workers:
  result=read_json(root/"results.json",[])
  successful=[x for x in result if x.get("saved")]
  episodes.extend(x["raw"] for x in successful)
  progress=read_json(root/"progress.json",{})
  rows.append(dict(worker_id=plan["worker_id"],pid=child.pid,process_running=child.poll() is None,
    exit_code=None if isinstance(child,AttachedCollector) else child.poll(),
    status=progress.get("status","STARTING"),attempts=len(result),successes=len(successful),
    target_successes=plan["successes"],phase=progress.get("measurements",{}).get("phase"),
    simulation_time_s=progress.get("measurements",{}).get("time_s"),
    progress=str(root/"progress.json"),last_error=result[-1].get("error") if result else None))
 return rows,episodes
def run_stage(command,name,student_updated):
 child=launch(command,OUT/(name.lower()+".log"))
 while child.poll() is None:
  check_stop()
  state(name,completed_successes=10,student_updated=student_updated,active_pid=child.pid,command=[str(x) for x in command])
  for _ in range(10):time.sleep(1);check_stop()
 if child.returncode:raise RuntimeError(name+" failed; see "+str(OUT/(name.lower()+".log")))
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 existing_pids=read_json(OUT/"worker_pids.json",{})
 for episode in BASE_EPISODES:
  if not read_json(episode/"result.json",{}).get("accepted"):raise RuntimeError("Correction is not accepted: "+str(episode))
 assert not set(PLANS[0]["seeds"]) & set(PLANS[1]["seeds"])
 plan=dict(n_action_steps=4,action_block_seconds=.4,checkpoint=str(SOURCE),previous_successes=[str(p) for p in BASE_EPISODES],
  workers=PLANS,target_successes=10,additional_successes=7,training_steps=2000,
  evaluation_trials=20,evaluation_seeds=EVAL_SEEDS,evaluation_teacher_intervention=False,
  evaluation_max_simulation_seconds=180,evaluation_output=str(EVAL),
  original_demonstrations_reloaded=False,training_source="current student checkpoint plus accepted corrections",
  acceptance="Complete released assembly and measured thread engagement; numerical forces recorded separately",
  student_input="23 state dimensions and three 128x128 RGB cameras",action_dim=48)
 write_json(OUT/"plan.json",plan)
 (OUT/"launcher_source.py").write_text(Path(__file__).read_text())
 workers=[]
 for item in PLANS:
  root=OUT/("worker_"+str(item["worker_id"]).zfill(2));root.mkdir(exist_ok=True)
  command=[ISAAC,"-u",HERE/"collect_handback.py","--output",root,"--checkpoint",SOURCE,
   "--successes",item["successes"],"--n-action-steps",4,"--worker-id",item["worker_id"],
   "--focus-quotas",json.dumps(item["focus_quotas"]),"--seeds",*item["seeds"]]
  pid=existing_pids.get(str(item["worker_id"]))
  attached=AttachedCollector(pid) if pid is not None else None
  completed=sum(bool(row.get("saved")) for row in read_json(root/"results.json",[]))
  if attached is not None and (attached.poll() is None or completed>=item["successes"]):
   child=attached;children.append(child)
  else:
   child=launch(command,root/"launcher.log")
  (root/"launcher_pid").write_text(str(child.pid)+"\n")
  workers.append((item,child,root))
 write_json(OUT/"worker_pids.json",{str(plan["worker_id"]):child.pid for plan,child,root in workers})
 while True:
  check_stop();rows,episodes=collect_status(workers)
  state("COLLECTING",workers=rows,completed_successes=len(episodes),new_successes=len(episodes)-len(BASE_EPISODES),student_updated=False)
  if all(child.poll() is not None for _,child,_ in workers):break
  for _ in range(10):time.sleep(1);check_stop()
 rows,episodes=collect_status(workers)
 write_json(OUT/"accepted_episodes.json",episodes)
 if len(episodes)<10:
  state("COLLECTION_INCOMPLETE",workers=rows,completed_successes=len(episodes),new_successes=len(episodes)-len(BASE_EPISODES),student_updated=False)
  return
 data=OUT/"accepted_raw";data.mkdir(exist_ok=True)
 for episode in episodes:
  source=Path(episode)
  if not (data/source.name).exists():(data/source.name).symlink_to(source,target_is_directory=True)
 if not (OUT/"fit_before.json").exists():
  run_stage([PY,"-B",HERE/"prefix_fit.py","--checkpoint",SOURCE,"--data",data,"--output",OUT/"fit_before.json"],"FIT_BEFORE",False)
 if not (TRAIN/"result.json").exists():
  run_stage([PY,"-B",H/"train.py","--corrective-only","--short-corrections","--corrective",data,
     "--checkpoint",SOURCE,"--output",TRAIN,"--steps",2000,"--learning-rate",.00001,
     "--min-learning-rate",.000001,"--warmup-steps",100],"TRAINING",False)
 if not (OUT/"fit_after.json").exists():
  run_stage([PY,"-B",HERE/"prefix_fit.py","--checkpoint",TRAIN/"policy.pt","--data",data,"--output",OUT/"fit_after.json"],"FIT_AFTER",True)
 run_stage([ISAAC,"-B",D/"evaluate_batch.py","--checkpoint",TRAIN/"policy.pt","--output",EVAL,
  "--seeds",*EVAL_SEEDS,"--max-seconds",180,"--n-action-steps",4,"--policy-device","cuda",
  "--thresholds",D/"runs/opposed100_v001/safety_thresholds.json"],"AUTONOMOUS_EVALUATION",True)
 evaluations=[read_json(p,{}) for p in sorted(EVAL.glob("trial_*/evaluation.json"))]
 if len(evaluations)!=len(EVAL_SEEDS) or not all(e.get("valid_policy_test") for e in evaluations):
  raise RuntimeError("Expected 20 valid autonomous tests; see "+str(EVAL))
 summary=read_json(EVAL/"summary.json",{})
 result=dict(completed_successes=len(episodes),checkpoint=str(TRAIN/"policy.pt"),
  training=read_json(TRAIN/"result.json",{}),evaluations=evaluations,
  evaluation_trials=len(evaluations),evaluation_summary=summary,
  learned_full_task_verified=bool(evaluations) and all(e.get("task_success",False) for e in evaluations))
 write_json(OUT/"result.json",result)
 subprocess.run([str(PY),"-B",str(HERE/"summarize_round.py")],check=True)
 state("COMPLETE",completed_successes=len(episodes),student_updated=True,learned_full_task_verified=result["learned_full_task_verified"])
if __name__=="__main__":
 try:main()
 except InterruptedError:
  stop_children()
  state("STOPPED_BY_USER",student_updated=(TRAIN/"policy.pt").exists())
 except Exception as exc:
  stop_children()
  if OUT.exists():
   (OUT/"error.txt").write_text(traceback.format_exc())
   state("NEEDS_REPAIR",error=str(exc),student_updated=(TRAIN/"policy.pt").exists())
  raise
