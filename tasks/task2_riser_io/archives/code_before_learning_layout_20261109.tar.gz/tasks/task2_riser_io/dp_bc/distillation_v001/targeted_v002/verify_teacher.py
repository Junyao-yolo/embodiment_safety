"""Full teacher control verification on a previously completed Task2 initial state."""
from pathlib import Path
import argparse,json,sys,time
HERE=Path(__file__).resolve().parent
D=HERE.parents[1];R=D.parent
sys.path.insert(0,str(HERE));sys.path.insert(0,str(D))
from collect_handback import make_source
from handback import HandbackRouter
class TeacherRouter(HandbackRouter):
 def __init__(self,*args,seat_position=None,**kwargs):super().__init__(*args,**kwargs)
 def group(self,phase):return "assembly"
 @property
 def path_recovery_active(self):return False
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--seed",type=int,default=920013);args=ap.parse_args()
 out=D/"distillation_v001"/"teacher_verification_v001"
 out.mkdir(exist_ok=True)
 status=dict(status="STARTING",seed=args.seed,teacher_only=True)
 def save(**kw):
  status.update(kw);(out/"progress.json").write_text(json.dumps(status,ensure_ascii=False,indent=2))
 save()
 source=make_source().replace("  from held_body_feedback import HeldBodyFeedbackExpert as FeedbackExpert","  from feedback import FeedbackExpert")
 (out/"executed_source.py").write_text(source)
 from isaacsim import SimulationApp
 app=SimulationApp({"headless":True,"limit_cpu_threads":4,"width":128,"height":128,"sync_loads":True,"extra_args":["--/log/file="+str(out/"kit.log")]})
 from recorder_handback import AnnotatedRecorder
 cfg=dict(method="dagger",randomize=True,checkpoint=str(D/"runs/targeted_query_pilot_v001/policy.pt"),
          policy_device="cuda",n_action_steps=8,fixed_noise=True,noise_mm_s=0.,save_failed_video=False,
          free_tracking_limit_mm=12.,seat_tracking_limit_mm=6.,gripper_difference_mm=12.,stall_window_s=.8,focus_set="wire")
 thresholds=json.loads((D/"runs/opposed100_v001/safety_thresholds.json").read_text())
 recorder=AnnotatedRecorder(out,args.seed,thresholds,label="Task2 教师完整执行验证")
 ns=dict(__name__="__main__",_collection_config=cfg,_episode_root=out/"raw",
         _diagnostics_root=out/"diagnostics",_simulation_app=app,_scene_session={},_trial_recorder=recorder,
         _kit_log=out/"kit.log",TargetedRouter=TeacherRouter,_runtime_metadata={"purpose":"teacher_only_full_task_validation"})
 def progress(row,perf):save(status="RUNNING",measurements=row,performance=perf)
 ns["_progress_callback"]=progress
 sys.argv=[str(R/"scripts/run_dp_bc.py"),"--seed",str(args.seed),"--record"]
 try:
  exec(compile(source,str(R/"scripts/run_dp_bc.py"),"exec"),ns)
  result=ns["report"];result.update(validation_kind="teacher_only",student_autonomous_success=False)
  (out/"result.json").write_text(json.dumps(result,ensure_ascii=False,indent=2));recorder.finish(result)
  if not result.get("accepted",False):(out/"rollout.mp4").unlink(missing_ok=True)
  save(status="COMPLETE",teacher_full_success=bool(result.get("accepted")),error=result.get("error"))
 finally:app.close()
if __name__=="__main__":main()
