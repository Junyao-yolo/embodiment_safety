"""Measured held-body pose feedback for Task2 corrective collection."""
import numpy as np
from scipy.spatial.transform import Rotation
from feedback import FeedbackExpert

class HeldBodyFeedbackExpert(FeedbackExpert):
 def query(self,state):
  ref=self.reference
  if ref is None or ref["body"] is None:return super().query(state)
  enabled=(getattr(self,"use_measured_ring_control",False) if ref["body"]=="ring" else getattr(self,"use_measured_screw_control",False))
  if not enabled:return super().query(state)
  actual=np.asarray(state[ref["body"]])[0]
  previous=self.limits.previous
  hp,hr=self.fk(previous[:7]);hp=np.asarray(hp);hr=np.asarray(hr)
  gain=1.-np.exp(-(10. if ref["body"]=="screw" else 6.)/self.limits.hz)
  dp=gain*(ref["position"]-actual[:3])
  dp*=min(1.,(self.linear_m_s/self.limits.hz)/max(np.linalg.norm(dp),1e-12))
  angle=gain*(Rotation.from_matrix(ref["rotation"])*Rotation.from_quat(actual[3:]).inv()).as_rotvec()
  angle*=min(1.,(self.angular_rad_s/self.limits.hz)/max(np.linalg.norm(angle),1e-12))
  dr=Rotation.from_rotvec(angle).as_matrix()
  position=hp+dp+(dr-np.eye(3))@(hp-actual[:3]);rotation=Rotation.from_matrix(dr@hr)
  measured_p,measured_r=self.fk(np.asarray(state["joints"])[0,:7])
  displacement=position-np.asarray(measured_p)
  travel_limit=max(.006,2.*self.linear_m_s/self.limits.hz)
  displacement*=min(1.,travel_limit/max(np.linalg.norm(displacement),1e-12))
  rotation_error=(rotation*Rotation.from_matrix(measured_r).inv()).as_rotvec()
  rotation_error*=min(1.,.1/max(np.linalg.norm(rotation_error),1e-12))
  rotation=Rotation.from_rotvec(rotation_error)*Rotation.from_matrix(measured_r)
  target=previous.copy()
  target[:7]=self.solve(np.asarray(measured_p)+displacement,rotation.as_quat(),previous[:7])
  target[7:9]=ref["width"]/2
  return self.limits.preview(target)
