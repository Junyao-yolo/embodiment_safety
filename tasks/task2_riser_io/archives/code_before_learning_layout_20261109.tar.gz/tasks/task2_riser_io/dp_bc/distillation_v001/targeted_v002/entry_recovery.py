"""Contact-entry recovery using withdrawal, axis alignment and reinsertion."""
from collections import deque
import numpy as np
from scipy.spatial.transform import Rotation
from handback import HandbackRouter
class EntryRecoveryRouter(HandbackRouter):
 def __init__(self,*args,seat_position=None,**kwargs):
  super().__init__(*args,**kwargs)
  self.seat_position=np.asarray(seat_position,dtype=float)
  self.entry_path=None;self.entry_attempted=False;self.entry_bad_since=None
  self.entry_events=[];self.entry_history=deque()
 @property
 def path_recovery_active(self):return self.entry_path is not None
 def enter_phase(self,phase):
  super().enter_phase(phase)
  self.entry_path=None;self.entry_attempted=False;self.entry_bad_since=None;self.entry_history.clear()
 def transition(self,control,phase,reason,trigger=None):
  if getattr(self,"entry_path",None) is not None:
   control="teacher_recovery";reason="孔口恢复："+{"withdraw":"退出接触","align":"上方对正轴线","insert":"重新下探"}[self.entry_path["stage"]]
   trigger=self.entry_path["trigger"]
  return super().transition(control,phase,reason,trigger)
 def command(self,state,phase,jacobian,images=None,observation=None,observation_id=None,force_expert=False):
  if phase!=self.phase:self.enter_phase(phase)
  ref=self.expert.reference;now=float(self.clock())
  if phase=="thread_turn" and ref["body"]=="screw" and self.group(phase)!="assembly":
   reference_rotation=np.asarray(ref["rotation"])
   yaw=float(np.arctan2(reference_rotation[1,0],reference_rotation[0,0]))
   ref["rotation"]=Rotation.from_euler("z",yaw).as_matrix()
   ref["position"][:2]=self.seat_position[:2]
  entry=phase in ("screw_ring_entry","thread_entry") and ref["body"]=="screw"
  if entry:
   actual=np.asarray(state["screw"])[0];rot=Rotation.from_quat(actual[3:]);axis=rot.apply([0.,0.,1.])
   tilt=float(np.degrees(np.arccos(np.clip(axis[2],-1.,1.))))
   yaw=float(np.arctan2(rot.as_matrix()[1,0],rot.as_matrix()[0,0]))
   upright=np.asarray(ref["rotation"]).copy()
   self.entry_history.append((now,actual[:3].copy()))
   while len(self.entry_history)>1 and now-self.entry_history[1][0]>=.8:self.entry_history.popleft()
   elapsed=now-self.entry_history[0][0]
   motion=float(np.linalg.norm(actual[:3]-self.entry_history[0][1]))*1000
   contacts=int(np.asarray(state["screw_contacts"][4]).sum())
   xy=float(np.linalg.norm(actual[:2]-self.seat_position[:2]))*1000
   z_error=abs(float(actual[2]-ref["position"][2]))*1000
   stalled_contact=contacts>0 and elapsed>=.8-1e-6 and motion<1.5 and (tilt>4. or xy>2. or z_error>3.)
   if self.entry_path is None and not self.entry_attempted and stalled_contact:
    trigger=dict(contact_count=contacts,axis_tilt_deg=tilt,xy_error_mm=xy,
                 axial_tracking_error_mm=z_error,motion_mm=motion,window_s=elapsed,
                 previous_control=self.control)
    self.entry_attempted=True
    self.entry_path=dict(stage="withdraw",clear_z=max(float(actual[2]),float(self.seat_position[2]+.020)),
                        withdraw_xy=actual[:2].copy(),withdraw_rotation=rot.as_matrix(),trigger=trigger)
    self.entry_events.append(dict(time_s=now,phase=phase,event="start",trigger=trigger))
    if self.control=="student":self.correct(phase,"孔口接触后持续停滞，需要退出重新对准",trigger)
    else:self.mode="recovery";self.recovery_started=now;self.close_since=None
   if self.entry_path is not None:
    path=self.entry_path
    if path["stage"]=="withdraw" and actual[2]>=path["clear_z"]-.001:
     self.grasp_reference=None;self.measured_grasp=None
     path["stage"]="align";self.entry_events.append(dict(time_s=now,phase=phase,event="align"))
    if path["stage"]=="align" and xy<1. and tilt<1.:
     self.grasp_reference=None;self.measured_grasp=None
     path["stage"]="insert";self.entry_events.append(dict(time_s=now,phase=phase,event="insert"))
    goal_z=float(self.seat_position[2]-(.0015 if phase=="screw_ring_entry" else .006))
    if path["stage"]=="insert" and xy<1. and abs(actual[2]-goal_z)<.001 and tilt<2.:
     self.entry_events.append(dict(time_s=now,phase=phase,event="complete",position=actual[:3].tolist(),axis_tilt_deg=tilt))
     self.entry_path=None;self.close_since=None
    else:
     if path["stage"]=="withdraw":
      ref["position"]=np.r_[path["withdraw_xy"],path["clear_z"]];ref["rotation"]=path["withdraw_rotation"]
     elif path["stage"]=="align":
      ref["position"]=np.r_[self.seat_position[:2],path["clear_z"]];ref["rotation"]=upright
     else:
      ref["position"]=np.r_[self.seat_position[:2],goal_z];ref["rotation"]=upright
     self.expert.set_motion_limits(min(self.expert.linear_m_s,.030),min(self.expert.angular_rad_s,1.2))
  active=self.path_recovery_active
  label,executed,source=super().command(state,phase,jacobian,images,observation,observation_id,force_expert or active)
  if active and source!="recovery":
   self.counts[source]-=1;self.counts["recovery"]+=1;source="recovery"
  return label,executed,source
 def recover_motion(self,state,phase,reason,details):
  super().recover_motion(state,phase,reason,details)
  if phase in ("screw_ring_entry","thread_entry") and self.entry_path is None:
   actual=np.asarray(state["screw"])[0];rotation=Rotation.from_quat(actual[3:]).as_matrix()
   self.entry_attempted=True
   self.entry_path=dict(stage="withdraw",clear_z=max(float(actual[2]),float(self.seat_position[2]+.020)),
                       withdraw_xy=actual[:2].copy(),withdraw_rotation=rotation,trigger=dict(details,timeout_recovery=True))
   self.entry_events.append(dict(time_s=float(self.clock()),phase=phase,event="timeout_withdraw",trigger=details))
 def summary(self):
  result=super().summary()
  result["contact_entry_recoveries"]=self.entry_events
  result["entry_orientation_goal"]="board-normal shaft axis with the authored thread entry orientation"
  return result
