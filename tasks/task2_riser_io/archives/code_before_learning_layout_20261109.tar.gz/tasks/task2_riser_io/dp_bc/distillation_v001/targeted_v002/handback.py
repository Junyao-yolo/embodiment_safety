"""Short expert interventions with explicit return to the student."""
import numpy as np
from router import TargetedRouter,GROUPS

FOCUS_PHASES={
 "wire":{"approach","descend","grasp","transport","seat"},
 "screw_pick":{"screw_approach","screw_descend","screw_grasp","screw_lift","screw_transport","screw_align"},
 "fastening":{"screw_ring_entry","thread_entry","thread_turn","screw_regrasp_open","screw_regrasp_return","screw_regrasp_close","preload_release","screw_release","screw_retract"},
}
class HandbackRouter(TargetedRouter):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  self.focus=self.config["focus_set"];self.recovery_started=0.;self.close_since=None
  self.phase_corrections=0;self.handback_note=None;self.handbacks=[];self.fallbacks=[]
  seed=int(args[2] if len(args)>2 else kwargs["seed"])
  self.fastening_window=("entry_turn","regrasp","entry")[seed%3]
  self.window_phases={"entry_turn":{"screw_ring_entry","thread_entry","thread_turn"},
                      "regrasp":{"screw_regrasp_open","screw_regrasp_return","screw_regrasp_close"},
                      "entry":{"screw_ring_entry","thread_entry"}}[self.fastening_window]
  self.focus_window_started=False;self.focus_window_complete=False
  self.focused_phases_seen=set()
 def group(self,phase):
  focus=getattr(self,"focus",self.config.get("focus_set","wire"))
  phases=getattr(self,"window_phases",FOCUS_PHASES[focus]) if focus=="fastening" else FOCUS_PHASES[focus]
  if phase not in phases or (focus=="fastening" and getattr(self,"focus_window_complete",False)):return "assembly"
  return GROUPS.get(phase,"fastening")
 def enter_phase(self,phase):
  if self.focus=="fastening":
   if phase in self.window_phases and not self.focus_window_complete:
    self.focus_window_started=True;self.focused_phases_seen.add(phase)
   elif self.focus_window_started:self.focus_window_complete=True
  super().enter_phase(phase)
  self.phase_corrections=0;self.close_since=None;self.handback_note=None
 def correct(self,phase,reason,trigger):
  super().correct(phase,reason,trigger)
  self.recovery_started=float(self.clock());self.phase_corrections+=1
  self.grasp_reference=None;self.measured_grasp=None
  self.close_since=None;self.handback_note=None
  if self.phase_corrections>=3:
   self.fallbacks.append(dict(phase=phase,time_s=float(self.clock()),reason="Three interventions within one phase; teacher finishes this phase"))
   self.reason+="；本阶段已连续接管3次，由教师完成本段"
   self.events[-1]["reason"]=self.reason
 def transition(self,control,phase,reason,trigger=None):
  if control=="teacher_continuation":
   reason="教师执行本条目标阶段之外的装配步骤；不计学生纠正"
  if control=="student" and getattr(self,"handback_note",None):
   reason="教师纠正后交回学生，继续当前步骤"
   trigger=self.handback_note
  return super().transition(control,phase,reason,trigger)
 def command(self,state,phase,jacobian,images=None,observation=None,observation_id=None,force_expert=False):
  now=float(self.clock())
  if (phase==self.phase and self.mode=="recovery" and not self.teacher_override
      and not force_expert and self.phase_corrections<3):
   error=float(self.expert.tracking_error(state))
   width_error=abs(float(self.expert.limits.previous[7:9].sum())-self.expert.reference["width"])
   tolerance=.0015 if phase in ("screw_ring_entry","thread_entry","thread_turn") else (.003 if self.group(phase) in ("seating","fastening") else .005)
   reference_stationary=bool(self.window and now-self.window[0][0]>=.25 and
     np.linalg.norm(self.expert.reference["position"]-self.window[0][3])<.0005)
   command_settled=float(np.max(np.abs(self.expert.limits.velocity)))<=.08
   close=error<=tolerance and width_error<=.003 and (not reference_stationary or command_settled)
   if close and self.close_since is None:self.close_since=now
   if not close:self.close_since=None
   stable=now-self.close_since if self.close_since is not None else 0.
   if (stable>=.1 and now-self.recovery_started>=.35 and images is not None
       and observation_id!=self.last_observation):
    note=dict(tracking_error_mm=error*1000,return_tolerance_mm=tolerance*1000,
              gripper_command_error_mm=width_error*1000,stable_s=stable,
              teacher_duration_s=now-self.recovery_started)
    self.mode="policy";self.pending=[];self.policy.clear_actions()
    self.bad_pose=0;self.bad_grip=0;self.window.clear();self.handback_note=note
    self.handbacks.append(dict(time_s=now,phase=phase,condition=note))
  ref=self.expert.reference
  if (self.mode=="policy" and ref["body"] in ("ring","screw") and self.measured_grasp is not None
      and self.grasp_reference is ref["grasp_offset"]):
   ref["grasp_offset"],ref["grasp_rotation"]=self.measured_grasp
  return super().command(state,phase,jacobian,images,observation,observation_id,force_expert)
 def summary(self):
  result=super().summary()
  focused=sum(self.student_by_phase.values())
  returns=[]
  for h in self.handbacks:
   end=next((e["time_s"] for e in self.events if e["time_s"]>h["time_s"]+1e-9 and
             (e["control"]!="student" or e["phase"]!=h["phase"])),float(self.clock()))
   returns.append(dict(**h,student_after_return_s=max(0.,end-h["time_s"])))
  qualifying=[r for r in returns if r["student_after_return_s"]>=.1]
  if self.focus!="wire":
   result["student_commands_by_group"][self.focus]=focused
   result["corrections_by_group"][self.focus]=sum(self.corrections_by_phase.values())
  result.update(focus_set=self.focus,focus_phases=sorted(self.window_phases if self.focus=="fastening" else FOCUS_PHASES[self.focus]),
   fastening_window=self.fastening_window if self.focus=="fastening" else None,
   focus_window_completed=self.focus_window_complete,focused_phases_seen=sorted(self.focused_phases_seen),
   teacher_handbacks=returns,qualifying_handbacks=len(qualifying),teacher_completed_after_repeated_failures=self.fallbacks,
   student_focus_commands=focused,
   collection_eligible=focused>=30 and self.interventions>=1 and bool(qualifying),
   continuation="Teacher handles non-focus stages; student attempts focus stages and resumes after short corrections.",
   autonomous_stage_success_claimed=False)
  return result
