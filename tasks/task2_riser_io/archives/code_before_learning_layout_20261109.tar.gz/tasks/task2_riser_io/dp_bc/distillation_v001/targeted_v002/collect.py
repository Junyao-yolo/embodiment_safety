"""Collect complete targeted DAgger corrections in one Isaac Sim session."""
from pathlib import Path
import argparse,gc,json,sys,time,traceback
import numpy as np
HERE=Path(__file__).resolve().parent
D=HERE.parents[1];R=D.parent
sys.path.insert(0,str(D));sys.path.insert(0,str(HERE))
from router import TargetedRouter

def replace(source,old,new):
 if source.count(old)!=1:raise RuntimeError("Expected one collection hook: "+old[:100])
 return source.replace(old,new,1)

def make_source():
 source=(R/"scripts/run_dp_bc.py").read_text()
 source=replace(source,"router=RecoveryRouter(expert,collection_config,args.seed,policy_client)",
  "router=TargetedRouter(expert,collection_config,args.seed,policy_client,clock=lambda:stepnum*dt)")
 source=replace(source,"   records.append(rec)",
  "   rec['control']=router.snapshot() if router is not None else {}\n   _trial_recorder.measure(rec,latest,sensor,ci,si,tr,target)\n   records.append(rec)")
 source=replace(source,"  image_frames.append(images)","  _trial_recorder.frame(images,rec)\n  image_frames.append(images)")
 source=replace(source,"  # Preserve physical verification time; no artificial nonzero action.",
  "  if router is not None:router.note_hold(phase,seconds)\n  # Preserve physical verification time; no artificial nonzero action.")
 source=replace(source,'    report.setdefault("grasp_retries",[]).append',
  '    if router is not None:router.note_grasp_failure(phase,height,blocked_width)\n    report.setdefault("grasp_retries",[]).append')
 source=replace(source," if not ring_on_seat(records[-1],target,assembly_geometry):\n  override=",
  " if not ring_on_seat(records[-1],target,assembly_geometry):\n  if router is not None:router.note_seat_failure(np.linalg.norm(rv.get_transforms()[0,:2]-target[:2]),rv.get_transforms()[0,2])\n  override=")
 source=replace(source,'  completion=.006 if phase=="thread_turn" else .002',
  '  completion=.006 if phase=="thread_turn" else (.005 if phase in ("approach","descend") else .002)')
 source=replace(source,"  tracker=MotionProgress(steps,settle_steps,completion_error=completion)",
  "  tracker=MotionProgress(steps,settle_steps,completion_error=completion)\n  tracker.budget+=480")
 source=replace(source," if report.get('accepted',False) and args.record:",
  " if router is not None:report['correction_coverage']=router.summary()\n if report.get('accepted',False) and report.get('correction_coverage',{}).get('collection_eligible',False) and args.record:")
 compile(source,str(R/"scripts/run_dp_bc.py"),"exec")
 return source

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--checkpoint",type=Path,default=D/"runs/corrective_only_v001/policy.pt")
 ap.add_argument("--output",type=Path,default=D/"distillation_v001/targeted_round002_v001")
 ap.add_argument("--successes",type=int,default=10);ap.add_argument("--max-attempts",type=int,default=30)
 ap.add_argument("--check-source",action="store_true");args=ap.parse_args()
 source=make_source()
 if args.check_source:print("Collection hooks and Python syntax valid");return
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
 raw=out/"raw";raw.mkdir(exist_ok=True)
 started=time.perf_counter()
 config=dict(method="dagger",randomize=True,checkpoint=str(args.checkpoint.resolve()),policy_device="cuda",
  n_action_steps=8,fixed_noise=True,noise_mm_s=0.,save_failed_video=False,
  free_tracking_limit_mm=12.,seat_tracking_limit_mm=6.,gripper_difference_mm=12.,stall_window_s=.8,
  policy_schedule="student starts each wire subphase; after measured trigger teacher completes that subphase",
  screw_schedule="teacher continuation, excluded from measured correction count")
 (out/"collection.json").write_text(json.dumps(config,indent=2))
 (out/"executed_collection_source.py").write_text(source)
 status=dict(status="STARTING",completed_successes=0,target_successes=args.successes)
 def write_status(**kw):
  status.update(kw,wall_s=time.perf_counter()-started)
  (out/"progress.json").write_text(json.dumps(status,ensure_ascii=False,indent=2))
 write_status()
 from isaacsim import SimulationApp
 app=SimulationApp({"headless":True,"limit_cpu_threads":4,"width":128,"height":128,"sync_loads":True,
                    "extra_args":["--/log/file="+str(out/"kit.log")]})
 from recorder import AnnotatedRecorder
 session={};results=json.loads((out/"results.json").read_text()) if (out/"results.json").exists() else []
 successes=sum(bool(r["saved"]) for r in results)
 thresholds=json.loads((D/"runs/opposed100_v001/safety_thresholds.json").read_text())
 seeds=[920005,920008,920013,920014,920016]+[950000+5*i for i in range(max(0,args.max_attempts-5))]
 attempted={r["seed"] for r in results if r["saved"]}
 try:
  for seed in seeds:
   if (out/"stop_after_attempt").exists():
    write_status(status="STOPPED_AFTER_ATTEMPT");return
   if seed in attempted:continue
   if successes>=args.successes:break
   index=max([int(p.name.split("_")[0]) for p in (out/"trials").glob("*") if p.is_dir()]+[-1])+1
   trial=out/"trials"/f"{index:03d}_corrective_{seed}"
   trial.mkdir(parents=True,exist_ok=False)
   recorder=AnnotatedRecorder(trial,seed,thresholds,label="Task2 targeted correction")
   ns=dict(__name__="__main__",_collection_config=dict(config),_episode_root=raw,
    _diagnostics_root=trial/"diagnostics",_reset_request=out/"reset_requested",
    _simulation_app=app,_scene_session=session,_trial_recorder=recorder,
    _kit_log=out/"kit.log",TargetedRouter=TargetedRouter,
    _runtime_metadata={"persistent":True,"worker_id":0,"purpose":"targeted_teacher_corrections"})
   write_status(status="RUNNING",seed=seed,trial=str(trial),completed_successes=successes)
   def progress(row,perf):
    controller=ns.get("router")
    write_status(measurements=row,performance=perf,control=controller.snapshot() if controller else {})
   ns["_progress_callback"]=progress
   sys.argv=[str(R/"scripts/run_dp_bc.py"),"--seed",str(seed),"--record"]
   before=time.perf_counter()
   exec(compile(source,str(R/"scripts/run_dp_bc.py"),"exec"),ns)
   report=ns["report"]
   report.update(validation_kind="targeted_correction",teacher_enabled=True,student_autonomous_success=False)
   coverage=report.get("correction_coverage",{})
   saved=bool(report.get("accepted") and coverage.get("collection_eligible"))
   report["saved_for_training"]=saved
   (trial/"result.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
   recorder.finish(report)
   result=dict(seed=seed,accepted=bool(report.get("accepted")),saved=saved,
    thread_engagement_verified=bool(report.get("thread_engagement_verified")),
    student_commands_by_group=coverage.get("student_commands_by_group",{}),
    corrections_by_group=coverage.get("corrections_by_group",{}),
    error=report.get("error"),wall_s=time.perf_counter()-before,trial=str(trial),
    raw=str(raw/f"episode_{seed:04d}") if saved else None,
    video=str(trial/"rollout.mp4") if saved else None)
   results.append(result)
   if saved:
    successes+=1
    if not (out/"first_success.json").exists():
     (out/"first_success.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print("ACCEPTED_CORRECTION",json.dumps(result),flush=True)
   else:
    (trial/"rollout.mp4").unlink(missing_ok=True)
   (out/"results.json").write_text(json.dumps(results,ensure_ascii=False,indent=2))
   render_setup=ns.get("setup_render")
   render={k:getattr(render_setup,k) for k in ("anns","products","paths","manifest")} if hasattr(render_setup,"anns") else {}
   ns["sim"].stop()
   session=dict(sim=ns["sim"],initial_transforms=ns["initial_transforms"],
                assembly_geometry=ns["assembly_geometry"],render=render)
   ns["view"].invalidate()
   ns.clear();del recorder,render_setup;gc.collect()
   write_status(completed_successes=successes,last_result=result)
  if successes<args.successes:raise RuntimeError("Target not reached within attempt budget")
  write_status(status="COMPLETE",completed_successes=successes)
 except Exception as exc:
  write_status(status="NEEDS_REPAIR",error=str(exc))
  (out/"error.txt").write_text(traceback.format_exc());raise
 finally:
  for ann in session.get("render",{}).get("anns",{}).values():ann.detach()
  for product in session.get("render",{}).get("products",[]):product.destroy()
  app.close()
if __name__=="__main__":main()
