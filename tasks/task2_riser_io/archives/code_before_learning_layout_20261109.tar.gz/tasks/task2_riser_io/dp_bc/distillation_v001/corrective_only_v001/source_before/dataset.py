"""Task2 demonstrations and teacher-contiguous corrective action windows."""
from pathlib import Path
import json
import numpy as np
import torch
from torch.utils.data import Dataset,Sampler
from data import Task2Data
from interface import CAMERAS

def expert_future_starts(sources,horizon=16):
 good=np.isin(sources,["expert","recovery","hold"]).all(axis=1)
 bad=np.r_[0,np.cumsum(~good)]
 # Observations are k,k+1; actions from k+1 onward must be teacher-contiguous.
 return np.array([k for k in range(len(good)-horizon+1) if bad[k+horizon]==bad[k+1]],dtype=np.int64)

def increments(absolute,state):
 a=np.asarray(absolute).reshape(-1,6,8).copy()
 previous=np.concatenate([np.asarray(state)[:,15:22,None].transpose(0,2,1),a[:,:-1,:7]],axis=1)
 a[:,:,:7]-=previous
 return a.reshape(-1,48)

class DistillationData(Dataset):
 def __init__(self,original,corrective):
  self.episodes=[];self.starts=[];self.groups={0:{},1:{}};self.summary=[]
  self.horizon=16
  for source,root in enumerate((original,corrective)):
   data=Task2Data(root)
   offset=len(self.episodes);valid={};boundaries=0
   phases=[]
   for i,e in enumerate(data.episodes):
    p=Path(e["path"]);meta=json.loads((p/"episode.json").read_text())
    phases.append(meta["phases"])
    if source:
     report=json.loads((p/"result.json").read_text())
     if report.get("execution_counts",{}).get("policy",0)<=0:
      raise ValueError("Corrective episode has no student execution: "+str(p))
     sources=np.load(p/"action_source.npy")
     valid[i]=set(expert_future_starts(sources,self.horizon).tolist())
     boundaries+=sum(bool(np.any(sources[k]=="policy")) for k in valid[i])
    e["action"]=increments(e["action"],e["state"])
    e["executed_delta"]=increments(np.load(p/"executed_action.npy"),e["state"])
    e["source"]=source
   self.episodes.extend(data.episodes)
   kept=0
   for i,k in data.starts:
    if source and k not in valid[i]:continue
    phase=phases[i][k+1]
    if phase=="settle" and k<18:continue
    index=len(self.starts);self.starts.append((offset+i,k))
    self.groups[source].setdefault((offset+i,phase),[]).append(index);kept+=1
   if not kept:raise ValueError("No usable windows in "+str(root))
   self.summary.append({"source":source,"root":str(root),"episodes":len(data.episodes),
                        "windows":kept,"student_to_teacher_boundary_windows":boundaries})
 def __len__(self):return len(self.starts)
 def __getitem__(self,index):
  ep,k=self.starts[index];e=self.episodes[ep]
  obs={c:torch.from_numpy(np.array(e[c][k:k+2])).permute(0,3,1,2).float()/255 for c in CAMERAS}
  obs["state"]=torch.from_numpy(np.array(e["state"][k:k+2]))
  action=np.array(e["action"][k:k+self.horizon])
  action[0]=e["executed_delta"][k]
  return {"obs":obs,"action":torch.from_numpy(action)}

class BalancedBatches(Sampler):
 def __init__(self,data,steps,batch_size,seed):
  self.steps=steps;self.batch_size=batch_size;self.seed=seed;self.groups={};self.prob={}
  for source,mapping in data.groups.items():
   self.groups[source]=[np.asarray(ids) for ids in mapping.values()]
   weights=np.array([.25 if phase in {"settle","wire_verify","preload_verify","full_verify"} else 1.
                     for (_,phase) in mapping],dtype=float)
   self.prob[source]=weights/weights.sum()
 def __len__(self):return self.steps
 def __iter__(self):
  rng=np.random.default_rng(self.seed)
  for step in range(self.steps):
   source=(step//8)%2
   if step%8==0:
    ids=self.groups[source][rng.choice(len(self.groups[source]),p=self.prob[source])]
   yield rng.choice(ids,size=self.batch_size,replace=len(ids)<self.batch_size).tolist()
