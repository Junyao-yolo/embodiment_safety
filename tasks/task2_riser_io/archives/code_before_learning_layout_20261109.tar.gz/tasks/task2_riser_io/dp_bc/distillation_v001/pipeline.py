"""Collect Task2 corrections alongside two stages of full-task distillation."""
from pathlib import Path
import json,subprocess,time,traceback
D=Path(__file__).resolve().parents[1]
HERE=D/"distillation_v001"
COLLECTION=HERE/"round_001"
WARMUP=D/"runs/distilled_round001_warmup_v001"
TRAIN=D/"runs/distilled_round001_v001"
PILOT=D/"evaluations/distilled_round001_pilot_v001"
FORMAL=D/"evaluations/distilled_round001_100_v001"
DP=D.parents[2]/"algos/diffusion_policy/.venv/bin/python"
ISAAC=Path("/mnt/data2/isaacsim-5.0.0/python.sh")
started=time.perf_counter()

def state(status,**fields):
    data=dict(status=status,wall_s=time.perf_counter()-started,**fields)
    (HERE/"pipeline_progress.json").write_text(json.dumps(data,indent=2))
    print(json.dumps(data),flush=True)

def start(command,log,pid_file):
    with log.open("w") as output:
        process=subprocess.Popen([str(x) for x in command],stdout=output,stderr=subprocess.STDOUT,
                                 stdin=subprocess.DEVNULL,cwd=str(D))
    pid_file.write_text(str(process.pid))
    return process

def run(command,log,stage):
    state(stage,command=[str(x) for x in command],log=str(log))
    process=start(command,log,HERE/"active_stage.pid")
    code=process.wait()
    if code:raise RuntimeError(stage+" failed; see "+str(log))

def collection_count():
    rows=json.loads((COLLECTION/"results.json").read_text())
    return sum(r["case"]=="corrective" and r["accepted"] and r["thread_engagement_verified"] for r in rows)

def main():
    count=collection_count()
    if count<3:raise RuntimeError("At least three complete corrective episodes are required")
    training=start([DP,"-B",HERE/"train.py","--corrective",COLLECTION/"raw","--output",WARMUP,"--steps","20000"],
                   HERE/"train_warmup.log",HERE/"warmup.pid")
    state("TRAINING_STAGE_1_AND_COLLECTING",training_pid=training.pid,training_steps=20000,
          total_training_steps=40000,training_progress=str(WARMUP/"progress.json"),
          corrective_successes_at_start=count,collection_progress=str(COLLECTION/"progress.json"))
    collector=None
    if count<5:
        collector=start([ISAAC,"-B",HERE/"collect_round.py","--max-attempts","22"],
                        HERE/"collect_additional.log",HERE/"collector.pid")
    code=training.wait()
    if code:raise RuntimeError("First training stage failed; see "+str(HERE/"train_warmup.log"))
    result=json.loads((WARMUP/"result.json").read_text())
    if result["steps"]!=20000:raise RuntimeError("First training stage is incomplete")
    state("FIRST_20000_UPDATES_COMPLETE",training=str(WARMUP/"result.json"),
          corrective_successes=collection_count(),collection_progress=str(COLLECTION/"progress.json"))
    if collector is not None:collector.wait()
    if collection_count()<5:
        run([ISAAC,"-B",HERE/"collect_round.py","--max-attempts","30","--checkpoint",WARMUP/"policy.pt"],
            HERE/"collect_updated_student.log","COLLECTING_WITH_UPDATED_STUDENT")
    if collection_count()<5:raise RuntimeError("Five complete corrective demonstrations are not yet available")
    run([DP,"-B",HERE/"train.py","--corrective",COLLECTION/"raw","--checkpoint",WARMUP/"policy.pt",
         "--output",TRAIN,"--steps","20000"],HERE/"train_round001.log","TRAINING_STAGE_2")
    first=json.loads((WARMUP/"result.json").read_text())
    second=json.loads((TRAIN/"result.json").read_text())
    (HERE/"training_result.json").write_text(json.dumps(dict(
        total_steps=first["steps"]+second["steps"],
        total_training_wall_s=first["train_wall_s"]+second["train_wall_s"],
        stages=[first,second],checkpoint=str(TRAIN/"policy.pt"),autonomous_task_verified=False),indent=2))
    thresholds=D/"runs/opposed100_v001/safety_thresholds.json"
    checkpoint=TRAIN/"policy.pt"
    common=[ISAAC,"-B",D/"evaluate_batch.py","--checkpoint",checkpoint,"--max-seconds","360",
            "--n-action-steps","8","--policy-device","cuda","--thresholds",thresholds]
    run(common+["--output",PILOT,"--seeds","189","930000","930001","930002","930003","--stop-on-incomplete"],
        HERE/"pilot_round001.log","AUTONOMOUS_PILOT")
    results=[json.loads(p.read_text()) for p in sorted(PILOT.glob("trial_*/evaluation.json"))]
    passed=len(results)==5 and all(
        r["valid_policy_test"] and r["task_success"] and r["report"].get("thread_engagement_verified")
        and r["report"].get("test_kind")=="learned_policy_closed_loop"
        and r["report"].get("demonstration_actions_used") is False for r in results)
    if not passed:
        state("PILOT_NEEDS_CORRECTION",completed=len(results),
              complete_successes=sum(r["task_success"] for r in results),
              results=str(PILOT/"summary.json"),checkpoint=str(checkpoint))
        return
    run(common+["--output",FORMAL,"--trials","100","--seed","940000"],
        HERE/"formal_round001.log","FORMAL_100_TESTS")
    summary=json.loads((FORMAL/"summary.json").read_text())
    state("COMPLETE",training=str(HERE/"training_result.json"),pilot=str(PILOT/"summary.json"),
          formal_summary=str(FORMAL/"summary.json"),videos=str(FORMAL/"video_selection.json"),
          task_success_rate=summary["task_success_rate"],
          candidate_safe_completion_rate=summary["candidate_safe_completion_rate"])

if __name__=="__main__":
    try:main()
    except Exception as error:
        state("NEEDS_REPAIR",error=str(error))
        (HERE/"pipeline_error.txt").write_text(traceback.format_exc())
        raise
