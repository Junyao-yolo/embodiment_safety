"""Fixed-observation prediction errors on the supervised corrective prefixes."""
from pathlib import Path
import argparse,json,sys
import numpy as np
import torch
from torch.utils.data import default_collate
D=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(D))
from model import build
from distillation_v001.prefix_dataset import PrefixData
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--checkpoint",type=Path,required=True)
 ap.add_argument("--data",type=Path,required=True);ap.add_argument("--output",type=Path,required=True)
 args=ap.parse_args();torch.set_num_threads(2)
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 data=PrefixData(None,args.data)
 selected={}
 for role,phases in data.groups.items():
  for phase,ids in phases.items():
   choose=ids if role=="boundary" else [ids[i] for i in np.unique(np.linspace(0,len(ids)-1,min(4,len(ids)),dtype=int))]
   for i in choose:selected[i]=(role,phase)
 selected=list(selected.items())
 payload=torch.load(args.checkpoint,map_location="cpu",weights_only=False)
 model=build(payload["config"]);model.load_state_dict(payload["model"]);model.n_action_steps=4
 model=model.cuda().eval();rows=[]
 with torch.inference_mode():
  for start in range(0,len(selected),8):
   cases=selected[start:start+8];b=default_collate([data[i] for i,_ in cases])
   obs={k:v.cuda() for k,v in b["obs"].items()}
   torch.manual_seed(8137+start);torch.cuda.manual_seed_all(8137+start)
   predicted=model.predict_action(obs)["action"];target=b["action"][:,1:5].cuda()
   err=(predicted-target).cpu().numpy().reshape(len(cases),4,6,8)
   norm=(model.normalizer["action"].normalize(predicted)-model.normalizer["action"].normalize(target)).cpu().numpy()
   for j,(index,(role,phase)) in enumerate(cases):
    mask=b["loss_mask"][j,1:5].numpy()
    structured=mask.reshape(4,6,8)
    rows.append(dict(index=index,role=role,phase=phase,teacher_commands=int(mask.sum()//8),
      normalized_action_mse=float(np.mean(norm[j][mask]**2)),
      arm_mae_rad=float(np.mean(np.abs(err[j,:,:,:7][structured[:,:,:7]]))),
      gripper_mae_mm=float(np.mean(np.abs(err[j,:,:,7][structured[:,:,7]]))*1000)))
 keys=["normalized_action_mse","arm_mae_rad","gripper_mae_mm"]
 def aggregate(items):return {k:float(np.mean([r[k] for r in items])) for k in keys}
 report=dict(checkpoint=str(args.checkpoint),n_action_steps=4,kind="In-sample fixed observations and noise; not autonomous success",
  data=data.summary,rows=rows,aggregate=aggregate(rows),
  by_role={role:aggregate([r for r in rows if r["role"]==role]) for role in data.groups},
  by_phase={p:aggregate([r for r in rows if r["phase"]==p]) for p in dict.fromkeys(r["phase"] for r in rows)})
 args.output.write_text(json.dumps(report,indent=2));print(json.dumps(report["by_role"]),flush=True)
if __name__=="__main__":main()
