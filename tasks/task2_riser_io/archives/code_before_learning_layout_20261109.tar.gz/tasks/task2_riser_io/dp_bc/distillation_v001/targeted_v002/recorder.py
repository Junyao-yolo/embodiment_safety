"""Video and control-event timestamps from the executed simulation."""
import csv,json,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from trial_recorder import TrialRecorder
CONTROLS={
 "student":("学生执行",(65,215,130)),
 "teacher_recovery":("教师介入：偏差纠正",(255,175,55)),
 "teacher_completion":("教师执行：指令收尾",(100,185,255)),
 "teacher_continuation":("教师执行：后续装配",(100,185,255)),
 "hold":("保持／物理验证",(195,195,195)),
}
class AnnotatedRecorder(TrialRecorder):
 def __init__(self,*args,**kw):
  super().__init__(*args,**kw)
  self.cjk=ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",22)
  self.small=ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",18)
  self.frame_times=[]
 def frame(self,images,rec):
  if self.pipe is None:
   ff="/home/ufdwaa/anaconda3/envs/env_isaaclab/lib/python3.10/site-packages/imageio_ffmpeg/binaries/ffmpeg-linux-x86_64-v7.0.2"
   self.log=(self.path/"encoder.log").open("w")
   self.pipe=subprocess.Popen([ff,"-y","-hide_banner","-loglevel","warning","-f","rawvideo","-pix_fmt","rgb24",
    "-s","1152x650","-r","10","-i","pipe:0","-an","-c:v","libx264","-preset","veryfast","-crf","20",
    "-threads","1","-pix_fmt","yuv420p","-movflags","+faststart",str(self.path/"rollout.mp4")],stdin=subprocess.PIPE,stderr=self.log)
  im=Image.new("RGB",(1152,650),(18,24,32));draw=ImageDraw.Draw(im)
  control=rec.get("control",{});name,color=CONTROLS.get(control.get("control","hold"),CONTROLS["hold"])
  draw.text((12,6),f"Task2 纠正采集 | seed {self.seed} | 仿真 {rec['time_s']:.2f} s | {rec['phase']}",font=self.cjk,fill="white")
  draw.text((12,40),name+f"    本次切换时间 {control.get('last_switch_s',0):.3f} s",font=self.cjk,fill=color)
  for j,(camera,title) in enumerate((("external","外部相机"),("wrist_left","左腕相机"),("wrist_right","右腕相机"))):
   draw.text((j*384+12,78),title+"（策略原图 128×128）",font=self.small,fill="lightblue")
   im.paste(Image.fromarray(images[camera]).resize((384,384)),(j*384,108))
  reason=control.get("reason","初始静置")
  draw.text((12,503),"条件："+reason,font=self.cjk,fill=color)
  trigger=control.get("trigger",{})
  compact=" | ".join(f"{k}={v:.3f}" if isinstance(v,(int,float)) else f"{k}={v}" for k,v in trigger.items())
  # The exact numeric conditions are also saved in control_events.json/csv.
  if len(compact)>110:compact=compact[:110]
  draw.text((12,538),compact,font=self.small,fill="white")
  m=control.get("measurements",{})
  draw.text((12,571),f"当前位置误差 {m.get('position_error_mm',0):.2f} mm | 姿态误差 {m.get('angle_error_deg',0):.2f}° | 根部载荷 {rec.get('root_force_N',0):.2f} N",font=self.small,fill="white")
  draw.text((12,605),"接管容差用于纠正采集；不作为安全损伤阈值。螺丝阶段由教师完成。",font=self.small,fill="lightgray")
  self.pipe.stdin.write(np.asarray(im).tobytes());self.frames+=1
  self.frame_times.append(dict(frame=self.frames-1,video_time_s=(self.frames-1)/10,simulation_time_s=rec["time_s"]))
 def finish(self,report):
  assessment=super().finish(report)
  coverage=report.get("correction_coverage",{})
  events=coverage.get("control_events",[])
  (self.path/"control_events.json").write_text(json.dumps(events,ensure_ascii=False,indent=2))
  with (self.path/"control_events.csv").open("w",newline="") as f:
   fields=["time_s","phase","group","previous_control","control","reason","trigger","measurements"]
   writer=csv.DictWriter(f,fields);writer.writeheader()
   for row in events:
    writer.writerow({**row,"trigger":json.dumps(row["trigger"],ensure_ascii=False),"measurements":json.dumps(row["measurements"])})
  (self.path/"frame_times.json").write_text(json.dumps(self.frame_times))
  return assessment
