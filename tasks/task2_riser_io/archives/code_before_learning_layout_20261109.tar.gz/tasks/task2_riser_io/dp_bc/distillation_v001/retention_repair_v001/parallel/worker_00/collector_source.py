"""Collect complete targeted DAgger corrections in one Isaac Sim session."""
from pathlib import Path
import argparse,gc,json,sys,time,traceback,importlib
import numpy as np
HERE=Path(__file__).resolve().parent
D=HERE.parents[1];R=D.parent
sys.path.insert(0,str(D));sys.path.insert(0,str(HERE))
from handback import HandbackRouter as TargetedRouter

def replace(source,old,new):
 if source.count(old)!=1:raise RuntimeError("Expected one collection hook: "+old[:100])
 return source.replace(old,new,1)

def make_source():
 source=(R/"scripts/run_dp_bc.py").read_text()
 source=replace(source,"  from feedback import JointCommandLimits,FeedbackExpert,RecoveryRouter","  from feedback import JointCommandLimits,RecoveryRouter\n  from held_body_feedback import HeldBodyFeedbackExpert as FeedbackExpert")
 source=replace(source,"router=RecoveryRouter(expert,collection_config,args.seed,policy_client)",
  "router=TargetedRouter(expert,collection_config,args.seed,policy_client,clock=lambda:stepnum*dt,seat_position=target)")
 source=replace(source,"  hp,hr=solver.compute_forward_kinematics('panda_hand',q[ai])\n  steps=max(1,round(seconds*60*motion_config['phases'].get(phase,{}).get('grip_duration_scale',1.)))","  hp,hr=handpose()\n  steps=max(1,round(seconds*60*motion_config['phases'].get(phase,{}).get('grip_duration_scale',1.)))")
 source=replace(source,"   records.append(rec)",
  "   rec['control']=router.snapshot() if router is not None else {}\n   _trial_recorder.measure(rec,latest,sensor,ci,si,tr,target)\n   records.append(rec)")
 source=replace(source,"  image_frames.append(images)","  _trial_recorder.frame(images,rec)\n  image_frames.append(images)")
 source=replace(source,"ring_offset=np.array([0.,.023,.007])","ring_offset=np.array([0.,.023,.012])")
 source=replace(source,"screw_offset=np.array([0.,0.,.033])","screw_offset=np.array([0.,0.,.037])")
 if source.count("[0,0,.033]")!=4:raise RuntimeError("Expected four screw regrasp waypoints")
 source=source.replace("[0,0,.033]","[0,0,.037]")
 source=replace(source," phase='seat';body_move(rv,target+[0,0,.0001],3.,board_rotation)",
  " phase='seat';body_move(rv,target+[0,0,.006],1.,board_rotation);body_move(rv,target+[0,0,.0001],3.,board_rotation)")
 source=replace(source,"  # Preserve physical verification time; no artificial nonzero action.",
  "  if router is not None:router.note_hold(phase,seconds)\n  # Preserve physical verification time; no artificial nonzero action.")
 source=replace(source,'    report.setdefault("grasp_retries",[]).append',
  '    if router is not None:router.note_grasp_failure(phase,height,blocked_width)\n    report.setdefault("grasp_retries",[]).append')
 source=replace(source," if not ring_on_seat(records[-1],target,assembly_geometry):\n  override=",
  " if not ring_on_seat(records[-1],target,assembly_geometry):\n  if router is not None:router.note_seat_failure(np.linalg.norm(rv.get_transforms()[0,:2]-target[:2]),rv.get_transforms()[0,2])\n  override=")
 source=replace(source,'  completion=.006 if phase=="thread_turn" else .002',
  '  completion=.006 if phase=="thread_turn" else (.0005 if phase=="seat" else (.005 if phase=="approach" else (.0015 if phase=="descend" else .002)))')
 source=replace(source,"    dispatch_feedback();seed=q[ai].copy();continue\n   actual=(latest['ring']", """    dispatch_feedback();seed=q[ai].copy()
    if phase=="thread_turn" and k>=steps:
     actual_screw=latest["screw"][0]
     progress_angle=float(np.dot((Rotation.from_quat(actual_screw[3:])*r0.inv()).as_rotvec(),dr/max(np.linalg.norm(dr),1e-12)))
     if (progress_angle>=.8*np.linalg.norm(dr) and actual_screw[2]<initial[2]
         and np.max(np.abs(expert.limits.velocity))<.08
         and np.max(np.abs(latest["joint_velocities"][0,:7]))<.1):
      report.setdefault("measured_turn_completions",[]).append(dict(requested_deg=float(np.degrees(np.linalg.norm(dr))),achieved_deg=float(np.degrees(progress_angle)),advance_m=float(initial[2]-actual_screw[2])))
      return
    continue
   actual=(latest['ring']""")
 a=source.index(" def control_schedule(steps,settle_steps=0):")
 b=source.index(" def hold_feedback(seconds):",a)
 source=source[:a]+""" def control_schedule(steps,settle_steps=0):
  if expert is None:
   yield from range(steps+settle_steps);return
  from distillation_v001.teacher import MotionProgress,MotionTimeout
  completion=.006 if phase=="thread_turn" else (.0005 if phase=="seat" else (.005 if phase=="approach" else (.0015 if phase=="descend" else .002)))
  tracker=MotionProgress(steps,settle_steps,completion_error=completion)
  tracker.budget+=480
  previous_override=router.teacher_override
  recoveries=0;stalled_ticks=0;best_error=float("inf");last_cursor=tracker.cursor
  no_progress_ticks=20*6
  previous_position=None;previous_rotation=None
  try:
   while True:
    yield tracker.index
    error=expert.tracking_error(latest);velocity=float(np.max(np.abs(expert.limits.velocity)))
    timeout=None
    try:done=tracker.update(error,velocity)
    except MotionTimeout as exc:done=False;timeout=exc
    if phase=="seat" and tracker.cursor>=tracker.steps:
     window=records[-max(2,round(.1*physics_hz)):]
     seated=bool(window and all(ring_on_seat(row,target,assembly_geometry) for row in window))
     span=np.ptp([[row["ring_x"],row["ring_y"],row["ring_z"]] for row in window],axis=0) if window else np.full(3,np.inf)
     centered=bool(window and np.linalg.norm(np.array([window[-1]["ring_x"],window[-1]["ring_y"]])-target[:2])<=.00035)
     if seated and centered and np.max(span)<=.0005:
      report.setdefault("measured_seat_completions",[]).append(dict(time_s=stepnum*dt,tracking_error_mm=error*1000,
       position_span_mm=(span*1000).tolist(),criterion="ring supported and center aligned within 0.35 mm for screw-hole clearance; released retention checked separately"))
      return
    if done and not router.path_recovery_active:return
    reference=expert.reference
    position=np.asarray(reference["position"]);rotation=np.asarray(reference["rotation"])
    waypoint_changed=(previous_position is None or np.linalg.norm(position-previous_position)>.001
                      or np.linalg.norm(rotation-previous_rotation)>.03)
    previous_position=position.copy();previous_rotation=rotation.copy()
    if waypoint_changed or tracker.cursor>last_cursor or error<best_error-.0005:
     stalled_ticks=0;best_error=error
    else:stalled_ticks+=1
    last_cursor=tracker.cursor
    if stalled_ticks>=no_progress_ticks or timeout is not None:
     if recoveries>=2:
      report.setdefault("incomplete_reference_tracking_phases",[]).append(phase)
      raise RuntimeError("Teacher recovery exhausted in "+phase+": "+str(timeout or f"no measured progress; error={error:.6f}"))
     recoveries+=1
     details=dict(attempt=recoveries,max_attempts=2,no_progress_action_steps=stalled_ticks/6.,
                  action_step_seconds=.1,reference_index=tracker.cursor,reference_steps=tracker.steps,
                  tracking_error_mm=float(error*1000),control_ticks=tracker.elapsed)
     router.recover_motion(latest,phase,"动作无有效进展，强制教师恢复并重新估计抓取关系",details)
     tracker.elapsed=0;tracker.stable=0
     stalled_ticks=0;best_error=float("inf")
  finally:router.teacher_override=previous_override
""" +source[b:]
 source=replace(source," if report.get('accepted',False) and args.record:",
  " if router is not None:report['correction_coverage']=router.summary()\n if report.get('accepted',False) and report.get('correction_coverage',{}).get('collection_eligible',False) and args.record:")
 compile(source,str(R/"scripts/run_dp_bc.py"),"exec")
 return source

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--checkpoint",type=Path,default=D/"runs/targeted_query_pilot_v001/policy.pt")
 ap.add_argument("--output",type=Path,default=D/"distillation_v001/handback_round003_v001")
 ap.add_argument("--successes",type=int,default=10);ap.add_argument("--max-attempts",type=int,default=30)
 ap.add_argument("--n-action-steps",type=int,choices=range(1,16),default=4)
 ap.add_argument("--worker-id",type=int,default=0)
 ap.add_argument("--focus-quotas",type=json.loads,default={"wire":4,"screw_pick":3,"fastening":3})
 ap.add_argument("--seeds",nargs="+",type=int)
 ap.add_argument("--focus",choices=("wire","screw_pick","fastening"))
 ap.add_argument("--check-source",action="store_true");args=ap.parse_args()
 source=make_source()
 if args.check_source:print("Collection hooks and Python syntax valid");return
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
 raw=out/"raw";raw.mkdir(exist_ok=True)
 started=time.perf_counter()
 config=dict(method="dagger",randomize=True,checkpoint=str(args.checkpoint.resolve()),policy_device="cuda",
  n_action_steps=args.n_action_steps,fixed_noise=True,noise_mm_s=0.,save_failed_video=False,
  free_tracking_limit_mm=12.,seat_tracking_limit_mm=6.,gripper_difference_mm=12.,stall_window_s=.8,student_no_progress_action_steps=20,action_step_seconds=.1,teacher_recovery_attempts=2,
  policy_schedule="student attempts focus stages; teacher corrects briefly and hands back within the same stage",
  worker_id=args.worker_id,focus_quotas=args.focus_quotas)
 if set(args.focus_quotas)!={"wire","screw_pick","fastening"} or any(v<0 for v in args.focus_quotas.values()):
  raise ValueError("Focus quotas must specify nonnegative wire, screw_pick and fastening counts")
 if sum(args.focus_quotas.values())<args.successes:raise ValueError("Focus quotas cannot satisfy target")
 (out/"collection.json").write_text(json.dumps(config,indent=2))
 (out/"collector_source.py").write_text(Path(__file__).read_text())
 (out/"executed_collection_source.py").write_text(source)
 status=dict(status="STARTING",completed_successes=0,target_successes=args.successes)
 def write_status(**kw):
  status.update(kw,wall_s=time.perf_counter()-started)
  pending=out/"progress.tmp";pending.write_text(json.dumps(status,ensure_ascii=False,indent=2));pending.replace(out/"progress.json")
 write_status()
 from isaacsim import SimulationApp
 app=SimulationApp({"headless":True,"limit_cpu_threads":4,"width":128,"height":128,"sync_loads":True,
                    "extra_args":["--/log/file="+str(out/"kit.log")]})
 from recorder_handback import AnnotatedRecorder
 session={};results=json.loads((out/"results.json").read_text()) if (out/"results.json").exists() else []
 successes=sum(bool(r["saved"]) for r in results)
 thresholds=json.loads((D/"runs/opposed100_v001/safety_thresholds.json").read_text())
 seeds=args.seeds if args.seeds else ([920013,920016,920005,920008,920014]+[960000+5*i for i in range(max(0,args.max_attempts-5))])[:args.max_attempts]
 attempted={r["seed"] for r in results if r["saved"]}
 try:
  for seed in seeds:
   if (out/"stop_after_attempt").exists():
    write_status(status="STOPPED_AFTER_ATTEMPT");return
   if seed in attempted:continue
   if successes>=args.successes:break
   index=max([int(p.name.split("_")[0]) for p in (out/"trials").glob("*") if p.is_dir()]+[-1])+1
   quotas=config["focus_quotas"]
   counts={focus:sum(r["saved"] and r.get("focus_set","wire")==focus for r in results) for focus in quotas}
   available=[f for f in ("screw_pick","fastening","wire") if counts[f]<quotas[f]]
   focus=args.focus or available[(len(results)-1)%len(available)]
   if seed==920013 and counts["wire"]<quotas["wire"]:focus="wire"
   cfg=dict(config,focus_set=focus,free_tracking_limit_mm=12. if focus=="wire" else 6.)
   trial=out/"trials"/f"{index:03d}_{focus}_{seed}"
   trial.mkdir(parents=True,exist_ok=False)
   import router as router_module,handback as handback_module,entry_recovery as entry_module,held_body_feedback as held_module
   importlib.reload(held_module)
   importlib.reload(router_module)
   importlib.reload(handback_module)
   controller_class=importlib.reload(entry_module).EntryRecoveryRouter
   recorder=AnnotatedRecorder(trial,seed,thresholds,label="Task2 纠正采集 / "+{"wire":"线头操作","screw_pick":"螺丝取放","fastening":"螺丝旋拧"}[focus])
   ns=dict(__name__="__main__",_collection_config=cfg,_episode_root=raw,
    _diagnostics_root=trial/"diagnostics",_reset_request=out/"reset_requested",
    _simulation_app=app,_scene_session=session,_trial_recorder=recorder,
    _kit_log=out/"kit.log",TargetedRouter=controller_class,
    _runtime_metadata={"persistent":True,"worker_id":args.worker_id,"purpose":"targeted_teacher_corrections"})
   write_status(status="RUNNING",seed=seed,focus_set=focus,focus_successes=counts,trial=str(trial),completed_successes=successes)
   def progress(row,perf):
    controller=ns.get("router")
    write_status(measurements=row,performance=perf,control=controller.snapshot() if controller else {})
   ns["_progress_callback"]=progress
   for module_file in ("router.py","handback.py","entry_recovery.py","held_body_feedback.py"):(trial/module_file).write_text((HERE/module_file).read_text())
   sys.argv=[str(R/"scripts/run_dp_bc.py"),"--seed",str(seed),"--record"]
   before=time.perf_counter()
   exec(compile(source,str(R/"scripts/run_dp_bc.py"),"exec"),ns)
   report=ns["report"]
   report.update(validation_kind="targeted_correction",teacher_enabled=True,student_autonomous_success=False)
   coverage=report.get("correction_coverage",{})
   saved=bool(report.get("accepted") and coverage.get("collection_eligible"))
   report["saved_for_training"]=saved
   (trial/"result.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
   recorder.finish(report)
   if not saved and ns.get("image_frames"):
    from PIL import Image
    for camera,pixels in ns["image_frames"][-1].items():Image.fromarray(pixels).save(trial/("last_"+camera+".png"))
   result=dict(seed=seed,focus_set=focus,qualifying_handbacks=coverage.get("qualifying_handbacks",0),accepted=bool(report.get("accepted")),saved=saved,
    thread_engagement_verified=bool(report.get("thread_engagement_verified")),
    student_commands_by_group=coverage.get("student_commands_by_group",{}),
    corrections_by_group=coverage.get("corrections_by_group",{}),
    error=report.get("error"),wall_s=time.perf_counter()-before,trial=str(trial),
    raw=str(raw/f"episode_{seed:04d}") if saved else None,
    video=str(trial/"rollout.mp4") if saved else None)
   results.append(result)
   if saved:
    successes+=1
    if not (out/"first_success.json").exists():
     (out/"first_success.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print("ACCEPTED_CORRECTION",json.dumps(result),flush=True)
   else:
    (trial/"rollout.mp4").unlink(missing_ok=True)
   pending=out/"results.tmp";pending.write_text(json.dumps(results,ensure_ascii=False,indent=2));pending.replace(out/"results.json")
   render_setup=ns.get("setup_render")
   render={k:getattr(render_setup,k) for k in ("anns","products","paths","manifest")} if hasattr(render_setup,"anns") else {}
   ns["sim"].stop()
   session=dict(sim=ns["sim"],initial_transforms=ns["initial_transforms"],
                assembly_geometry=ns["assembly_geometry"],render=render)
   ns["view"].invalidate()
   ns.clear();del recorder,render_setup;gc.collect()
   write_status(completed_successes=successes,last_result=result)
  if successes<args.successes:
   if args.seeds:
    write_status(status="PROBE_COMPLETE",completed_successes=successes);return
   raise RuntimeError("Target not reached within attempt budget")
  write_status(status="COMPLETE",completed_successes=successes)
 except Exception as exc:
  write_status(status="NEEDS_REPAIR",error=str(exc))
  (out/"error.txt").write_text(traceback.format_exc());raise
 finally:
  for ann in session.get("render",{}).get("anns",{}).values():ann.detach()
  for product in session.get("render",{}).get("products",[]):product.destroy()
  app.close()
if __name__=="__main__":main()
