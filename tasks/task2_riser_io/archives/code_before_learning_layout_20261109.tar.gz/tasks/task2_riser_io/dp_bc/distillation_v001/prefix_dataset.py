"""Contiguous teacher prefixes, including short corrective takeovers."""
from pathlib import Path
from collections import Counter
import json
import numpy as np
import torch
from torch.utils.data import Dataset,Sampler
from data import Task2Data
from interface import CAMERAS
from distillation_v001.dataset import increments
FOCUS={"approach","descend","grasp","transport","seat"}

class PrefixData(Dataset):
 def __init__(self,original,corrective):
  if original is not None:raise ValueError("Prefix correction training uses only the corrective root")
  data=Task2Data(corrective);self.episodes=data.episodes;self.starts=[];self.lengths=[];self.roles=[];self.queries=[]
  self.groups={};self.boundaries={};self.horizon=16
  meta=[];sources=[];good=[];focuses=[]
  for e in self.episodes:
   path=Path(e["path"])
   meta.append(json.loads((path/"episode.json").read_text())["phases"])
   report=json.loads((path/"result.json").read_text())
   focuses.append(set(report.get("correction_coverage",{}).get("focus_phases",FOCUS)))
   source=np.load(path/"action_source.npy");sources.append(source)
   good.append(np.isin(source,["expert","recovery","hold"]).all(axis=1))
   e["action"]=increments(e["action"],e["state"])
   e["executed_delta"]=increments(np.load(path/"executed_action.npy"),e["state"])
   e["source"]=1
  boundary_counts=Counter();phase_counts=Counter();prefix_counts=Counter()
  for ep,k in data.starts:
   phase=meta[ep][k+1]
   query=bool(not good[ep][k+1] and phase in focuses[ep] and np.any(sources[ep][k+1]=="policy"))
   if not good[ep][k+1] and not query:continue
   if phase=="settle":continue
   length=0
   for j in range(k+1,k+self.horizon):
    if not good[ep][j]:break
    length+=1
   if not length and not query:continue
   boundary=bool(np.any(sources[ep][k]=="policy"))
   role="student_query" if query else "boundary" if boundary and phase in focuses[ep] else "correction" if phase in focuses[ep] else "continuation"
   index=len(self.starts);self.starts.append((ep,k));self.lengths.append(length);self.roles.append(role);self.queries.append(query)
   self.groups.setdefault(role,{}).setdefault(phase,[]).append(index)
   phase_counts[phase]+=1;prefix_counts[length]+=1
   if boundary and not query:boundary_counts[phase]+=1
  if not self.starts:raise ValueError("No teacher prefixes in corrective data")
  self.summary=[dict(source=1,root=str(corrective),episodes=len(self.episodes),windows=len(self.starts),
   student_to_teacher_boundary_windows=sum(boundary_counts.values()),
   boundary_windows_by_phase=dict(boundary_counts),phase_windows=dict(phase_counts),
   future_prefix_lengths=dict(prefix_counts),
   student_query_windows=sum(self.queries),
   loss_target="Student-visited states: first expert query only. Teacher execution: contiguous prefix. Padding excluded from loss")]
 def __len__(self):return len(self.starts)
 def __getitem__(self,index):
  ep,k=self.starts[index];e=self.episodes[ep];length=self.lengths[index]
  obs={c:torch.from_numpy(np.array(e[c][k:k+2])).permute(0,3,1,2).float()/255 for c in CAMERAS}
  obs["state"]=torch.from_numpy(np.array(e["state"][k:k+2]))
  action=np.array(e["action"][k:k+self.horizon])
  action[0]=e["executed_delta"][k]
  mask=np.zeros_like(action,dtype=bool)
  if self.queries[index]:
   first=action[1,:8].copy()
   tail=action[1:].reshape(-1,6,8);tail[:,:,:7]=0.;tail[:,:,7]=first[7]
   action[1,:8]=first;mask[1,:8]=True
  else:
   mask[:length+1]=True
   tail=action[length+1:].reshape(-1,6,8)
   tail[:,:,:7]=0.
   tail[:,:,7]=action[length].reshape(6,8)[-1,7]
  return dict(obs=obs,action=torch.from_numpy(action),loss_mask=torch.from_numpy(mask))

class PrefixBatches(Sampler):
 def __init__(self,data,steps,batch_size,seed):
  self.steps=steps;self.batch_size=batch_size;self.seed=seed
  self.groups={role:[np.asarray(ids) for ids in phases.values()] for role,phases in data.groups.items()}
  self.roles=list(self.groups)
  weights={"student_query":.4,"boundary":.25,"correction":.15,"continuation":.2}
  self.prob=np.array([weights[r] for r in self.roles]);self.prob/=self.prob.sum()
 def __len__(self):return self.steps
 def __iter__(self):
  rng=np.random.default_rng(self.seed)
  for _ in range(self.steps):
   batch=[]
   for _ in range(self.batch_size):
    role=rng.choice(self.roles,p=self.prob);groups=self.groups[role];ids=groups[rng.integers(len(groups))]
    batch.append(int(rng.choice(ids)))
   yield batch

def masked_diffusion_loss(policy,batch):
 if not policy.obs_as_global_cond:raise ValueError("Task2 requires global observation conditioning")
 if policy.noise_scheduler.config.prediction_type!="sample":raise ValueError("Task2 uses clean-action prediction")
 nobs=policy.normalizer.normalize(batch["obs"])
 trajectory=policy.normalizer["action"].normalize(batch["action"])
 obs={k:v[:,:policy.n_obs_steps].reshape(-1,*v.shape[2:]) for k,v in nobs.items()}
 features=policy.obs_encoder(obs).reshape(trajectory.shape[0],-1)
 condition=policy.mask_generator(trajectory.shape)
 noise=torch.randn_like(trajectory)
 timesteps=torch.randint(0,policy.noise_scheduler.config.num_train_timesteps,(len(trajectory),),device=trajectory.device).long()
 noisy=policy.noise_scheduler.add_noise(trajectory,noise,timesteps)
 noisy[condition]=trajectory[condition]
 pred=policy.model(noisy,timesteps,local_cond=None,global_cond=features)
 mask=batch["loss_mask"] & ~condition
 squared=(pred-trajectory).square()*mask
 return (squared.flatten(1).sum(1)/mask.flatten(1).sum(1)).mean()
