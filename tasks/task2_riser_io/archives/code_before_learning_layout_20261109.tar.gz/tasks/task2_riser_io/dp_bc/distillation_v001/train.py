"""Continue full-task Task2 DP-BC with expert corrective demonstrations."""
from pathlib import Path
import argparse,copy,json,math,os,subprocess,sys,time
import numpy as np
import torch
from torch.utils.data import DataLoader
D=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(D))
from model import build
from distillation_v001.dataset import DistillationData,BalancedBatches
from diffusion_policy.model.diffusion.ema_model import EMAModel
from diffusion_policy.model.common.normalizer import SingleFieldLinearNormalizer

def task1_active():
 output=subprocess.check_output(["nvidia-smi","--query-compute-apps=pid","--format=csv,noheader"],text=True)
 for pid in output.split():
  p=Path("/proc")/pid/"cmdline"
  try:cmd=p.read_bytes().lower()
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  if b"task1" in cmd:return True
 return False

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--original",type=Path,default=D/"data/opposed_v002/raw")
 ap.add_argument("--corrective",type=Path,required=True)
 ap.add_argument("--checkpoint",type=Path,default=D/"runs/opposed100_v002/policy.pt")
 ap.add_argument("--output",type=Path,required=True)
 ap.add_argument("--steps",type=int,default=40000)
 ap.add_argument("--corrective-only",action="store_true")
 ap.add_argument("--short-corrections",action="store_true")
 ap.add_argument("--learning-rate",type=float,default=1e-4)
 ap.add_argument("--min-learning-rate",type=float,default=1e-5)
 ap.add_argument("--warmup-steps",type=int,default=500)
 args=ap.parse_args()
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 started=time.perf_counter();torch.set_num_threads(2);torch.manual_seed(42);np.random.seed(42)
 torch.set_float32_matmul_precision("highest")
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 def progress(**kw):
  kw["wall_s"]=time.perf_counter()-started
  (out/"progress.json").write_text(json.dumps(kw,indent=2))
 progress(status="LOADING_DATA")
 from distillation_v001.prefix_dataset import PrefixData,PrefixBatches,masked_diffusion_loss
 data_class=PrefixData if args.short_corrections else DistillationData
 sampler_class=PrefixBatches if args.short_corrections else BalancedBatches
 data=data_class(None if args.corrective_only else args.original,args.corrective)
 payload=torch.load(args.checkpoint,map_location="cpu",weights_only=False)
 cfg=dict(payload["config"]);cfg["n_action_steps"]=4
 model=build(cfg);model.load_state_dict(payload["model"])
 values=np.concatenate([e["action"] for e in data.episodes]+[e["executed_delta"] for e in data.episodes])
 with torch.no_grad():
  normalized=model.normalizer["action"].normalize(torch.from_numpy(values))
  outside=float((normalized.abs()>1.0001).float().mean())
  normalized_peak=float(normalized.abs().max())
 extend_normalizer=outside>0 and not args.corrective_only
 if extend_normalizer:
  model.normalizer["action"]=SingleFieldLinearNormalizer.create_fit(values,mode="limits")
 model=model.cuda().train();ema_model=copy.deepcopy(model);ema=EMAModel(ema_model,power=.75)
 opt=torch.optim.AdamW(model.parameters(),lr=args.learning_rate,weight_decay=1e-6)
 loader=DataLoader(data,batch_sampler=sampler_class(data,args.steps,16,42),num_workers=2,
                   pin_memory=True,persistent_workers=True,prefetch_factor=2)
 sampling=("100% corrective" if args.corrective_only else "50% original, 50% corrective")
 settings={"source_checkpoint":str(args.checkpoint),"model":cfg,"data":data.summary,"steps":args.steps,
           "batch_size":16,"precision":"FP32; TF32 disabled","optimizer":"AdamW",
           "learning_rate":[args.learning_rate,args.min_learning_rate],"warmup_steps":args.warmup_steps,
           "corrective_only":args.corrective_only,"episode_paths":[e["path"] for e in data.episodes],
           "gradient_clip_norm":1.,"weight_decay":1e-6,"ema_power":.75,
           "source_sampling":sampling+"; episode-phase groups weighted equally; verification weight 0.25",
           "past_action_target":"Recorded executed action for the action preceding the latest observation",
           "corrective_future_target":"Only contiguous expert/recovery/hold executed segments",
           "normalizer_extended":extend_normalizer,
           "normalizer_policy":"inherited unchanged" if args.corrective_only else "extend action limits when needed","target_outside_original_range_fraction":outside,
           "target_normalized_peak":normalized_peak,
           "coexistence":"Sleep 0.12 s after each synchronized Task2 update while a Task1 GPU process is active",
           "task_success_verified":False}
 if args.short_corrections:
  settings.update(short_corrections=True,source_sampling="40% student-state queries, 25% handoff boundaries, 15% focus-phase prefixes, 20% continuation; phases uniform within role",corrective_future_target="First query on student-visited states plus contiguous teacher prefixes; other future masked")
 (out/"config.json").write_text(json.dumps(settings,indent=2))
 def device(x):return {k:device(v) for k,v in x.items()} if isinstance(x,dict) else x.cuda(non_blocking=True)
 def save(step):
  torch.save({"config":cfg,"model":ema_model.state_dict(),"steps":step,"training":settings},out/"policy.pt.tmp")
  os.replace(out/"policy.pt.tmp",out/"policy.pt")
  torch.save({"raw_model":model.state_dict(),"optimizer":opt.state_dict(),"steps":step},out/"training_state.pt.tmp")
  os.replace(out/"training_state.pt.tmp",out/"training_state.pt")
 losses=[];paced_updates=0;pause=.12 if task1_active() else 0.;train_start=time.perf_counter()
 with (out/"metrics.jsonl").open("w") as log:
  for step,batch in enumerate(loader,1):
   if step%100==1:pause=.12 if task1_active() else 0.
   b=device(batch);opt.zero_grad(set_to_none=True)
   fraction=max(0.,(step-args.warmup_steps)/max(1,args.steps-args.warmup_steps))
   lr=min(1.,step/max(1,args.warmup_steps))*(args.min_learning_rate+
       (args.learning_rate-args.min_learning_rate)*.5*(1+math.cos(math.pi*fraction)))
   for group in opt.param_groups:group["lr"]=lr
   loss=masked_diffusion_loss(model,b) if args.short_corrections else model.compute_loss(b)
   if not torch.isfinite(loss):raise RuntimeError("Nonfinite loss")
   loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
   opt.step();ema.step(model)
   with torch.no_grad():
    buffers=dict(model.named_buffers())
    for name,v in ema_model.named_buffers():v.copy_(buffers[name])
   losses.append(float(loss.detach()))
   if pause:
    torch.cuda.synchronize();time.sleep(pause);paced_updates+=1
   log.write(json.dumps({"step":step,"loss":losses[-1],"learning_rate":lr,"task1_coexist_pause_s":pause,
                        "train_wall_s":time.perf_counter()-train_start})+"\n")
   if step%100==0:
    log.flush()
    progress(status="TRAINING",step=step,total_steps=args.steps,loss_mean_100=float(np.mean(losses[-100:])),
             train_wall_s=time.perf_counter()-train_start,task1_coexist_pause_s=pause,paced_updates=paced_updates)
   if step%5000==0 or step==args.steps:save(step)
 result={"status":"TRAINING_FINISHED","steps":args.steps,"train_wall_s":time.perf_counter()-train_start,
         "last_100_loss":float(np.mean(losses[-100:])),"paced_updates":paced_updates,
         "learned_full_task_verified":False,"checkpoint":str(out/"policy.pt")}
 (out/"result.json").write_text(json.dumps(result,indent=2));progress(**result);print(json.dumps(result),flush=True)
if __name__=="__main__":main()
