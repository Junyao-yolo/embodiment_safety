"""Validate the full teacher and collect corrective demonstrations in one simulator."""
from pathlib import Path
import argparse,gc,json,sys,time,traceback
import numpy as np
D=Path(__file__).resolve().parents[1];R=D.parent
sys.path.insert(0,str(D))
from evaluate_batch import make_source
from interface import action_block_to_targets
BASE=D/"data/opposed_v002/raw/episode_0189"
class RecordedActions:
 def __init__(self):
  self.actions=np.load(BASE/"executed_action.npy")
  self.times=np.load(BASE/"time.npy");self.cursor=int(np.searchsorted(self.times,2.-1e-7))
 def act(self,images,state):
  block=self.actions[min(self.cursor,len(self.actions)-1)]
  self.cursor+=1
  return action_block_to_targets(block)
 def close(self):pass

def main():
 ap=argparse.ArgumentParser();ap.add_argument("--checkpoint",type=Path,default=D/"runs/opposed100_v002/policy.pt")
 ap.add_argument("--output",type=Path,default=D/"distillation_v001/round_001")
 ap.add_argument("--successes",type=int,default=5);ap.add_argument("--max-attempts",type=int,default=7)
 ap.add_argument("--seed",type=int,default=920000);args=ap.parse_args()
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
 raw=out/"raw";raw.mkdir(exist_ok=True)
 started=time.perf_counter()
 config=dict(method="dagger",randomize=True,checkpoint=str(args.checkpoint.resolve()),policy_device="cuda",
             n_action_steps=8,fixed_noise=True,student_segment_blocks=8,expert_segment_blocks=24,
             recovery_distance_m=.015,contact_recovery_distance_m=.002,gripper_recovery_difference_m=.005,noise_mm_s=0.,save_failed_video=False)
 (out/"collection.json").write_text(json.dumps(config,indent=2))
 status={"status":"STARTING","completed_successes":0,"target_successes":args.successes}
 def write_status(**kw):
  status.update(kw,wall_s=time.perf_counter()-started)
  (out/"progress.json").write_text(json.dumps(status,indent=2))
 write_status(status="STARTING")
 from isaacsim import SimulationApp
 app=SimulationApp({"headless":True,"limit_cpu_threads":4,"width":128,"height":128,"sync_loads":True,
                    "extra_args":["--/log/file="+str(out/"kit.log")]})
 from trial_recorder import TrialRecorder
 session={};results=json.loads((out/"results.json").read_text()) if (out/"results.json").exists() else [];successes=sum(r["case"]=="corrective" and r["accepted"] for r in results)
 thresholds=json.loads((D/"runs/opposed100_v001/safety_thresholds.json").read_text())
 try:
  cases=[(kind,189) for kind in ("recorded_full","teacher_full") if not any(r["case"]==kind and r["accepted"] and r["thread_engagement_verified"] for r in results)]
  attempted={r["seed"] for r in results if r["case"]=="corrective"}
  cases.extend(("corrective",args.seed+i) for i in range(args.max_attempts) if args.seed+i not in attempted)
  for index,(kind,seed) in enumerate(cases,start=len(results)):
   if kind=="corrective" and successes>=args.successes:break
   trial=out/"trials"/f"{index:03d}_{kind}_{seed}";trial.mkdir(parents=True,exist_ok=False)
   recorder=TrialRecorder(trial,seed,thresholds,label="Task2 "+kind)
   if kind=="recorded_full":
    budget=float(np.load(BASE/"time.npy")[-1])+.1-2.+3.
    source,ns=make_source(args.checkpoint,trial,seed,budget,1,"cuda")
    old="policy_client=PolicyClient(POLICY_CHECKPOINT,device=POLICY_DEVICE,**EXECUTION_OPTIONS)"
    if old not in source:raise RuntimeError("Policy client site missing")
    source=source.replace(old,"policy_client=_recorded_actions",1)
    ns["_recorded_actions"]=RecordedActions()
    ns["_initial_conditions"]=json.loads((BASE/"result.json").read_text())["initial_conditions"]
   else:
    source=(R/"scripts/run_dp_bc.py").read_text()
    source=source.replace("   records.append(rec)","   _trial_recorder.measure(rec,latest,sensor,ci,si,tr,target)\n   records.append(rec)",1)
    source=source.replace("  image_frames.append(images)","  _trial_recorder.frame(images,rec)\n  image_frames.append(images)",1)
    cfg=dict(config)
    if kind=="teacher_full":cfg["method"]="expert"
    ns={"__name__":"__main__","_collection_config":cfg,
        "_episode_root":raw if kind=="corrective" else out/"teacher_data",
        "_diagnostics_root":trial/"diagnostics","_reset_request":out/"reset_requested"}
   write_status(status="RUNNING",case=kind,seed=seed,trial=str(trial),completed_successes=successes)
   def progress(row,perf):
    write_status(measurements=row,performance=perf)
   ns.update(_simulation_app=app,_scene_session=session,_trial_recorder=recorder,
             _progress_callback=progress,_kit_log=out/"kit.log",
             _runtime_metadata={"persistent":True,"worker_id":0,"purpose":"expert_distillation"})
   sys.argv=[str(R/"scripts/run_dp_bc.py"),"--seed",str(seed),"--record"]
   before=time.perf_counter()
   exec(compile(source,str(R/"scripts/run_dp_bc.py"),"exec"),ns)
   report=ns["report"]
   report.update(validation_kind=kind,teacher_enabled=kind!="recorded_full",
                 student_autonomous_success=False)
   if kind=="recorded_full":report["test_kind"]="recorded_action_replay"
   (trial/"result.json").write_text(json.dumps(report,indent=2))
   recorder.finish(report)
   result={"case":kind,"seed":seed,"accepted":bool(report.get("accepted")),
           "thread_engagement_verified":bool(report.get("thread_engagement_verified")),
           "policy_commands":report.get("execution_counts",{}).get("policy",0),
           "error":report.get("error"),"wall_s":time.perf_counter()-before,"trial":str(trial)}
   results.append(result)
   if kind=="corrective" and result["accepted"]:
    if not result["policy_commands"]:raise RuntimeError("Corrective episode did not execute student commands")
    successes+=1
   (out/"results.json").write_text(json.dumps(results,indent=2))
   render_setup=ns.get("setup_render")
   render={k:getattr(render_setup,k) for k in ("anns","products","paths","manifest")} if hasattr(render_setup,"anns") else {}
   ns["sim"].stop()
   session=dict(sim=ns["sim"],initial_transforms=ns["initial_transforms"],assembly_geometry=ns["assembly_geometry"],render=render)
   ns["view"].invalidate()
   ns.clear();del recorder,render_setup;gc.collect()
   write_status(completed_successes=successes,last_result=result)
   if kind!="corrective" and (not result["accepted"] or not result["thread_engagement_verified"]):
    raise RuntimeError("Full replay/teacher verification failed: "+str(trial))
  if successes<args.successes:raise RuntimeError("Corrective collection attempt budget exhausted")
  write_status(status="COMPLETE",completed_successes=successes)
 except Exception as exc:
  write_status(status="NEEDS_REPAIR",error=str(exc))
  (out/"error.txt").write_text(traceback.format_exc())
  raise
 finally:
  for ann in session.get("render",{}).get("anns",{}).values():ann.detach()
  for product in session.get("render",{}).get("products",[]):product.destroy()
  app.close()
if __name__=="__main__":main()
