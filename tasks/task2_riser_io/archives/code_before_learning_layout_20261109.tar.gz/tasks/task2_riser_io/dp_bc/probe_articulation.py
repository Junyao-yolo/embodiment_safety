"""Measure cable articulation stability through the seated-terminal check."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=(R/"scripts/run_dp_bc.py").read_text()
s=s.replace("R/'dp_bc/current_kit.log'","R/'dp_bc/articulation_probe_kit.log'")
s=s.replace("body_api.CreateSolverPositionIterationCountAttr(128)","body_api.CreateSolverPositionIterationCountAttr(32)")
s=s.replace("report['solver_position_iterations']=128","report['solver_position_iterations']=32")
s=s.replace("'segments':seg.native.get_transforms()", "'segments':sensor.native.get_link_transforms()[0,[ln.index('Segment_'+str(i).zfill(2)) for i in range(24)]]")
anchor=" physics_hz=args.physics_hz"
s=s.replace(anchor," for p in stage.Traverse():\n  if str(p.GetPath()).startswith('/wire1/Bend_'):\n   UsdPhysics.Joint(p).CreateExcludeFromArticulationAttr(False)\n"+anchor,1)
s=s.replace("except Exception as e:\n", "except Exception as e:\n print('POSE_DIAG', {k:np.asarray(v).tolist() for k,v in latest.items() if k in ['segments','ring','screw']},flush=True)\n",1)
exec(compile(s,str(R/"scripts/run_dp_bc.py"),"exec"),{"__name__":"__main__"})
