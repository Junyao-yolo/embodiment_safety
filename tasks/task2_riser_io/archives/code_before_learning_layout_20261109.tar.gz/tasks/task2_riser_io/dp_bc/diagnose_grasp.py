"""Compare recorded and learned Task2 grasp actions under the same reset."""
from pathlib import Path
import gc,json,sys,time
import numpy as np
D=Path(__file__).resolve().parent
from evaluate_batch import make_source
from interface import action_block_to_targets
EP=D/"data/opposed_v002/raw/episode_0189"
OUT=D/"evaluations/grasp_comparison_v001"
OUT.mkdir(parents=True,exist_ok=True)
CHECKPOINT=D/"runs/opposed100_v001/policy_bn_synced.pt"
class RecordedActions:
 def __init__(self):
  self.actions=np.load(EP/"executed_action.npy")
  self.times=np.load(EP/"time.npy")
  self.cursor=int(np.searchsorted(self.times,2.-1e-7))
 def act(self,images,state):
  result=action_block_to_targets(self.actions[self.cursor])
  self.cursor+=1
  return result
 def close(self):pass

def main():
 from isaacsim import SimulationApp
 app=SimulationApp({"headless":True,"limit_cpu_threads":4,"width":128,"height":128,
  "sync_loads":True,"extra_args":["--/log/file="+str(OUT/"kit.log")]})
 from trial_recorder import TrialRecorder
 threshold=json.loads((D/"runs/opposed100_v001/safety_thresholds.json").read_text())
 session={};results=[]
 try:
  for name,steps,shared in [("recorded",1,False),("policy_1",1,False),("policy_8",8,False),("policy_1_shared_limits",1,True)]:
   out=OUT/name;out.mkdir(exist_ok=True)
   recorder=TrialRecorder(out,189,threshold)
   source,ns=make_source(CHECKPOINT,out,189,12.,steps,"cuda")
   ns.update(_simulation_app=app,_scene_session=session,_trial_recorder=recorder,_kit_log=OUT/"kit.log")
   if name=="recorded":
    source=source.replace("policy_client=PolicyClient(POLICY_CHECKPOINT,device=POLICY_DEVICE,**EXECUTION_OPTIONS)",
                          "policy_client=_recorded_actions")
    ns["_recorded_actions"]=RecordedActions()
   if shared:
    source=source.replace(" velocity_cmd=np.zeros(7);limited=0;",
                          " from feedback import JointCommandLimits\n command_limiter=JointCommandLimits(q)\n velocity_cmd=np.zeros(7);limited=0;")
    start=source.index("   desired=(proposed[:7]-q[:7])*60.")
    end=source.index("   robot.set_dof_position_targets",start)
    source=source[:start]+"""   proposal_jump=max(proposal_jump,float(np.max(np.abs(proposed[:7]-q[:7]))))
   next_command=command_limiter.commit(proposed)
   limited+=int(np.max(np.abs(next_command[:7]-proposed[:7]))>1e-5);issued+=1
   q[:]=next_command
"""+source[end:]
   source=source.replace(" phase='policy'\n", " phase='policy'\n policy_proposals=[]\n")
   source=source.replace("  proposal=policy_client.act(image_frames[-1],state)",
      "  proposal=policy_client.act(image_frames[-1],state)\n  policy_proposals.append(dict(time_s=stepnum/physics_hz,state=state.tolist(),proposal=proposal.tolist()))")
   def progress(row,perf):
    (OUT/"progress.json").write_text(json.dumps({"status":"RUNNING","case":name,"completed":len(results),"time_s":row["time_s"]},indent=2))
   ns["_progress_callback"]=progress
   sys.argv=[str(D.parent/"scripts/run_dp_bc.py"),"--seed","189","--record"]
   before=time.perf_counter()
   exec(compile(source,str(D.parent/"scripts/run_dp_bc.py"),"exec"),ns)
   report=ns["report"]
   report["diagnostic_case"]=name
   (out/"result.json").write_text(json.dumps(report,indent=2))
   recorder.finish(report)
   (out/"proposals.json").write_text(json.dumps(ns.get("policy_proposals",[])))
   result={k:report.get(k) for k in ["wire_lifted","wire_seated","max_ring_lift_m","max_proposed_joint_jump_rad","limited_command_fraction","smoothness","error"]}
   result.update(case=name,wall_s=time.perf_counter()-before,video=str(out/"rollout.mp4"))
   results.append(result);print(json.dumps(result),flush=True)
   (OUT/"summary.json").write_text(json.dumps(results,indent=2))
   client=ns.get("policy_client")
   if client is not None and (not hasattr(client,"proc") or not client.proc.stdin.closed):client.close()
   render_setup=ns.get("setup_render")
   render={key:getattr(render_setup,key) for key in ("anns","products","paths","manifest")}
   ns["sim"].stop()
   session=dict(sim=ns["sim"],initial_transforms=ns["initial_transforms"],assembly_geometry=ns["assembly_geometry"],render=render)
   ns["view"].invalidate();ns.clear();gc.collect()
  (OUT/"progress.json").write_text(json.dumps({"status":"COMPLETE","completed":len(results)},indent=2))
 finally:
  for ann in session.get("render",{}).get("anns",{}).values():ann.detach()
  for product in session.get("render",{}).get("products",[]):product.destroy()
  app.close()
if __name__=="__main__":main()
