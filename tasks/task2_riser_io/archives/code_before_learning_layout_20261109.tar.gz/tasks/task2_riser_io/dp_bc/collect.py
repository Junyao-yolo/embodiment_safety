"""Launch Task2 collection with a persistent Isaac Sim process."""
from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parents[1];D=R/"dp_bc"
with (D/"worker.log").open("w") as log:
    result=subprocess.run(["/mnt/data2/isaacsim-5.0.0/python.sh","-B",str(D/"collect_persistent.py"),*sys.argv[1:]],cwd=R,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
