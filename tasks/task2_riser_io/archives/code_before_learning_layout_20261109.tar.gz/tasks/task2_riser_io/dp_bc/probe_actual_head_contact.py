"""Synchronized three-camera recordings of contact-driven assembly attempts."""
from pathlib import Path
import argparse,sys,json,csv,traceback,time
import numpy as np
from scipy.spatial.transform import Rotation
R=Path('/mnt/data2/wjy_SERL/Embodied_Safety/tasks/task2_riser_io')
sys.path.insert(0,str(R/'dp_bc'))
from acceptance import ACCEPTANCE_VERSION,assembly_hold,hold_passed
pa=argparse.ArgumentParser()
pa.add_argument('--seed',type=int,default=0);pa.add_argument('--record',action='store_true');pa.add_argument('--probe-wire',action='store_true')
pa.add_argument('--physics-hz',type=int,choices=[120,240,480],default=120)
args=pa.parse_args()
out=R/'dp_bc/contact_fixture'

import io
records=[];frames=[];events=[];image_frames=[];writer=None;app=None;phase='initializing';stepnum=0
rng=np.random.default_rng(args.seed)
variation={'carry_height_m':float(rng.uniform(.865,.885)),'waypoint_x_m':float(rng.uniform(-.008,.008)),'waypoint_y_m':float(rng.uniform(-.008,.008)),'duration_scale':float(rng.uniform(.95,1.15))}
report={'scene':'riser_io_success_v014.usda','full_task_completed':False,'safety_verdict':'UNASSESSED','ring_geometry_unchanged':True,'task_body_pose_writes_after_reset':False,'seed':args.seed,'variation':variation}
report['acceptance_version']=ACCEPTANCE_VERSION
report['clamp_force_role']='diagnostic only; no minimum force magnitude'
contact_log=io.StringIO()
camera_writers={}
performance_totals={}
wall_started=time.perf_counter()
def measured(name):
 def decorate(fn):
  def call(*a,**kw):
   start=time.perf_counter()
   try:return fn(*a,**kw)
   finally:
    entry=performance_totals.setdefault(name,{'seconds':0.,'calls':0})
    entry['seconds']+=time.perf_counter()-start;entry['calls']+=1
  return call
 return decorate
def performance_snapshot():
 return {'wall_seconds':time.perf_counter()-wall_started,'simulation_seconds':stepnum/args.physics_hz,'components':performance_totals}


try:
 sys.argv=[sys.argv[0]]
 from isaacsim import SimulationApp
 app=SimulationApp({'headless':True,'limit_cpu_threads':4,'width':128,'height':128,'sync_loads':True,'extra_args':['--/log/file='+str(R/'dp_bc/contact_fixture_kit.log')]})
 import omni.usd,omni.physics.tensors as tensors,torch
 from pxr import UsdGeom,UsdPhysics,UsdLux,Gf
 from isaacsim.core.api import SimulationContext
 from isaacsim.robot_motion.motion_generation import LulaKinematicsSolver,interface_config_loader
 omni.usd.get_context().open_stage(str(R/'scene/riser_io_success_v014.usda'))
 for _ in range(8):app.update()
 stage=omni.usd.get_context().get_stage();stage.SetEditTarget(stage.GetSessionLayer())
 UsdLux.DomeLight.Define(stage,'/World/DemoLight').CreateIntensityAttr(1500.)
 from pxr import PhysxSchema
 for p in stage.Traverse():
  if p.HasAPI(UsdPhysics.RigidBodyAPI):
   if str(p.GetPath())=='/ScrewTray/Nest_1/Screw_1':
    PhysxSchema.PhysxContactReportAPI.Apply(p).CreateThresholdAttr(0.)
   elif p.HasAPI(PhysxSchema.PhysxContactReportAPI):
    p.RemoveAPI(PhysxSchema.PhysxContactReportAPI)
   body_api=PhysxSchema.PhysxRigidBodyAPI.Apply(p)
   body_api.CreateSolverPositionIterationCountAttr(128)
   body_api.CreateSolverVelocityIterationCountAttr(16)
  if p.HasAPI(UsdPhysics.ArticulationRootAPI):
   articulation_api=PhysxSchema.PhysxArticulationAPI.Apply(p)
   articulation_api.CreateSolverPositionIterationCountAttr(64)
   articulation_api.CreateSolverVelocityIterationCountAttr(16)
 for p in stage.Traverse():
  if p.IsA(UsdPhysics.Scene):
   physics=PhysxSchema.PhysxSceneAPI.Apply(p)
   physics.CreateEnableGPUDynamicsAttr(True)
   physics.CreateBroadphaseTypeAttr('GPU')
 stage.GetPrimAtPath('/wire1/FixedJoint').SetActive(False)
 for prim in stage.Traverse():
  if str(prim.GetPath()).startswith('/NutPlate_Coarse') and prim.HasAPI(UsdPhysics.CollisionAPI):UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(False)
 report['physics_backend']='PhysX GPU'
 report['contact_reporting']='screw contact pairs used by assembly controller and clamp verification'
 for path in ['/World/Robot','/World/CableSensor']:
  PhysxSchema.PhysxArticulationAPI.Apply(stage.GetPrimAtPath(path)).CreateSolverPositionIterationCountAttr(64)
 report['solver_position_iterations']=128
 report['solver_velocity_iterations']=16
 physics_hz=args.physics_hz
 report['physics_rate_Hz']=physics_hz;report['measurement_rate_Hz']=120 if args.record else 60
 dt=1/physics_hz
 sim=SimulationContext(physics_dt=dt,rendering_dt=1/60,backend='torch',device='cuda:0');sim.initialize_physics();sim.play()
 for _ in range(4):sim.step(render=True)
 view=tensors.create_simulation_view('torch');view.set_subspace_roots('/')
 class HostObservations:
  """Expose GPU physics state as NumPy observations to the controller."""
  def __init__(self, native):self.native=native
  def __getattr__(self, name):
   member=getattr(self.native,name)
   if not callable(member):return member
   def call(*args,**kwargs):
    def upload(x):
     if isinstance(x,np.ndarray):
      if x.dtype==np.uint32:x=x.astype(np.int32)
      return torch.as_tensor(x,device='cpu' if name in ['set_dof_max_forces','set_dof_stiffnesses','set_dof_dampings'] else 'cuda:0').contiguous()
     return x
    def download(x):
     if isinstance(x,torch.Tensor):return x.detach().cpu().numpy()
     if isinstance(x,(tuple,list)):return type(x)(download(v) for v in x)
     return x
    value=member(*(upload(v) for v in args),**kwargs)
    if name in ['get_contact_data','get_friction_data']:
     counts,starts=value[-2:]
     used=int(torch.where(counts>0,starts+counts,0).max().item())
     value=tuple(v[:used] for v in value[:-2])+tuple(value[-2:])
    return download(value)
   return call
 robot=HostObservations(view.create_articulation_view('/World/Robot'))
 sensor=HostObservations(view.create_articulation_view('/World/CableSensor'))
 seg=HostObservations(view.create_rigid_body_view('/wire1/Segment_*'))
 rv=HostObservations(view.create_rigid_body_view('/wire1/_0347300_ring_terminal'))
 sv=HostObservations(view.create_rigid_body_view('/ScrewTray/Nest_1/Screw_1'))
 assert robot.count==1 and sensor.count==1 and seg.count==24 and rv.count==1
 names=list(robot.shared_metatype.dof_names);ln=list(sensor.shared_metatype.link_names);si=ln.index('Segment_00')
 ci=next(i for i,n in enumerate(ln) if 'TE_L26620011' in n)
 report['sensor_links']=ln
 report['robot_dof_names']=names
 report['action_representation']='joint position targets at 60 Hz; radians for arm joints and meters for fingers'
 report['clamp_measurement']='normal force under the screw head, evaluated after releasing the gripper'
 solver=LulaKinematicsSolver(**interface_config_loader.load_supported_lula_kinematics_solver_config('Franka'))
 ai=np.array([names.index(n) for n in solver.get_joint_names()]);fi=np.array([names.index('panda_finger_joint1'),names.index('panda_finger_joint2')]);ix=np.array([0],np.uint32)
 base=robot.get_root_transforms()[0];solver.set_robot_base_pose(base[:3],np.r_[base[6],base[3:6]])
 @measured("inverse_kinematics")
 def solve(p,rr,seed):
  joints,ok=(solver.compute_inverse_kinematics('panda_hand',p,np.r_[rr[3],rr[:3]],warm_start=seed,position_tolerance=.00002,orientation_tolerance=.0002) if phase=='initializing' else (None,False))
  if ok and (phase=='initializing' or np.max(np.abs(np.asarray(joints)-seed))<.03):return np.asarray(joints)
  from scipy.optimize import least_squares
  goal=Rotation.from_quat(rr)
  def residual(qs):
   pp,rot=solver.compute_forward_kinematics('panda_hand',qs)
   return np.r_[(np.asarray(pp)-p)*10,(Rotation.from_matrix(rot)*goal.inv()).as_rotvec()]
  lo=np.array([-2.8973,-1.7628,-2.8973,-3.0718,-2.8973,-.0175,-2.8973]);hi=np.array([2.8973,1.7628,2.8973,-.0698,2.8973,3.7525,2.8973])
  if phase!='initializing':
   bounds=(np.maximum(lo+1e-7,seed-.03),np.minimum(hi-1e-7,seed+.03))
   def local_residual(x):return np.r_[residual(x),.01*(x-seed)]
   r=least_squares(local_residual,np.clip(seed,*bounds),bounds=bounds,max_nfev=60,ftol=1e-10,xtol=1e-10,gtol=1e-10)
   err=residual(r.x)
   if np.linalg.norm(err[:3])<.0002 and np.linalg.norm(err[3:])<.0002:return r.x
   raise RuntimeError('continuous IK could not track pose '+str(err))
  best=None
  for start in [seed,[0,-.8,0,-2.6,0,1.8,.7854],[.5,.2,-.5,-2.,0,2.3,0],[-.5,.2,.5,-2.,0,2.3,1.5]]:
   r=least_squares(residual,np.clip(start,lo+1e-6,hi-1e-6),bounds=(lo,hi),max_nfev=160,ftol=1e-10,xtol=1e-10,gtol=1e-10)
   if best is None or np.linalg.norm(r.fun)<np.linalg.norm(best.fun):best=r
   if np.linalg.norm(r.fun[:3])<.005 and np.linalg.norm(r.fun[3:])<.01:return r.x
  raise RuntimeError('IK unreachable: '+str(p)+' residual '+str(best.fun))
 Rdown=np.array([[0.,1.,0.],[1.,0.,0.],[0.,0.,-1.]])
 q=robot.get_dof_positions()[0].copy();q[ai]=[0,-.5,0,-2.2,0,1.7,.7854];q[fi]=.04
 q[ai]=solve(np.array([-.285,.02,1.0434]),Rotation.from_matrix(Rdown).as_quat(),q[ai])
 robot.set_dof_positions(q[None].astype(np.float32),ix);robot.set_dof_velocities(np.zeros_like(q)[None].astype(np.float32),ix);robot.set_dof_position_targets(q[None].astype(np.float32),ix)
 forces=robot.get_dof_max_forces().copy();forces[0,fi]=15.;robot.set_dof_max_forces(forces,ix)
 stiffness=robot.get_dof_stiffnesses().copy();stiffness[0,fi]=400.;robot.set_dof_stiffnesses(stiffness,ix)
 damping=robot.get_dof_dampings().copy();damping[0,fi]=15.;robot.set_dof_dampings(damping,ix)
 report['finger_control']={'stiffness_N_m':400.,'damping_Ns_m':15.,'effort_cap_N':15.}
 jp0=np.array([stage.GetPrimAtPath(f'/wire1/Bend_{i:02d}').GetAttribute('physics:localPos0').Get() for i in range(23)])
 jp1=np.array([stage.GetPrimAtPath(f'/wire1/Bend_{i:02d}').GetAttribute('physics:localPos1').Get() for i in range(23)])
 screw_contacts=HostObservations(view.create_rigid_contact_view('/ScrewTray/Nest_1/Screw_1',['/NutPlate_Coarse/Nut_1/IndependentNut','/wire1/_0347300_ring_terminal','/PCB_4_Terminal/SingleSeat'],2048))
 step_physics=measured('physics_step')(sim.step)
 latched=False
 latest={}
 @measured("state_contact_readback")
 def capture_states():
  normal_data=screw_contacts.native.get_contact_data(dt)
  # PhysX reuses the pair index buffers for friction data on the same contact view.
  normal_data=tuple(normal_data[:-2])+tuple(x.clone() for x in normal_data[-2:])
  requests={
   'segments':seg.native.get_transforms(),'ring':rv.native.get_transforms(),
   'screw':sv.native.get_transforms(),'ring_velocity':rv.native.get_velocities(),
   'joints':robot.native.get_dof_positions(),'joint_velocities':robot.native.get_dof_velocities(),
   'screw_contacts':normal_data,'screw_friction':screw_contacts.native.get_friction_data(dt)}
  chunks=[];layout=[];offset=0
  for name,value in requests.items():
   values=value if isinstance(value,(tuple,list)) else [value]
   entries=[]
   for v in values:
    size=v.numel();entries.append((offset,size,tuple(v.shape)));offset+=size
    chunks.append(v.flatten().to(torch.float32))
   layout.append((name,entries,isinstance(value,(tuple,list))))
  packed=torch.cat(chunks).detach().cpu().numpy()
  latest.clear()
  for name,entries,islist in layout:
   values=[packed[o:o+n].reshape(shape) for o,n,shape in entries]
   latest[name]=values if islist else values[0]
 def screw_measure():
  sp=latest['screw'][0].copy();force=np.zeros(3);moment=np.zeros(3)
  sf,cp,cn,dep,counts,starts=latest['screw_contacts']
  ff,fp,fc,fs=latest['screw_friction']
  for nn,ss in zip(counts.ravel(),starts.ravel()):
   sl=slice(int(ss),int(ss+nn))
   if nn:
    v=sf[sl]*cn[sl];force+=v.sum(axis=0);moment+=np.cross(cp[sl]-sp[:3],v).sum(axis=0)
  for nn,ss in zip(fc.ravel(),fs.ravel()):
   sl=slice(int(ss),int(ss+nn))
   if nn:force+=ff[sl].sum(axis=0);moment+=np.cross(fp[sl]-sp[:3],ff[sl]).sum(axis=0)
  axis=Rotation.from_quat(sp[3:]).apply([0,0,1]);axial=float(np.dot(force,axis))
  return sp,abs(axial),float(np.linalg.norm(force-axis*axial)),abs(float(np.dot(moment,axis)))

 def handpose():return solver.compute_forward_kinematics('panda_hand',latest['joints'][0,ai] if latest else robot.get_dof_positions()[0,ai])
 def tick(n=1):
  global stepnum,latched
  for _ in range(n):
   step_physics(render=False);stepnum+=1
   capture_states()
   analysis_started=time.perf_counter()
   tr=latest['segments'];xyz=tr[:,:3];ring=latest['ring'][0]
   gaps=np.linalg.norm(xyz[:-1]+Rotation.from_quat(tr[:-1,3:]).apply(jp0)-xyz[1:]-Rotation.from_quat(tr[1:,3:]).apply(jp1),axis=1)
   sp,sax,slat,storque=screw_measure();sq=Rotation.from_quat(sp[3:])
   if not hasattr(tick,'last_screw_rotation'):tick.last_screw_rotation=sq;tick.screw_angle=0.
   tick.screw_angle+=float(np.dot((sq*tick.last_screw_rotation.inv()).as_rotvec(),sq.apply([0,0,1])))
   tick.last_screw_rotation=sq
   cf,cp,cn,cd,cc,cs=latest['screw_contacts']
   start=int(cs.ravel()[1]);count=int(cc.ravel()[1]);part=slice(start,start+count)
   local=sq.inv().apply(cp[part]-sp[:3])
   under_head=(np.linalg.norm(local[:,:2],axis=1)>.0055)&(np.abs(local[:,2]-.018)<.0005)
   head_force=(cf[part]*cn[part])[under_head].sum(axis=0)
   rec={'time_s':stepnum*dt,'phase':phase,'screw_axial_N':sax,'screw_lateral_N':slat,'screw_torque_Nm':storque,
    'screw_tip_z':float(sp[2]),'screw_x_m':float(sp[0]),'screw_y_m':float(sp[1]),
    'screw_tilt_deg':float(np.degrees(np.arccos(np.clip(sq.apply([0,0,1])[2],-1,1)))),
    'screw_rotation_accumulated_deg':float(np.degrees(tick.screw_angle)),
    'clamp_N':float(abs(np.dot(head_force,sq.apply([0,0,1])))),
    'head_contact_count':int(np.count_nonzero(under_head)),
    'head_contact_signed_sum_N':float(cf[part].reshape(-1)[under_head].sum()),
    'ring_x':float(ring[0]),'ring_y':float(ring[1]),'ring_z':float(ring[2]),
    'ring_speed_m_s':float(np.linalg.norm(latest['ring_velocity'][0,:3])),
    'ring_tilt_deg':float(np.degrees(np.arccos(np.clip(Rotation.from_quat(ring[3:]).as_matrix()[2,2],-1,1)))),
    'robot_joint_positions':latest['joints'][0].tolist(),
    'robot_joint_velocities':latest['joint_velocities'][0].tolist(),'robot_joint_targets':q.tolist(),
    'joint_gap_m':float(gaps.max()),'contact_separation_m':0.}
   records.append(rec)
   active=phase not in ['settle','calibration','initializing']
   if stepnum%(physics_hz//60)==0:
    commanded=q[ai].copy()
    if hasattr(tick,'previous_command'):
     command_v=(commanded-tick.previous_command)*60.
     if hasattr(tick,'previous_command_v') and active:
      command_a=(command_v-tick.previous_command_v)*60.
      if np.max(np.abs(command_v))>2. or np.max(np.abs(command_a))>12.:
       raise RuntimeError('command smoothness limit exceeded')
     tick.previous_command_v=command_v
    tick.previous_command=commanded
   if not np.isfinite(xyz).all() or float(gaps.max())>.010:raise RuntimeError('structural instability')
   entry=performance_totals.setdefault('state_analysis',{'seconds':0.,'calls':0})
   entry['seconds']+=time.perf_counter()-analysis_started;entry['calls']+=1
   if args.record and stepnum%(physics_hz//10)==0:write_frame(rec,tr,ring)
   if stepnum%(physics_hz*5)==0:print('PERFORMANCE',json.dumps(performance_snapshot()),flush=True)
   if stepnum%physics_hz==0:
    print('STATE',json.dumps({k:rec[k] for k in ['time_s','phase','ring_x','ring_y','ring_z','clamp_N']}),flush=True)
 def setup_render():
  import omni.replicator.core as rep
  if hasattr(setup_render,'anns'):return
  external=UsdGeom.Camera.Define(stage,'/World/ExternalCamera')
  external.CreateFocalLengthAttr(23.)
  external.CreateClippingRangeAttr(Gf.Vec2f(.005,10.))
  mat=Gf.Matrix4d().SetLookAt(Gf.Vec3d(.13,-.57,1.35),Gf.Vec3d(-.15,.055,.86),Gf.Vec3d(0,0,1)).GetInverse()
  UsdGeom.Xformable(external).AddTransformOp().Set(mat)
  paths={'external':'/World/ExternalCamera','wrist_left':'/World/Robot/panda_hand/WristCam_L','wrist_right':'/World/Robot/panda_hand/WristCam_R'}
  setup_render.anns={};setup_render.paths=paths;manifest={}
  for name,path in paths.items():
   p=stage.GetPrimAtPath(path)
   if not p or p.GetTypeName()!='Camera':raise RuntimeError('missing camera '+path)
   product=rep.create.render_product(path,(128,128))
   ann=rep.AnnotatorRegistry.get_annotator('rgb');ann.attach([product]);setup_render.anns[name]=ann
   c=UsdGeom.Camera(p)
   manifest[name]={'path':path,'resolution':[128,128],'focal_length':c.GetFocalLengthAttr().Get(),'horizontal_aperture':c.GetHorizontalApertureAttr().Get(),'vertical_aperture':c.GetVerticalApertureAttr().Get(),'local_matrix':np.asarray(UsdGeom.Xformable(p).GetLocalTransformation()).tolist()}
  manifest['external_configuration']='fixed collection camera; task2 has no saved external camera calibration'
  manifest['timestamp']='simulation time; all cameras rendered without intervening physics steps'
  setup_render.manifest=manifest
  for attempt in range(60):
   sim.render()
   if all(a.get_data() is not None and a.get_data().size for a in setup_render.anns.values()):break
  else:raise RuntimeError('three-camera render initialization failed')
 @measured("camera_render_readback")
 def write_frame(rec,tr,ring):
  setup_render();sim.render();images={}
  for name,ann in setup_render.anns.items():
   rgb=ann.get_data()
   if rgb is None or not rgb.size:raise RuntimeError('empty camera '+name)
   images[name]=np.ascontiguousarray(rgb[:,:,:3]).copy()
  image_frames.append(images)
  frames.append({'frame':len(frames),'time_s':rec['time_s'],'phase':phase,
   'ring_pose':ring.tolist(),'screw_pose':latest['screw'][0].tolist(),
   'robot_joints':latest['joints'][0].tolist(),'physics_step':stepnum})
 def event(name):
  row={'event':name,'time_s':stepnum*dt,'ring_pose':rv.get_transforms()[0].tolist()};events.append(row);print('EVENT',json.dumps(row),flush=True)
 def move(tcp,seconds=3.,width=None,rotation=None,stop_force=None):
  global q
  desired=Rdown if rotation is None else rotation
  start,rot=solver.compute_forward_kinematics('panda_hand',q[ai]);end=np.asarray(tcp)-desired@np.array([0,0,.1034])
  r0=Rotation.from_matrix(rot);r1=Rotation.from_matrix(desired);dr=(r1*r0.inv()).as_rotvec()
  steps=max(int(seconds*variation['duration_scale']*60),int(np.ceil(1.875*np.linalg.norm(dr)/1.2*60)));seed=q[ai].copy()
  for k in range(steps):
   t=(k+1)/steps;u=t*t*t*(10+t*(-15+6*t))
   p=start+(end-start)*u;rr=(Rotation.from_rotvec(dr*u)*r0).as_quat()
   nxt=solve(p,rr,seed)
   if np.max(np.abs(nxt-seed))>.08:raise RuntimeError('discontinuous IK target')
   seed=nxt;q[ai]=seed
   if width is not None:q[fi]=width/2
   robot.set_dof_position_targets(q[None].astype(np.float32),ix);tick(physics_hz//60)
  tick(physics_hz//4)
  hp,_=handpose()
  if np.linalg.norm(np.asarray(hp)-end)>.020:raise RuntimeError('hand tracking error')
 def body_move(body,goal,seconds=2.,rotation=None,force_target=None):
  global q
  initial=body.get_transforms()[0].copy();r0=Rotation.from_quat(initial[3:])
  hp,hr=solver.compute_forward_kinematics('panda_hand',q[ai]);grasp_offset=r0.inv().apply(np.asarray(hp)-initial[:3]);grasp_rotation=r0.inv().as_matrix()@hr
  r1=r0 if rotation is None else Rotation.from_matrix(rotation);dr=(r1*r0.inv()).as_rotvec()
  bias=np.zeros(3);angle_bias=np.zeros(3);admittance=0.
  steps=max(int(seconds*variation['duration_scale']*60),int(np.ceil(1.875*np.linalg.norm(dr)/1.2*60)));seed=q[ai].copy()
  for k in range(steps+30):
   t=min(1.,(k+1)/steps);u=t*t*t*(10+t*(-15+6*t))
   desired=initial[:3]+(np.asarray(goal)-initial[:3])*u
   if force_target is not None:
    admittance=float(np.clip(admittance+.000001*(records[-1]['screw_axial_N']-force_target),-.001,.002))
    desired[2]+=admittance
   drt=Rotation.from_rotvec(dr*u)*r0
   actual=(latest['ring'] if body is rv else latest['screw'])[0].copy();ar=Rotation.from_quat(actual[3:])
   error=desired-actual[:3];bias=np.clip(bias+.025*error,-.002,.002)
   if force_target is not None:bias[2]=0.
   angle_bias=np.clip(angle_bias+.015*(drt*ar.inv()).as_rotvec(),-.03,.03)
   rd=(Rotation.from_rotvec(angle_bias)*drt).as_matrix()
   hp=desired+bias+rd@grasp_offset;hr=rd@grasp_rotation
   nxt=solve(hp,Rotation.from_matrix(hr).as_quat(),seed)
   if np.max(np.abs(nxt-seed))>.08:raise RuntimeError('discontinuous IK body target')
   seed=nxt;q[ai]=seed;robot.set_dof_position_targets(q[None].astype(np.float32),ix);tick(physics_hz//60)
 def grip(width,seconds=1.):
  global q
  start=q[fi].copy();steps=int(seconds*60)
  for k in range(steps):
   q[fi]=start+(width/2-start)*(((k+1)/steps)**3*(10+((k+1)/steps)*(-15+6*((k+1)/steps))));robot.set_dof_position_targets(q[None].astype(np.float32),ix);tick(physics_hz//60)

 for body,pos in [(rv,[-.092,-.071,.818]),(sv,[-.092,-.071,.8031])]:
  pose=body.get_transforms().copy();pose[0,:3]=pos;pose[0,3:]=[0,0,0,1]
  body.set_transforms(pose.astype(np.float32),ix)
  body.set_velocities(np.zeros((1,6),np.float32),ix)
 phase='calibration';samples=[]
 for n in range(4):
  tick(30)
  cf,cp,cn,cd,cc,cs=latest['screw_contacts'];sp=latest['screw'][0]
  a=int(cs.ravel()[1]);b=int(cc.ravel()[1]);part=slice(a,a+b)
  loc=Rotation.from_quat(sp[3:]).inv().apply(cp[part]-sp[:3])
  mask=(np.linalg.norm(loc[:,:2],axis=1)>.0055)&(np.abs(loc[:,2]-.018)<.0005)
  f=cf[part].reshape(-1)[mask]
  samples.append(dict(time_s=records[-1]['time_s'],signed_head_forces_N=f.tolist(),ring_pose=latest['ring'][0].tolist(),screw_pose=sp.tolist(),geometric_head_contact_count=int(mask.sum()),
   positive_count=int((f>0).sum()),magnitude_count=int((np.abs(f)>0).sum()),
   observed_head_contact_count=records[-1]['head_contact_count'],clamp_N=records[-1]['clamp_N']))
 result=dict(fixture='gravity contact of actual ring and screw with nut collisions disabled for sensor isolation; not a task trajectory',samples=samples)
 (R/'dp_bc/contact_fixture_result.json').write_text(json.dumps(result,indent=2))
 print('CONTACT_FIXTURE',json.dumps(result),flush=True)
except Exception:
 print(traceback.format_exc(),flush=True)
 raise
finally:
 if app is not None:app.close()
