# Task2 DP-BC

独立于 Task1 的线缆接线与螺丝紧固行为克隆接口。

- 观测：10 Hz，external / wrist_left / wrist_right 三路同步 128×128 RGB。
- 状态：23 维，依次为机械臂关节位置 7、关节速度 7、实际夹爪总宽度 1、上一条关节目标 7、上一条夹爪总宽度 1。
- 动作：48 维，按时间排列的 6×8 个值。每个 8 维指令为 7 个关节位置目标及夹爪总宽度，以 60 Hz 执行。
- 时间关系：观测 t 配对随后 (t,t+0.1] 内实际执行的六条指令。
- 数据：每条成功轨迹一个目录，保存 time/state/action 和三路图像 NPY。失败轨迹不进入训练集；诊断视频保存在 failure_review。
- 验收版本：task2_contact_hold_v003。实际抓取搬运、端子稳定落座、螺纹运动关系、螺丝头接触、松爪保持，以及命令平滑性。
- 停止拧紧与撤手后的装配检查共用 acceptance.py：连续观察 3 秒位姿和稳定性，并要求最后 1 秒内检测到螺丝头底面接触。接触根据物理引擎报告的螺丝头底面接触点识别，不使用力的符号或幅值作为接触门槛。
- 压紧力保留为诊断值，不设 0.2 N 成功门槛。任务完成不代表达到经标定的工程预紧力；安全状态仍为 UNASSESSED。
- 数据加载器的序列长度为 16，不跨轨迹边界。两帧观测预测动作序列，执行当前六条 60 Hz 指令，再获取观测。
- 当前阶段：先收集 5 条，验证训练、检查点恢复、推理、动作解码和实际控制回放，再扩大到 100 条。

所有文件保存在本目录及同一 Task2 目录的 scripts 中。第三方 Diffusion Policy 库和 Python 环境只读复用。

采集入口：python3 -B dp_bc/collect.py

训练入口：/mnt/data2/wjy_SERL/Embodied_Safety/algos/diffusion_policy/.venv/bin/python -B dp_bc/train.py --data dp_bc/data/raw --output dp_bc/runs/pilot5 --steps 100 --batch-size 4 --device cpu

训练接口通过与学习策略完成物理任务是两个指标，训练结果中的 learned_policy_task_success_verified 单独报告。采集结果不提供已标定的材料损伤安全标签。

采集状态：progress.json；五条验证与扩量状态：pilot_progress.json。pilot.py 在五条成功数据齐备后执行 100 次训练更新、检查点重载、推理和完整物理动作回放，通过后将采集目标改为 100。

policy.py 提供观测历史与动作解码；client.py / worker.py 通过本机管道连接仿真环境与推理环境，图像无需临时文件。每次返回 6×9 的 Franka 关节目标，其中夹爪总宽度拆分为两根手指的位置目标。

运动速度配置：motion.json 在每条轨迹启动时读取。default 设置阶段时长倍率、平移峰值速度（mm/s）和旋转峰值速度（rad/s），phases 覆盖指定阶段。motion_timing.py 根据移动距离和转角计算时长，保留五次多项式平滑起止。duration_scale 控制名义时长，速度上限可以进一步延长动作；两者同时约束。每条 result.json 保存实际配置、各段规划时长和各阶段仿真耗时。

当前速度设置由 motion.json 记录。空中搬运与接近、带线移动、螺纹入口和最终保持分别配置；重复旋转采用平滑加速、匀速、平滑减速曲线。每条轨迹记录使用的完整配置，速度参数不代表材料损伤阈值。关节速度、加速度及抖动验收保持不变。

采集由 collect.py 启动 collect_persistent.py：一个 Isaac Sim 进程连续运行，每条关闭上一场景并重新加载初始场景，释放相机产品和物理视图。runtime.json 配置 Fabric 和求解迭代次数；图像频率、状态维数和动作频率仍按原接口。启动时间、单条采集与清理时间分别记录在 collection.log，最终统计应包含失败尝试的耗时。

逆运动学使用 Lula 的解析雅可比，并将旋转雅可比转换为姿态对数误差的导数。profile_output/ik_validation.json 保存其数值差分对照结果；命令仍通过原有连续性和跟踪检查。

Task1 优先等待：wait_for_task1.py 读取 wait_for_task1.json，只有选定 Task1 正式训练完成且 GPU 没有其他计算进程才启动采集；进度见 wait_status.json。Task2 暂停期间不保留 Isaac Sim 进程和显存。
