"""Collect a DAgger round and retrain on all accepted Task2 episodes."""
from pathlib import Path
import argparse,json,subprocess,sys,time
D=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser()
 p.add_argument("--checkpoint",type=Path,required=True)
 p.add_argument("--round",type=int,required=True)
 p.add_argument("--episodes",type=int,default=5)
 p.add_argument("--expert-probability",type=float,default=.8)
 p.add_argument("--train-steps",type=int,default=1000)
 p.add_argument("--n-action-steps",type=int,choices=[1,8],default=8)
 args=p.parse_args()
 if not 0<=args.expert_probability<=1:raise ValueError("Mixture probability must lie in [0,1]")
 if not args.checkpoint.is_file():raise FileNotFoundError(args.checkpoint)
 # Task1 has explicit priority on this shared GPU.
 gpu=subprocess.check_output(["nvidia-smi","--query-compute-apps=pid","--format=csv,noheader"],text=True)
 for pid in gpu.split():
  proc=Path("/proc")/pid/"cmdline"
  if proc.exists() and b"task1" in proc.read_bytes().lower():
   raise RuntimeError("Task1 is using the GPU; leave its process running and retry later")
 out=D/"dagger"/f"round_{args.round:03d}";out.mkdir(parents=True,exist_ok=False)
 config=json.loads((D/"feedback_dagger.json").read_text())
 config.update(checkpoint=str(args.checkpoint.resolve()),expert_probability=args.expert_probability,n_action_steps=args.n_action_steps)
 cfg=out/"collection.json";cfg.write_text(json.dumps(config,indent=2))
 before={p.name for p in (D/"data/raw").glob("episode_*") if (p/"result.json").exists()}
 started=time.perf_counter()
 command=[sys.executable,"-B",str(D/"collect.py"),"--collection-config",str(cfg),
          "--additional-successes",str(args.episodes),"--max-attempts",str(args.episodes*3)]
 status=subprocess.run(command,cwd=D).returncode
 new=[p for p in sorted((D/"data/raw").glob("episode_*")) if p.name not in before and (p/"result.json").exists()
      and json.loads((p/"result.json").read_text()).get("accepted")]
 rows=[json.loads((p/"result.json").read_text()) for p in new]
 report=dict(round=args.round,collection_exit_code=status,new_episodes=[p.name for p in new],
  mixture=config,execution_counts={k:sum(r.get("execution_counts",{}).get(k,0) for r in rows) for k in ("policy","expert","recovery","dart","hold")},
  collection_wall_s=time.perf_counter()-started,learned_policy_success_verified=False)
 (out/"result.json").write_text(json.dumps(report,indent=2))
 if status or len(new)<args.episodes:raise SystemExit(status or 2)
 if not report["execution_counts"]["policy"]:raise RuntimeError("No policy actions executed; this round is not DAgger")
 python=D.parents[2]/"algos/diffusion_policy/.venv/bin/python"
 train=[str(python),"-B",str(D/"train.py"),"--data",str(D/"data/raw"),"--output",str(out/"train"),"--steps",str(args.train_steps)]
 # Train from scratch on the accumulated accepted dataset; the next round uses this checkpoint.
 with (out/"train.log").open("w") as log:
  status=subprocess.run(train,cwd=D,stdout=log,stderr=subprocess.STDOUT).returncode
 report.update(training_exit_code=status,checkpoint=str(out/"train/policy.pt"),wall_s=time.perf_counter()-started)
 (out/"result.json").write_text(json.dumps(report,indent=2))
 raise SystemExit(status)
if __name__=="__main__":main()
