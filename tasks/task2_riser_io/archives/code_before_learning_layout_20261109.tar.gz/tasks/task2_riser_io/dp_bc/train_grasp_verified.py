"""Train Task2 DP-BC on one grasp prefix and measure decoded command accuracy."""
from pathlib import Path
import sys,json,time
import numpy as np
import torch
D=Path(__file__).resolve().parent
from model import build
from interface import CAMERAS
from diffusion_policy.model.common.normalizer import SingleFieldLinearNormalizer
OUT=D/"runs/grasp_fit_v003"
EP=D/"data/opposed_v002/raw/episode_0189"
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 torch.set_num_threads(2);torch.manual_seed(42)
 rng=np.random.default_rng(42);start=time.perf_counter()
 base=torch.load(D/"runs/grasp_delta_v002/policy.pt",map_location="cpu",weights_only=False)
 cfg=dict(base["config"],vision_normalization="group",action_representation="expert_joint_delta_width_v002")
 model=build(cfg)
 weights={k:v for k,v in base["model"].items() if not k.endswith(("running_mean","running_var","num_batches_tracked"))}
 model.load_state_dict(weights);model=model.cuda()
 limit=int(np.searchsorted(np.load(EP/"time.npy"),14.,side="right"))
 x=np.load(EP/"state.npy")[:limit].copy()
 a=np.load(EP/"action.npy")[:limit].copy().reshape(-1,6,8)
 previous=np.concatenate([x[:,15:22,None].transpose(0,2,1),a[:,:-1,:7]],axis=1)
 delta=a.copy();delta[:,:,:7]-=previous
 reconstructed=x[:,15:22,None].transpose(0,2,1)+np.cumsum(delta[:,:,:7],axis=1)
 conversion=float(abs(reconstructed-a[:,:,:7]).max())
 if conversion>2e-6:raise RuntimeError("Expert command conversion failed")
 model.normalizer["action"]=SingleFieldLinearNormalizer.create_fit(delta.reshape(-1,48),mode="limits").cuda()
 state=torch.from_numpy(x).cuda();action=torch.from_numpy(delta.reshape(-1,48)).cuda()
 absolute=torch.from_numpy(a).cuda()
 images={c:torch.from_numpy(np.array(np.load(EP/(c+".npy"),mmap_mode="r")[:limit])).permute(0,3,1,2).float().cuda()/255 for c in CAMERAS}
 def batch(ids):
  ids=np.asarray(ids);oi=torch.as_tensor(ids[:,None]+np.arange(2),device="cuda");ai=torch.as_tensor(ids[:,None]+np.arange(model.horizon),device="cuda")
  return {"obs":{**{c:images[c][oi] for c in CAMERAS},"state":state[oi]},"action":action[ai]}
 settings={"episode":str(EP),"prefix_seconds":14,"max_steps":20000,"batch_size":16,"precision":"float32",
  "initial_learning_rate":1e-4,"normalization":"GroupNorm","source_checkpoint":str(D/"runs/grasp_delta_v002/policy.pt"),
  "expert_action_conversion_max_error_rad":conversion,"policy_inputs":"23 state and 3 RGB cameras, two observations; no phase or clock",
  "offline_fit_criteria":{"decoded_arm_p95_rad":.00025,"decoded_arm_max_rad":.001,"gripper_p95_m":.001},
  "criteria_scope":"Diagnostic action-fit gate only; learned grasp and full-task success require autonomous simulation execution."}
 (OUT/"config.json").write_text(json.dumps(settings,indent=2))
 opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-6)
 losses=[];checks=[]
 def validate(step):
  model.eval();errors=[];widths=[]
  with torch.no_grad():
   for first in range(18,limit-model.horizon+1,16):
    ids=np.arange(first,min(first+16,limit-model.horizon+1))
    b=batch(ids);torch.manual_seed(189)
    pred=model.predict_action(b["obs"])["action"][:,0].reshape(-1,6,8)
    current=state[torch.as_tensor(ids+1,device="cuda"),15:22]
    decoded=current[:,None,:]+pred[:,:,:7].cumsum(dim=1)
    truth=absolute[torch.as_tensor(ids+1,device="cuda")]
    errors.append((decoded-truth[:,:,:7]).abs().flatten())
    widths.append((pred[:,:,7]-truth[:,:,7]).abs().flatten())
  error=torch.cat(errors);width=torch.cat(widths)
  result={"step":step,"decoded_arm_mae_rad":float(error.mean()),"decoded_arm_p95_rad":float(torch.quantile(error,.95)),
   "decoded_arm_max_rad":float(error.max()),"gripper_p95_m":float(torch.quantile(width,.95)),
   "wall_s":time.perf_counter()-start}
  result["offline_fit_passed"]=result["decoded_arm_p95_rad"]<=.00025 and result["decoded_arm_max_rad"]<=.001 and result["gripper_p95_m"]<=.001
  checks.append(result);(OUT/"action_validation.json").write_text(json.dumps(checks,indent=2))
  torch.save({"config":cfg,"model":model.state_dict(),"steps":step,"training":settings},OUT/"policy.pt")
  model.train()
  return result
 model.train()
 with (OUT/"metrics.jsonl").open("w") as log:
  for step in range(1,20001):
   b=batch(rng.integers(18,limit-model.horizon+1,size=16));opt.zero_grad(set_to_none=True)
   lr=1e-5+9e-5*.5*(1+np.cos(np.pi*(step-1)/20000))
   for group in opt.param_groups:group["lr"]=lr
   loss=model.compute_loss(b)
   if not torch.isfinite(loss):raise RuntimeError("Nonfinite loss")
   loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
   losses.append(float(loss.detach()))
   if step%100==0:
    row={"status":"TRAINING","step":step,"total_steps":20000,"loss_mean_100":float(np.mean(losses[-100:])),"wall_s":time.perf_counter()-start}
    log.write(json.dumps(row)+"\n");log.flush()
    (OUT/"progress.json").write_text(json.dumps(row,indent=2))
   if step%2000==0:
    check=validate(step);print(json.dumps(check),flush=True)
    if check["offline_fit_passed"]:break
 result=dict(checks[-1],status="OFFLINE_FIT_PASSED" if checks[-1]["offline_fit_passed"] else "OFFLINE_FIT_INSUFFICIENT",
  learned_grasp_verified=False,learned_full_task_verified=False,simulation_started=False)
 (OUT/"result.json").write_text(json.dumps(result,indent=2));(OUT/"progress.json").write_text(json.dumps(result,indent=2))
 print(json.dumps(result),flush=True)
if __name__=="__main__":main()
