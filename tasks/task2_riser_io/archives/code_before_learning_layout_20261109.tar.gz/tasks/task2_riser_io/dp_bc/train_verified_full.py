"""Train Task2 DP-BC on all 100 demonstrations and verify a training initial state."""
from pathlib import Path
import argparse,copy,json,math,os,random,subprocess,time
import numpy as np
import torch
from torch.utils.data import DataLoader,Sampler
from data import Task2Data
from model import build
from interface import CAMERAS
from diffusion_policy.model.common.normalizer import SingleFieldLinearNormalizer
from diffusion_policy.model.diffusion.ema_model import EMAModel
D=Path(__file__).resolve().parent
class PhaseBatches(Sampler):
 def __init__(self,data,steps,batch_size,seed):
  self.steps=steps;self.batch_size=batch_size;self.seed=seed;groups={}
  phases=[json.loads((Path(e["path"])/"episode.json").read_text())["phases"] for e in data.episodes]
  for index,(ep,k) in enumerate(data.starts):
   phase=phases[ep][k+1]
   if phase=="settle" and k<18:continue
   groups.setdefault((ep,phase),[]).append(index)
  self.groups=[(phase,np.asarray(ids)) for (_,phase),ids in groups.items()]
 def __len__(self):return self.steps
 def __iter__(self):
  rng=np.random.default_rng(self.seed);issued=0
  while issued<self.steps:
   for group in rng.permutation(len(self.groups)):
    phase,ids=self.groups[group]
    count=2 if phase in {"settle","wire_verify","preload_verify","full_verify"} else 8
    for _ in range(count):
     if issued>=self.steps:return
     yield rng.choice(ids,size=self.batch_size,replace=len(ids)<self.batch_size).tolist()
     issued+=1
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--steps",type=int,default=40000)
 ap.add_argument("--output",type=Path,required=True);args=ap.parse_args()
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 begin=time.perf_counter();torch.set_num_threads(2);torch.manual_seed(42);np.random.seed(42);random.seed(42)
 torch.set_float32_matmul_precision("highest")
 def progress(**row):
  row["wall_s"]=time.perf_counter()-begin
  (out/"progress.json").write_text(json.dumps(row,indent=2))
  return row
 progress(status="LOADING_DATA")
 data=Task2Data(D/"data/opposed_v002/raw")
 if len(data.episodes)!=100:raise RuntimeError("Expected all 100 Task2 demonstrations")
 max_conversion=0.
 for e in data.episodes:
  absolute=np.array(e["action"]).reshape(-1,6,8)
  previous=np.concatenate([np.asarray(e["state"])[:,15:22,None].transpose(0,2,1),absolute[:,:-1,:7]],axis=1)
  delta=absolute.copy();delta[:,:,:7]-=previous
  rebuilt=np.asarray(e["state"])[:,15:22,None].transpose(0,2,1)+np.cumsum(delta[:,:,:7],axis=1)
  max_conversion=max(max_conversion,float(abs(rebuilt-absolute[:,:,:7]).max()))
  e["action"]=delta.reshape(-1,48)
 if max_conversion>2e-6:raise RuntimeError("Expert command representation is not reversible")
 base=torch.load(D/"runs/grasp_fit_v003/policy.pt",map_location="cpu",weights_only=False)
 cfg=base["config"];model=build(cfg);model.load_state_dict(base["model"])
 model.normalizer["action"]=SingleFieldLinearNormalizer.create_fit(np.concatenate([e["action"] for e in data.episodes]),mode="limits")
 model=model.cuda();ema_model=copy.deepcopy(model);ema=EMAModel(ema_model,power=.75)
 opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-6)
 sampler=PhaseBatches(data,args.steps,16,42)
 loader=DataLoader(data,batch_sampler=sampler,num_workers=2,pin_memory=True,persistent_workers=True,prefetch_factor=2)
 settings={"model":cfg,"episodes":100,"episode_paths":[e["path"] for e in data.episodes],"available_sequences":len(data),
  "steps":args.steps,"batch_size":16,"precision":"float32; TF32 disabled","learning_rate":1e-4,"optimizer":"AdamW",
  "weight_decay":1e-6,"gradient_clip_norm":1.,"ema_power":.75,"source_checkpoint":str(D/"runs/grasp_fit_v003/policy.pt"),
  "sampling":"Shuffle episode-phase groups; 8 batches per motion group, 2 per verification/settle group; sample windows within each group.",
  "policy_inputs":"23-dimensional state, three RGB cameras, two observations; no phase labels or elapsed time.",
  "action_representation":"Expert joint increments within each six-command block; absolute gripper width.",
  "conversion_max_error_rad":max_conversion,
  "verification":"Training initial seed 189: autonomous grasp first, then complete assembly; 100-trial benchmark remains stopped."}
 (out/"config.json").write_text(json.dumps(settings,indent=2))
 def cuda(x):return {k:cuda(v) for k,v in x.items()} if isinstance(x,dict) else x.cuda(non_blocking=True)
 def checkpoint(step):
  payload={"config":cfg,"model":ema_model.state_dict(),"steps":step,"training":settings}
  tmp=out/"policy.pt.tmp";torch.save(payload,tmp);os.replace(tmp,out/"policy.pt")
  tmp=out/"training_state.pt.tmp"
  torch.save({"raw_model":model.state_dict(),"optimizer":opt.state_dict(),"steps":step},tmp)
  os.replace(tmp,out/"training_state.pt")
 losses=[];training_start=time.perf_counter()
 with (out/"metrics.jsonl").open("w") as log:
  for step,b in enumerate(loader,1):
   b=cuda(b);model.train();opt.zero_grad(set_to_none=True)
   warmup=min(1.,step/500);fraction=max(0.,(step-500)/max(1,args.steps-500))
   lr=warmup*(1e-5+9e-5*.5*(1+math.cos(math.pi*fraction)))
   for group in opt.param_groups:group["lr"]=lr
   loss=model.compute_loss(b)
   if not torch.isfinite(loss):raise RuntimeError("Nonfinite training loss")
   loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();ema.step(model)
   with torch.no_grad():
    buffers=dict(model.named_buffers())
    for name,buffer in ema_model.named_buffers():buffer.copy_(buffers[name])
   losses.append(float(loss.detach()))
   log.write(json.dumps({"step":step,"loss":losses[-1],"learning_rate":lr,"train_wall_s":time.perf_counter()-training_start})+"\n")
   if step%100==0:
    log.flush();elapsed=time.perf_counter()-training_start
    row=progress(status="TRAINING",step=step,total_steps=args.steps,loss_mean_100=float(np.mean(losses[-100:])),
      train_wall_s=elapsed,seconds_per_step=elapsed/step,remaining_s=elapsed/step*(args.steps-step))
    print(json.dumps(row),flush=True)
   if step%5000==0 or step==args.steps:checkpoint(step)
 del loader,model,ema_model,opt,b;torch.cuda.empty_cache()
 train_wall=time.perf_counter()-training_start
 (out/"training_result.json").write_text(json.dumps({"status":"TRAINING_FINISHED","steps":args.steps,
  "training_wall_s":train_wall,"last_100_loss":float(np.mean(losses[-100:])),"learned_full_task_verified":False},indent=2))
 evaluations=[]
 for label,seconds in [("training_grasp",12),("training_full",360)]:
  evaluation=out/label;evaluation.mkdir()
  command=["/mnt/data2/isaacsim-5.0.0/python.sh","-B",str(D/"evaluate_batch.py"),"--checkpoint",str(out/"policy.pt"),
   "--output",str(evaluation),"--trials","1","--seed","189","--max-seconds",str(seconds),
   "--n-action-steps","1","--policy-device","cuda","--thresholds",str(D/"runs/opposed100_v001/safety_thresholds.json")]
  progress(status="VERIFYING_"+label.upper(),command=command,training_wall_s=train_wall)
  with (evaluation/"worker.log").open("w") as log:
   completed=subprocess.run(command,cwd=D,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  path=evaluation/"trial_000/result.json";report=json.loads(path.read_text()) if path.exists() else {}
  valid=bool(report.get("command_blocks",0)>0 and report.get("error") in (None,"released assembly incomplete"))
  result={"stage":label,"valid_execution":valid,"wire_lifted":bool(report.get("wire_lifted")),
   "functional_assembly_completed":bool(report.get("accepted")),"thread_engagement_verified":bool(report.get("thread_engagement_verified")),
   "evaluation":str(evaluation),"exit_code":completed.returncode}
  evaluations.append(result)
  if not valid or not result["wire_lifted"]:break
 full=next((x for x in evaluations if x["stage"]=="training_full"),{})
 verified=bool(full.get("valid_execution") and full.get("functional_assembly_completed") and full.get("thread_engagement_verified"))
 result=progress(status="TRAINING_INITIAL_FULL_TASK_VERIFIED" if verified else "NEEDS_FURTHER_TRAINING_DIAGNOSIS",
  learned_full_task_verified=verified,verification=evaluations,training_wall_s=train_wall,batch_100_evaluation_started=False)
 (out/"result.json").write_text(json.dumps(result,indent=2))
 print(json.dumps(result),flush=True)
if __name__=="__main__":main()
