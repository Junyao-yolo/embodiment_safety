"""Validate five successful episodes before expanding collection."""
from pathlib import Path
import json,subprocess,time
R=Path(__file__).resolve().parents[1];D=R/"dp_bc"
PY="/mnt/data2/wjy_SERL/Embodied_Safety/algos/diffusion_policy/.venv/bin/python"
def save(x):(D/"pilot_progress.json").write_text(json.dumps(x,indent=2))
save({"status":"COLLECTING_PILOT","target":5})
while True:
 state=json.loads((D/"progress.json").read_text())
 if state["status"]=="NEEDS_REPAIR":save({"status":"COLLECTION_NEEDS_REPAIR"});raise SystemExit(1)
 if state["completed_successes"]>=5 and state["status"]=="PILOT_READY":break
 time.sleep(10)
save({"status":"TRAINING_PILOT","episodes":5})
with (D/"pilot_train.log").open("w") as log:
 p=subprocess.run([PY,"-B",str(D/"train.py"),"--data",str(D/"data/raw"),"--output",str(D/"runs/pilot5"),"--steps","100","--batch-size","4","--device","cpu"],stdout=log,stderr=subprocess.STDOUT)
if p.returncode:save({"status":"TRAINING_FAILED"});raise SystemExit(1)
training=json.loads((D/"runs/pilot5/result.json").read_text())
episodes=sorted(p for p in (D/"data/raw").glob("episode_*") if (p/"result.json").exists())
source=episodes[-1]
save({"status":"VERIFYING_PHYSICAL_ACTION_REPLAY","episode":source.name,"training":training})
with (D/"replay.log").open("w") as log:
 p=subprocess.run(["/mnt/data2/isaacsim-5.0.0/python.sh","-B",str(D/"replay.py"),"--episode",str(source)],stdout=log,stderr=subprocess.STDOUT,cwd=R)
rp=D/"replay"/source.name/"result.json"
replay=json.loads(rp.read_text()) if rp.exists() else {}
if p.returncode or not replay.get("accepted"):
 save({"status":"REPLAY_FAILED","training":training,"replay":replay});raise SystemExit(1)
save({"status":"PILOT_PASSED_EXPANDING_TO_100","episodes":5,"training":training,"physical_action_replay_accepted":True,"learned_policy_task_success_verified":False})
(D/"collection.json").write_text(json.dumps({"target":100},indent=2))
with (D/"collection.log").open("a") as log:
 p=subprocess.run(["python3","-B",str(D/"collect.py")],stdout=log,stderr=subprocess.STDOUT,cwd=R)
save({"status":"COLLECTION_COMPLETE" if p.returncode==0 else "COLLECTION_NEEDS_REPAIR","pilot_passed":True,"learned_policy_task_success_verified":False})
