"""Prepare whole-reset-group splits and an official Task2 DP-C configuration."""
import common
import argparse,json,math,shutil
from collections import Counter
from pathlib import Path
import numpy as np
from omegaconf import OmegaConf

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,required=True);ap.add_argument("--epochs",type=int,default=100);a=ap.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    source=common.ROOT/"algos/diffusion_policy/vendor/diffusion_policy/config/train_diffusion_unet_hybrid_workspace.yaml"
    official=OmegaConf.to_container(OmegaConf.load(source),resolve=False)
    root=common.DP/"data/opposed_v002/raw"
    episodes=[];max_error=0.
    for p in sorted(root.glob("episode_*")):
        if not (p/"result.json").exists():continue
        result=json.loads((p/"result.json").read_text())
        if not result.get("accepted"):continue
        meta=json.loads((p/"episode.json").read_text())
        state=np.load(p/"state.npy",mmap_mode="r");action=np.load(p/"action.npy",mmap_mode="r")
        delta=common.delta_actions(state,action).reshape(-1,6,8)
        recovered=state[:,None,15:22]+np.cumsum(delta[:,:,:7],axis=1)
        max_error=max(max_error,float(np.abs(recovered-action.reshape(-1,6,8)[:,:,:7]).max()))
        n=len(state)
        assert state.shape==(n,23) and action.shape==(n,48)
        assert all(np.load(p/(c+".npy"),mmap_mode="r").shape==(n,128,128,3) for c in common.CAMERAS)
        episodes.append(dict(path=str(p),samples=n,windows=n-7,
            reset_group=int(meta["initial_conditions"]["reset_seed"]),route=meta["route_mode"]))
    assert len(episodes)==100
    assert max_error<2e-6
    groups=np.array(sorted({e["reset_group"] for e in episodes}))
    rng=np.random.default_rng(42);vg=set(rng.permutation(groups)[:math.ceil(len(groups)*.1)].tolist())
    for e in episodes:e["split"]="validation" if e["reset_group"] in vg else "train"
    counts={s:dict(episodes=sum(e["split"]==s for e in episodes),
              windows=sum(e["windows"] for e in episodes if e["split"]==s),
              reset_groups=sorted({e["reset_group"] for e in episodes if e["split"]==s}),
              routes=dict(Counter(e["route"] for e in episodes if e["split"]==s))) for s in ("train","validation")}
    manifest=dict(episodes=episodes,counts=counts,seed=42,action_roundtrip_max_error_rad=max_error,
        sequence_sampling="Official padded horizon16: pad_before=1, pad_after=7; uniform shuffled windows",
        labels="Clean expert joint deltas within each six-command slot; absolute gripper width",
        observations="Actual rollout RGB/state; previous targets are actual executed commands")
    common.write_json(out/"data_manifest.json",manifest)
    policy=official["policy"]
    policy.update(shape_meta={"action":{"shape":[48]},"obs":{
        **{c:{"shape":[3,128,128],"type":"rgb"} for c in common.CAMERAS},
        "state":{"shape":[23],"type":"low_dim"}}},horizon=16,n_obs_steps=2,n_action_steps=8,obs_as_global_cond=True)
    spe=math.ceil(counts["train"]["windows"]/64)
    epochs=a.epochs
    cfg=dict(seed=42,output_dir=str(out),manifest=str(out/"data_manifest.json"),
        data=str(root),official_source_epochs=int(official["training"]["num_epochs"]),model_kind="official_hybrid",official_source=str(source),
        official_policy=policy,batch_size=64,num_workers=8,epochs=epochs,
        steps_per_epoch=spe,updates=epochs*spe,scheduler_total_steps=epochs*spe,
        lr=1e-4,warmup_steps=500,precision="float32; TF32 disabled",gradient_clipping=None,
        optimizer={"name":"AdamW","betas":[.95,.999],"eps":1e-8,"weight_decay":1e-6},
        ema={"update_after_step":0,"inv_gamma":1.,"power":.75,"min_value":0.,"max_value":.9999},
        pad_before=1,pad_after=7,validate_every=spe,checkpoint_every=spe,
        action_representation="expert_joint_delta_width_v002",image_normalization="uint8/255, then [-1,1]",
        normalizer="Train-only per-dimension limits for state and action; original range_eps=1e-4",
        validation="Four complete reset groups held out; no adjacent route leakage",
        full_task_success_verified=False,stage_report_epochs=[1,10,50,100],
        train_episodes=counts["train"]["episodes"],validation_episodes=counts["validation"]["episodes"],
        train_windows=counts["train"]["windows"],validation_windows=counts["validation"]["windows"],
        source_checkpoint=None)
    common.write_json(out/"config.json",cfg)
    shutil.copyfile(source,out/"official_source.yaml")
    print(json.dumps(dict(output=str(out),counts=counts,steps_per_epoch=spe,full_updates=cfg["updates"],epochs=epochs),ensure_ascii=False))
if __name__=="__main__":main()
