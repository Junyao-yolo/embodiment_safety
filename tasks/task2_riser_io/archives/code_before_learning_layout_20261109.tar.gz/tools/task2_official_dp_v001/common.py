"""Task2 observations and action sequences for the official DP-C model."""
import os,sys,json,zlib
from functools import lru_cache
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
DP=ROOT/"tasks/task2_riser_io/dp_bc"
BENCH=ROOT/"tools/tool_hang_benchmark_v001"
sys.path[:0]=[str(BENCH/"official_deps"),str(BENCH/"deps"),str(ROOT/"algos/diffusion_policy/vendor")]
for k in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS"):
    os.environ[k]="4"
os.environ.setdefault("WANDB_MODE","disabled")
import numpy as np
import torch
from torch.utils.data import Dataset
CAMERAS=("external","wrist_left","wrist_right")

def write_json(path,value):
    path=Path(path);temp=path.with_suffix(".tmp")
    temp.write_text(json.dumps(value,indent=2,ensure_ascii=False));temp.replace(path)

def build(cfg):
    import hydra
    from omegaconf import OmegaConf
    return hydra.utils.instantiate(OmegaConf.create(cfg["official_policy"]))

def delta_actions(state,absolute):
    a=np.asarray(absolute,np.float32).reshape(-1,6,8)
    prev=np.concatenate([np.asarray(state)[:,None,15:22],a[:,:-1,:7]],axis=1)
    out=a.copy();out[:,:,:7]-=prev
    return out.reshape(-1,48)

@lru_cache(maxsize=1)
def load_rgb_cache(cache):
    meta=json.loads((cache/"manifest.json").read_text())
    assert meta["status"]=="COMPLETE"
    index=np.load(cache/"index.npy")
    blob=np.fromfile(cache/"rgb.bin",dtype=np.uint8)
    blob.flags.writeable=False
    return meta,index,blob

class Sequences(Dataset):
    def __init__(self,cfg,split):
        self.cfg=cfg
        meta=json.loads(Path(cfg["manifest"]).read_text())
        self.records=[x for x in meta["episodes"] if x["split"]==split]
        cache=Path(cfg["output_dir"])/"rgb_cache"
        cache_meta,self.cache_index,self.cache_blob=load_rgb_cache(cache)
        self.cache_offsets={e["path"]:e["offset"] for e in cache_meta["episodes"]}
        self.arrays=[]
        self.ends=[]
        total=0
        for row in self.records:
            p=Path(row["path"])
            e={k:np.load(p/(k+".npy"),mmap_mode="r") for k in ("state","action")}
            e["delta"]=delta_actions(e["state"],e["action"])
            self.arrays.append(e)
            total+=row["windows"];self.ends.append(total)
        self.ends=np.asarray(self.ends,np.int64)
    def __len__(self):return int(self.ends[-1])
    def __getitem__(self,index):
        ep=int(np.searchsorted(self.ends,index,side="right"))
        offset=index-(int(self.ends[ep-1]) if ep else 0)
        start=offset-self.cfg["pad_before"]
        e=self.arrays[ep];n=len(e["state"])
        obs_ids=np.clip(start+np.arange(2),0,n-1)
        act_ids=np.clip(start+np.arange(16),0,n-1)
        obs={}
        base=self.cache_offsets[self.records[ep]["path"]]
        for ci,c in enumerate(CAMERAS):
            frames=[]
            for frame_id in obs_ids:
                pos,size=self.cache_index[base+frame_id,ci]
                residual=np.frombuffer(zlib.decompress(self.cache_blob[pos:pos+size]),np.uint8).reshape(128,128,3)
                frames.append(np.cumsum(residual,axis=1,dtype=np.uint8))
            obs[c]=torch.from_numpy(np.moveaxis(np.stack(frames),-1,1).copy())
        obs["state"]=torch.from_numpy(np.asarray(e["state"][obs_ids]).copy())
        return {"obs":obs,"action":torch.from_numpy(e["delta"][act_ids].copy())}
    def normalizer(self):
        from diffusion_policy.model.common.normalizer import LinearNormalizer,SingleFieldLinearNormalizer as Field
        from diffusion_policy.common.normalize_util import get_image_range_normalizer
        n=LinearNormalizer()
        n["state"]=Field.create_fit(np.concatenate([e["state"] for e in self.arrays]),mode="limits")
        n["action"]=Field.create_fit(np.concatenate([e["delta"] for e in self.arrays]),mode="limits")
        for c in CAMERAS:n[c]=get_image_range_normalizer()
        return n

def cuda_batch(batch):
    obs={}
    for k,v in batch["obs"].items():
        v=v.cuda(non_blocking=True)
        obs[k]=v.float()/255 if k in CAMERAS else v
    return {"obs":obs,"action":batch["action"].cuda(non_blocking=True)}
