"""Execute official DP-C checkpoints through the Task2 action interface."""
import common
import importlib.util
import sys
import torch

sys.path.insert(0,str(common.DP))
spec=importlib.util.spec_from_file_location("task2_existing_action_interface",common.DP/"policy.py")
legacy=importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)

class Task2OfficialPolicy(legacy.Task2Policy):
    def __init__(self,checkpoint,device="cuda",n_action_steps=8,fixed_noise=False,seed=42):
        self.device=device
        payload=torch.load(checkpoint,map_location="cpu",weights_only=False)
        self.config=payload["config"]
        self.action_representation=self.config["action_representation"]
        self.model=common.build(self.config)
        self.model.load_state_dict(payload["ema"] if "ema" in payload else payload["model"])
        del payload
        self.model=self.model.to(device).eval()
        if not 1<=n_action_steps<=self.model.horizon-self.model.n_obs_steps+1:
            raise ValueError("Action block exceeds prediction horizon")
        self.model.n_action_steps=n_action_steps
        self.fixed_noise=fixed_noise
        self.seed=int(seed)
        self.generator=torch.Generator(device=device)
        self.model.kwargs["generator"]=self.generator
        self.reset()
