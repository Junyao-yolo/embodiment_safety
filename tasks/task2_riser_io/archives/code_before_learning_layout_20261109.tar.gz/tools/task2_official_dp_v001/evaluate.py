"""Persistent-scene closed-loop testing of a fixed Task2 DP-BC checkpoint."""
from pathlib import Path
import argparse,gc,json,runpy,sys,time,traceback
D=Path(__file__).resolve().parents[2]/"tasks/task2_riser_io/dp_bc";R=D.parent
sys.path.insert(0,str(D))
def make_source(checkpoint,out,seed,budget,steps,device):
 old=sys.argv
 sys.argv=[str(D/'evaluate.py'),'--checkpoint',str(checkpoint),'--output',str(out),'--seed',str(seed),
           '--max-seconds',str(budget),'--n-action-steps',str(steps),'--randomized-reset']
 captured=[]
 try:
  runpy.run_path(str(D/'evaluate.py'),init_globals={'compile':lambda source,*args:source,
                'exec':lambda source,namespace:captured.append((source,namespace))})
 finally:sys.argv=old
 source,ns=captured[0]
 source=source.replace("from client import PolicyClient","from official_client import PolicyClient")
 source=source.replace("ring_pose_stable=False,head_seated=False,mean_clamp_N=None","ring_pose_stable=False,head_seated=False,gripper_released=False,mean_clamp_N=None")
 source=source.replace("policy_client=PolicyClient(POLICY_CHECKPOINT,**EXECUTION_OPTIONS)",
                       "policy_client=PolicyClient(POLICY_CHECKPOINT,device=POLICY_DEVICE,**EXECUTION_OPTIONS)")
 source=source.replace(" if policy_client is not None:policy_client.close()\n report['performance']=performance_snapshot()",
                       " report['performance']=performance_snapshot()")
 source=source.replace("   records.append(rec)","   _trial_recorder.measure(rec,latest,sensor,ci,si,tr,target)\n   records.append(rec)")
 source=source.replace("  image_frames.append(images)","  _trial_recorder.frame(images,rec)\n  image_frames.append(images)")
 source=source.replace("if len(window)==physics_hz*3 and float(", "if observation%10==0 and len(window)==physics_hz*3 and float(")
 # Policy rollouts do not query the demonstration controller.
 source=source.replace(" if collection_config:\n  from feedback", " if collection_config and not globals().get('_policy_only',False):\n  from feedback")
 source=source.replace("'action_source':action_source}", "'action_source':'policy' if phase=='policy' else 'hold'}")
 source=source.replace("report['collection_method']=collection_config.get(\"method\",\"expert\")", "report['collection_method']='learned_policy'")
 source=source.replace("report['collection_config']=collection_config", "report['reset_configuration']={'randomize':True}")
 ns.update(POLICY_DEVICE=device,_policy_only=True)
 return source,ns

def main():
 p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--trials',type=int,default=100);p.add_argument('--seed',type=int,default=810000)
 p.add_argument('--seeds',type=int,nargs='+');p.add_argument('--stop-on-incomplete',action='store_true')
 p.add_argument('--max-seconds',type=float,default=360);p.add_argument('--n-action-steps',type=int,default=8)
 p.add_argument('--policy-device',default='cuda');p.add_argument('--thresholds',type=Path)
 a=p.parse_args();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
 seeds=a.seeds if a.seeds else [a.seed+i*4 for i in range(a.trials)]
 a.trials=len(seeds)
 checkpoint=a.checkpoint.resolve();thresholds=json.loads(a.thresholds.read_text()) if a.thresholds else {}
 config=dict(checkpoint=str(checkpoint),trials=a.trials,seeds=seeds,stop_on_incomplete=a.stop_on_incomplete,
  max_simulation_seconds=a.max_seconds,n_action_steps=a.n_action_steps,fixed_noise=False,policy_device=a.policy_device,
  reset_distribution='same ranges as demonstrations, independent reset groups',
  policy_observations='three RGB128 cameras and 23 robot-state values; no privileged scene state',
  task_acceptance='task2_released_assembly_v004',thresholds=thresholds)
 (a.output/'config.json').write_text(json.dumps(config,indent=2))
 from isaacsim import SimulationApp
 app=SimulationApp({'headless':True,'limit_cpu_threads':4,'width':128,'height':128,
  'sync_loads':True,'extra_args':['--/log/file='+str(a.output/'kit.log')]})
 from trial_recorder import TrialRecorder
 session={};started=time.perf_counter();results=[]
 try:
  for i in range(a.trials):
   seed=seeds[i];out=a.output/f'trial_{i:03d}';out.mkdir(exist_ok=True)
   resultfile=out/'evaluation.json'
   if resultfile.exists():
    result=json.loads(resultfile.read_text())
    if result.get('valid_policy_test'):results.append(result);continue
   recorder=TrialRecorder(out,seed,thresholds,label="Task2 official DP-C best epoch 18")
   source,ns=make_source(checkpoint,out,seed,a.max_seconds,a.n_action_steps,a.policy_device)
   ns.update(_simulation_app=app,_scene_session=session,_trial_recorder=recorder,_kit_log=a.output/'kit.log')
   before=time.perf_counter()
   def progress(row,perf):
    (a.output/'progress.json').write_text(json.dumps(dict(status='TESTING',completed=len(results),total=a.trials,
     active_trial=i,seed=seed,trial_wall_s=time.perf_counter()-before,measurements=row,performance=perf),indent=2))
   ns['_progress_callback']=progress
   sys.argv=[str(R/'scripts/run_dp_bc.py'),'--seed',str(seed),'--record']
   exec(compile(source,str(R/'scripts/run_dp_bc.py'),'exec'),ns)
   report=ns['report']
   report['policy_updates']=(report.get('command_blocks',0)+a.n_action_steps-1)//a.n_action_steps
   (out/'result.json').write_text(json.dumps(report,indent=2))
   assessment=recorder.finish(report)
   valid=(report.get('command_blocks',0)>0 or report.get('error') in ('Command outside joint or gripper range','Nonfinite action')) and report.get('error') in (None,'released assembly incomplete','Command outside joint or gripper range','Nonfinite action')
   full_success=bool(report.get('accepted') and report.get('thread_engagement_verified'))
   failure=('invalid_policy_action' if report.get('error') in ('Command outside joint or gripper range','Nonfinite action') else 'initial_grasp' if not report.get('wire_lifted') else
            'wire_transfer_or_seating' if not report.get('wire_seated') else
            'screw_pickup' if not report.get('screw_lifted') else
            'screw_fastening' if not report.get('screw_fastened') or not report.get('thread_engagement_verified') else 'release_or_retention')
   result=dict(trial=i,seed=seed,valid_policy_test=valid,task_success=full_success,
     failure_category=None if full_success else failure if valid else 'execution_error',
     wall_s=time.perf_counter()-before,simulation_s=ns['stepnum']/ns['physics_hz'],
     report=report,safety=assessment,video=str(out/'rollout.mp4'),measurements=str(out/'measurements.npz'))
   resultfile.write_text(json.dumps(result,indent=2));results.append(result)
   render_setup=ns.get('setup_render')
   render={name:getattr(render_setup,name) for name in ('anns','products','paths','manifest')} if hasattr(render_setup,'anns') else {}
   if 'sim' in ns:
    ns['sim'].stop();session=dict(sim=ns['sim'],initial_transforms=ns['initial_transforms'],
      assembly_geometry=ns['assembly_geometry'],render=render)
   if 'view' in ns:ns['view'].invalidate()
   ns.clear();del recorder;gc.collect()
   from summarize_evaluation import summarize
   summarize(a.output)
   if a.stop_on_incomplete and valid and not full_success:
    (a.output/'progress.json').write_text(json.dumps(dict(status='PILOT_INCOMPLETE',completed=len(results),total=a.trials,failed_seed=seed,trial=str(out)),indent=2))
    return
   if not valid:raise RuntimeError('Invalid policy test; preserve evidence and repair before continuing: '+str(out))
  state=dict(status='COMPLETE',completed=len(results),total=a.trials,wall_s=time.perf_counter()-started)
  (a.output/'progress.json').write_text(json.dumps(state,indent=2))
 except Exception:
  (a.output/'error.txt').write_text(traceback.format_exc());raise
 finally:
  for ann in session.get('render',{}).get('anns',{}).values():ann.detach()
  for product in session.get('render',{}).get('products',[]):product.destroy()
  app.close()
if __name__=='__main__':main()
