from pathlib import Path
import json,sys,time
import numpy as np
from official_client import PolicyClient
ROOT=Path(__file__).resolve().parents[2]
DP=ROOT/"tasks/task2_riser_io/dp_bc"
RUN=DP/"runs/official_dp_current_input_v001"
OUT=DP/"evaluations/official_dp_best18_v001"
OUT.mkdir(parents=True,exist_ok=True)
manifest=json.loads((RUN/"data_manifest.json").read_text())
episode=Path(next(x["path"] for x in manifest["episodes"] if x["split"]=="validation"))
state=np.load(episode/"state.npy",mmap_mode="r")
cameras=("external","wrist_left","wrist_right")
images={c:np.load(episode/(c+".npy"),mmap_mode="r") for c in cameras}
client=PolicyClient(RUN/"checkpoints/best_ema.pt",device="cuda",n_action_steps=8,fixed_noise=False,seed=970000)
elapsed=[]
try:
 for i in range(9):
  begin=time.perf_counter()
  action=client.act({c:images[c][i] for c in cameras},state[i])
  elapsed.append(time.perf_counter()-begin)
  assert action.shape==(6,9) and np.isfinite(action).all()
finally:
 client.close()
result=dict(status="PASSED",checkpoint=str(RUN/"checkpoints/best_ema.pt"),observation_shapes={c:[128,128,3] for c in cameras},state_dim=23,command_shape=[6,9],action_block=8,calls=9,call_wall_seconds=elapsed,simulation_task_success_verified=False)
(OUT/"interface_check.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
