"""Lossless RGB cache for random-access Task2 training batches."""
import common
import argparse,json,time,zlib,os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import numpy as np

def encode(frame):
    residual=np.empty_like(frame);residual[:,0]=frame[:,0]
    residual[:,1:]=frame[:,1:]-frame[:,:-1]
    return zlib.compress(residual.tobytes(),3)

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--config",required=True);a=ap.parse_args()
    cfg=json.loads(Path(a.config).read_text())
    manifest=json.loads(Path(cfg["manifest"]).read_text())
    out=Path(cfg["output_dir"])/"rgb_cache";out.mkdir(exist_ok=True)
    n=sum(e["samples"] for e in manifest["episodes"])
    index=np.lib.format.open_memmap(out/"index.npy",mode="w+",dtype=np.int64,shape=(n,3,2))
    start=time.monotonic();offset=0;rows=[];checks=0
    with (out/"rgb.bin").open("wb") as stream,ThreadPoolExecutor(max_workers=8) as pool:
        for episode in manifest["episodes"]:
            p=Path(episode["path"]);length=episode["samples"]
            for c,key in enumerate(common.CAMERAS):
                frames=np.load(p/(key+".npy"),mmap_mode="r")
                for left in range(0,length,128):
                    chunk=np.asarray(frames[left:left+128]).copy()
                    blobs=list(pool.map(encode,chunk))
                    for j,blob in enumerate(blobs):
                        frame_id=left+j
                        index[offset+frame_id,c]=[stream.tell(),len(blob)]
                        stream.write(blob)
                        if frame_id in (0,length-1):
                            restored=np.cumsum(np.frombuffer(zlib.decompress(blob),np.uint8).reshape(128,128,3),axis=1,dtype=np.uint8)
                            assert np.array_equal(restored,frames[frame_id])
                            checks+=1
            rows.append(dict(path=str(p),offset=offset,samples=length))
            offset+=length
            common.write_json(out/"progress.json",dict(episodes=len(rows),total_episodes=100,rows=offset,total_rows=n,
                bytes_written=stream.tell(),wall_s=time.monotonic()-start))
    index.flush()
    common.write_json(out/"manifest.json",dict(status="COMPLETE",rows=n,cameras=list(common.CAMERAS),episodes=rows,
        encoding="horizontal uint8 delta + zlib level3",verified_roundtrip_frames=checks,
        raw_bytes=n*3*128*128*3,cache_bytes=(out/"rgb.bin").stat().st_size,
        wall_s=time.monotonic()-start))
    print((out/"manifest.json").read_text(),flush=True)
if __name__=="__main__":main()
