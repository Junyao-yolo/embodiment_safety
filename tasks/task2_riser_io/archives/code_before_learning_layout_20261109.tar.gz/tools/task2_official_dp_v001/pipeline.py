"""Build the Task2 image cache and continue the 100-epoch training run."""
from pathlib import Path
import json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
OUT=ROOT/"tasks/task2_riser_io/dp_bc/runs/official_dp_current_input_v001"
PYTHON=ROOT/"algos/diffusion_policy/.venv/bin/python"

def main():
    common_args=["--config",str(OUT/"config.json")]
    (OUT/"pipeline_status.json").write_text(json.dumps({"status":"BUILDING_RGB_CACHE","started_unix":time.time()}))
    if not (OUT/"rgb_cache/manifest.json").exists():
        with (OUT/"cache.log").open("w") as stream:
            result=subprocess.run([str(PYTHON),"-B","-u",str(HERE/"cache_images.py"),*common_args],cwd=ROOT,
                stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError("RGB cache failed; see cache.log")
    (OUT/"pipeline_status.json").write_text(json.dumps({"status":"TRAINING_100_EPOCHS","started_unix":time.time()}))
    with (OUT/"train.log").open("a") as stream:
        proc=subprocess.Popen([str(PYTHON),"-B","-u",str(HERE/"train.py"),*common_args],cwd=ROOT,
            stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
        (OUT/"train.pid").write_text(str(proc.pid))
        code=proc.wait()
    (OUT/"pipeline_status.json").write_text(json.dumps({"status":"TRAINING_FINISHED" if code==0 else "TRAINING_ERROR","exit_code":code}))
if __name__=="__main__":main()
