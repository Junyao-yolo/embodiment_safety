"""Train the official Task2 DP-C model with resumable full-state checkpoints."""
import common
import argparse,copy,json,math,random,signal,subprocess,threading,time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from diffusion_policy.model.diffusion.ema_model import EMAModel

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--config",required=True)
    ap.add_argument("--stop-after",type=int);ap.add_argument("--smoke",action="store_true")
    a=ap.parse_args();cfg=json.loads(Path(a.config).read_text())
    limit=min(cfg["updates"],a.stop_after or cfg["updates"])
    out=Path(cfg["output_dir"])/"smoke" if a.smoke else Path(cfg["output_dir"])
    out.mkdir(parents=True,exist_ok=True);ckpts=out/"checkpoints";ckpts.mkdir(exist_ok=True)
    common.write_json(out/"config.json",cfg)
    torch.set_num_threads(4);torch.manual_seed(cfg["seed"]);np.random.seed(cfg["seed"]);random.seed(cfg["seed"])
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=True
    data=common.Sequences(cfg,"train");val=common.Sequences(cfg,"validation")
    model=common.build(cfg);model.set_normalizer(data.normalizer());model.cuda()
    ema_model=copy.deepcopy(model);ema=EMAModel(ema_model,**cfg["ema"])
    opt=torch.optim.AdamW(model.parameters(),lr=cfg["lr"],betas=(.95,.999),eps=1e-8,weight_decay=1e-6)
    def factor(s):
        if s<cfg["warmup_steps"]:return s/max(1,cfg["warmup_steps"])
        f=(s-cfg["warmup_steps"])/(cfg["scheduler_total_steps"]-cfg["warmup_steps"])
        return .5*(1+math.cos(math.pi*min(f,1.)))
    sched=torch.optim.lr_scheduler.LambdaLR(opt,factor)
    step=epoch=batch_index=0;best=float("inf");train_seconds=0.
    # batch_index is the number of consumed batches in the current epoch.
    last=ckpts/"last.pt"
    if last.exists() and not a.smoke:
        payload=torch.load(last,map_location="cpu",weights_only=False)
        assert payload["config"]==cfg
        model.load_state_dict(payload["model"]);ema_model.load_state_dict(payload["ema"])
        model.cuda();ema_model.cuda()
        opt.load_state_dict(payload["optimizer"]);sched.load_state_dict(payload["scheduler"])
        step=payload["step"];epoch=payload["epoch"];batch_index=payload["batch_index"]
        best=payload["best_val_loss"];train_seconds=payload["train_seconds"]
        ema.optimization_step=payload["ema_step"]
        torch.set_rng_state(payload["torch_rng"]);torch.cuda.set_rng_state(payload["cuda_rng"])
        np.random.set_state(payload["numpy_rng"]);random.setstate(payload["python_rng"])
        del payload
    halt=threading.Event()
    signal.signal(signal.SIGTERM,lambda *_:halt.set());signal.signal(signal.SIGINT,lambda *_:halt.set())
    startwall=time.monotonic()
    log=(out/"metrics.jsonl").open("a",buffering=1)
    def record(row):
        log.write(json.dumps(row)+"\n");print(json.dumps(row),flush=True)
    common.write_json(out/"training_start.json",dict(pid=__import__("os").getpid(),
        device=torch.cuda.get_device_name(),parameters=sum(p.numel() for p in model.parameters()),
        trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
        train_episodes=cfg["train_episodes"],validation_episodes=cfg["validation_episodes"],
        train_windows=len(data),validation_windows=len(val),step=step,precision=cfg["precision"],
        official_prediction_type=model.noise_scheduler.config.prediction_type))
    common.write_json(out/"progress.json",dict(status="INITIALIZED",step=step,total_steps=cfg["updates"]))
    def save(path):
        begin=time.monotonic()
        payload=dict(config=cfg,model=model.state_dict(),ema=ema_model.state_dict(),optimizer=opt.state_dict(),
            scheduler=sched.state_dict(),step=step,epoch=epoch,batch_index=batch_index,best_val_loss=best,
            train_seconds=train_seconds,ema_step=ema.optimization_step,torch_rng=torch.get_rng_state(),
            cuda_rng=torch.cuda.get_rng_state(),numpy_rng=np.random.get_state(),python_rng=random.getstate())
        temp=path.with_suffix(".partial");torch.save(payload,temp);temp.replace(path)
        record(dict(event="checkpoint",step=step,path=str(path),seconds=time.monotonic()-begin))
    def validate():
        begin=time.monotonic();ema_model.eval();total=count=0
        loader=DataLoader(val,batch_size=64,shuffle=False,num_workers=cfg["num_workers"],
            pin_memory=True,generator=torch.Generator().manual_seed(1729))
        with torch.random.fork_rng(devices=[0]),torch.no_grad():
            torch.manual_seed(1729);torch.cuda.manual_seed_all(1729)
            for b in loader:
                b=common.cuda_batch(b);loss=ema_model.compute_loss(b)
                n=len(b["action"]);total+=float(loss)*n;count+=n
        return total/count,time.monotonic()-begin
    def telemetry():
        with (out/"gpu.jsonl").open("a",buffering=1) as f:
            while not halt.is_set():
                r=subprocess.run(["nvidia-smi","--query-gpu=timestamp,name,utilization.gpu,memory.used,power.draw","--format=csv,noheader"],capture_output=True,text=True)
                f.write(json.dumps({"time":time.time(),"gpu":r.stdout.strip()})+"\n")
                halt.wait(30)
    threading.Thread(target=telemetry,daemon=True).start()
    recent=[];stable=[];resume_step=step
    first_batch=None
    while step<limit and not halt.is_set():
        ids=torch.randperm(len(data),generator=torch.Generator().manual_seed(cfg["seed"]+epoch)).tolist()[batch_index*64:]
        loader=DataLoader(data,batch_size=64,sampler=ids,num_workers=cfg["num_workers"],
            pin_memory=True,persistent_workers=False,prefetch_factor=2,
            generator=torch.Generator().manual_seed(cfg["seed"]+epoch))
        iterator=iter(loader);model.train()
        while step<limit and not halt.is_set():
            begin=time.monotonic()
            try:b=next(iterator)
            except StopIteration:break
            datawait=time.monotonic()-begin;b=common.cuda_batch(b)
            if first_batch is None:first_batch={k:v[:1].clone() for k,v in b["obs"].items()}
            opt.zero_grad(set_to_none=True);loss=model.compute_loss(b);loss.backward()
            opt.step();sched.step();ema.step(model)
            value=float(loss.detach())
            if not math.isfinite(value):raise RuntimeError(f"Nonfinite loss at step {step+1}")
            elapsed=time.monotonic()-begin
            step+=1;batch_index+=1;train_seconds+=elapsed
            recent.append((elapsed,datawait,value))
            if 50<step-resume_step<=150:stable.append((elapsed,datawait,value))
            if step==1 or step%25==0 or step==limit:
                arr=np.asarray(recent)
                row=dict(status="TRAINING",event="train",step=step,epoch=epoch+batch_index/cfg["steps_per_epoch"],
                    full_budget_steps=cfg["updates"],loss_mean=float(arr[:,2].mean()),lr=sched.get_last_lr()[0],
                    seconds_per_update=float(arr[:,0].mean()),data_wait_ms=float(arr[:,1].mean()*1000),
                    train_seconds=train_seconds,elapsed_wall_s=time.monotonic()-startwall,
                    eta_full_train_seconds=float(arr[:,0].mean()*(cfg["updates"]-step)),
                    gpu_peak_mib=torch.cuda.max_memory_allocated()/2**20)
                record(row);common.write_json(out/"progress.json",row);recent=[]
            if step-resume_step==150 and stable:
                arr=np.asarray(stable);per=float(arr[:,0].mean())
                common.write_json(out/"timing.json",dict(warmup_updates=50,measured_updates=len(stable),
                    seconds_per_update=per,data_wait_ms=float(arr[:,1].mean()*1000),
                    seconds_per_epoch=per*cfg["steps_per_epoch"],
                    training_100_epochs_hours=per*cfg["steps_per_epoch"]*100/3600,
                    training_full_budget_days=per*cfg["updates"]/86400,
                    excludes_validation_and_checkpoint=True))
            if a.smoke and step>=limit:break
            if step%cfg["validate_every"]==0 or step==limit:
                vl,seconds=validate()
                record(dict(event="validation",step=step,epoch=epoch+batch_index/cfg["steps_per_epoch"],
                    ema_val_epsilon_mse=vl,windows=len(val),seconds=seconds))
                if vl<best:
                    best=vl
                    tmp=ckpts/"best_ema.partial";torch.save(dict(config=cfg,model=ema_model.state_dict(),step=step,
                        validation_loss=vl),tmp);tmp.replace(ckpts/"best_ema.pt")
            if step%cfg["checkpoint_every"]==0 or step==limit:save(last)
        del iterator,loader
        if step>=limit or halt.is_set():break
        epoch+=1;batch_index=0
    save(last)
    if a.smoke:
        ema_model.eval()
        with torch.no_grad():pred=ema_model.predict_action(first_batch)["action"]
        assert pred.shape==(1,8,48) and torch.isfinite(pred).all()
        before=pred.cpu()
        del model,opt,ema,ema_model,b
        torch.cuda.empty_cache()
        payload=torch.load(last,map_location="cpu",weights_only=False)
        loaded=common.build(cfg);loaded.load_state_dict(payload["ema"]);loaded.cuda().eval()
        del payload
        with torch.no_grad():pred=loaded.predict_action(first_batch)["action"]
        assert pred.shape==(1,8,48) and torch.isfinite(pred).all()
        common.write_json(out/"result.json",dict(status="TASK2_OFFICIAL_SMOKE_OK",steps=step,
            output_shape=list(pred.shape),checkpoint_reload=True,full_task_success_verified=False,
            seconds=time.monotonic()-startwall))
        print("TASK2_OFFICIAL_SMOKE_OK",flush=True)
    else:
        common.write_json(out/("paused.json" if halt.is_set() else "completed.json"),dict(step=step,epoch=epoch+batch_index/cfg["steps_per_epoch"],
            training_seconds=train_seconds,best_val_epsilon_mse=best,full_budget_complete=step==cfg["updates"],
            full_task_success_verified=False))
    halt.set();log.close()
if __name__=="__main__":main()
